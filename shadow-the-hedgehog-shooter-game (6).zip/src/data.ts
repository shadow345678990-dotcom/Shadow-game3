import type { SceneId } from './game/arenas';

export type Difficulty = 'easy' | 'normal' | 'hard';
export type GameMode = 'story' | 'survival';
export type Power = 'spear' | 'control' | 'blast';
export type DoomPower = 'spear' | 'morph' | 'surf' | 'blast' | 'wing';
export type DoomForm = 'morph' | 'surf' | 'wing';
export type StageType = 'eliminate' | 'survive' | 'collect' | 'defend' | 'boss' | 'interact' | 'reach';

export interface Settings {
  sound: boolean;
  difficulty: Difficulty;
  screenShake: boolean;
  autoAim: boolean;
}

export interface Emerald {
  id: number;
  name: string;
  color: string;
  gift: string;
}

export const emeralds: Emerald[] = [
  { id: 0, name: 'امرالد سبز', color: '#8ced6d', gift: 'نیزهٔ کیاس را بیدار می‌کند.' },
  { id: 1, name: 'امرالد آبی', color: '#5fa8ff', gift: 'جریان انرژی را پایدار نگه می‌دارد.' },
  { id: 2, name: 'امرالد زرد', color: '#ffd24a', gift: 'سرعت واکنش شدو را بالا می‌برد.' },
  { id: 3, name: 'امرالد سفید', color: '#e9e6f2', gift: 'خاطرات آرک را روشن می‌کند.' },
  { id: 4, name: 'امرالد بنفش', color: '#b57bff', gift: 'کنترل کیاس را عمیق‌تر می‌کند.' },
  { id: 5, name: 'امرالد لاجوردی', color: '#4ad9d0', gift: 'دید شدو در تاریکی را تیز می‌کند.' },
  { id: 6, name: 'امرالد قرمز', color: '#ff5560', gift: 'انفجار کیاس را مهارناپذیر می‌کند.' },
];

export interface DialogueLine {
  speaker: string;
  text: string;
}

export interface Stage {
  type: StageType;
  title: string;
  detail: string;
  target: number;
  emeralds?: number[];
  scene: SceneId;
  dialogue: DialogueLine[];
  radio?: DialogueLine;
  guards?: number;
  objectLabel?: string;
  boss?: 'commander' | 'black-doom';
}

export interface Chapter {
  id: number;
  title: string;
  subtitle: string;
  location: string;
  paragraphs: string[];
  mission: string;
  arena: 'ark' | 'city';
  faction: 'gun' | 'arms';
  stages: Stage[];
  epilogue: string;
  estimatedMinutes: string;
  finale?: DialogueLine[];
}

export const chapters: Chapter[] = [
  {
    id: 0,
    title: 'پروژهٔ شدو',
    subtitle: 'آغاز یک زندگی غیرممکن',
    location: 'ایستگاه فضایی آرک',
    paragraphs: [
      'پنجاه سال پیش، پروفسور جرالد روباتنیک در ایستگاه فضایی آرک، پروژه‌ای برای ساخت شکل نهایی حیات آغاز کرد. با کمک دی‌ان‌ای بلک دووم، شدو به وجود آمد؛ موجودی که می‌توانست انرژی کیاس امرالدها را کنترل کند.',
      'ماریا، نوهٔ جرالد، اولین دوست شدو بود. او از زمینی می‌گفت که آرزو داشت روزی آن را ببیند. اما آرامش آرک ماندگار نبود. نیروهای G.U.N. وارد ایستگاه شدند و شدو برای اولین بار مجبور شد بجنگد.',
    ],
    mission: 'آزمایشگاه آرک را پاک‌سازی کن و اولین کیاس امرالد را به دست بیاور.',
    arena: 'ark',
    faction: 'gun',
    estimatedMinutes: '۵ تا ۸',
    epilogue: 'شدو برای نخستین بار از پنجرهٔ آرک زمین را دید. ماریا گفت آن پایین آدم‌هایی زندگی می‌کنند که هنوز او را نمی‌شناسند. اما آژیرهای سرخ به صدا درآمدند؛ خاطرهٔ آرام رصدخانه، آخرین آرامش آرک بود.',
    stages: [
      { type: 'eliminate', title: 'بیداری در آزمایشگاه', detail: '۲۸ ربات آزمایشی را شکست بده و کنترل توانایی‌هایت را پس بگیر.', target: 28, scene: 'ark-lab', dialogue: [{ speaker: 'جرالد', text: 'شدو، صدای مرا می‌شنوی؟ این آزمایشگاه خانهٔ توست. امروز باید یاد بگیری از قدرتت برای محافظت استفاده کنی.' }, { speaker: 'شدو', text: 'اسم من... شدو. آماده‌ام، پروفسور.' }], radio: { speaker: 'جرالد', text: 'انرژی‌ات را کنترل کن. قدرت تو فقط به سلاحت محدود نیست.' } },
      { type: 'interact', title: 'اولین تصویر از زمین', detail: 'کنار سه کنسول رصدخانه بایست تا داده‌ها فعال شوند.', target: 3, scene: 'ark-observatory', dialogue: [{ speaker: 'ماریا', text: 'آن سیارهٔ آبی زمین است. می‌خواهم یک روز با هم آن را ببینیم. اول پنجره‌های رصدخانه را روشن کنیم.' }, { speaker: 'شدو', text: 'برای همین از من خواسته‌ای کنسول‌ها را فعال کنم؟ می‌خواهم آن دنیا را بشناسم.' }] },
      { type: 'survive', title: 'راکتور ناپایدار', detail: '۷۰ ثانیه از راکتور کیاس در برابر ربات‌های خراب‌شده دفاع کن.', target: 70, scene: 'ark-reactor', dialogue: [{ speaker: 'جرالد', text: 'راکتور از کنترل خارج شده است. تا وقتی مدار اضطراری را تعمیر کنم، نگذار ربات‌ها به تو نزدیک شوند.' }, { speaker: 'شدو', text: 'ماریا پشت این در است. هیچ‌چیز از اینجا عبور نمی‌کند.' }], radio: { speaker: 'جرالد', text: 'مدار دوم برقرار شد. فقط کمی بیشتر دوام بیاور.' } },
      { type: 'collect', title: 'نخستین سنگ آشوب', detail: '۱۲ نگهبان را شکست بده؛ سپس امرالد سبز را از آزمایشگاه بردار.', target: 1, guards: 12, emeralds: [0], scene: 'ark-lab', dialogue: [{ speaker: 'جرالد', text: 'این سنگ یک کیاس امرالد است. ربات‌ها محفظه‌اش را قفل کرده‌اند؛ تا نگهبانان را شکست ندهی آزاد نمی‌شود.' }, { speaker: 'شدو', text: 'می‌توانم انرژی‌اش را حس کنم. انگار از قبل مرا می‌شناسد.' }] },
      { type: 'eliminate', title: 'فرمان محرمانهٔ G.U.N.', detail: '۳۲ ربات مهاجم راهروی آرک را متوقف کن.', target: 32, scene: 'ark-corridor', dialogue: [{ speaker: 'راوی', text: 'یک پیام نظامی، دسترسی‌های آرک را قطع می‌کند. این بار ربات‌ها برای آزمایش نیامده‌اند.' }, { speaker: 'ماریا', text: 'شدو، باید برویم! درهای آشیانه هنوز باز هستند.' }], radio: { speaker: 'شدو', text: 'این حمله را فراموش نمی‌کنم. اما اول باید ماریا را به جای امن برسانم.' } },
      { type: 'reach', title: 'مسیر آشیانه', detail: '۱۴ نگهبان را از سر راه بردار؛ سپس ۸ ثانیه در نقطهٔ خروج بمان.', target: 8, guards: 14, scene: 'ark-hangar', dialogue: [{ speaker: 'ماریا', text: 'از این آشیانه می‌توانیم به بخش کپسول‌ها برسیم. من راه را نشان می‌دهم.' }, { speaker: 'شدو', text: 'پشت سرم بمان. تا وقتی من اینجا هستم، به تو نمی‌رسند.' }] },
    ],
  },
  {
    id: 1,
    title: 'آخرین قول به ماریا',
    subtitle: 'یک خاطره، یک قول',
    location: 'راهروی خروج اضطراری آرک',
    paragraphs: [
      'عملیات نظامی آرک به فاجعه تبدیل شد. ماریا برای نجات شدو، او را در یک کپسول فرار قرار داد. پیش از آن‌که کپسول به زمین فرستاده شود، از شدو خواست به انسان‌ها فرصتی برای خوشبختی بدهد.',
      'شدو زنده ماند، اما ماریا نه. آن قول در اعماق خاطرات او پنهان شد. حالا در بازآفرینی آخرین لحظات آرک، از کپسول فرار محافظت کن و آخرین امید ماریا را زنده نگه دار.',
    ],
    mission: 'از کپسول فرار محافظت کن و مسیر خروج را امن نگه دار.',
    arena: 'ark',
    faction: 'gun',
    estimatedMinutes: '۶ تا ۹',
    epilogue: 'ماریا اهرم پرتاب را کشید. در آخرین لحظه گفت: «به آن‌ها فرصتی برای خوشبختی بده.» کپسول به سوی زمین رفت، اما ماریا جا ماند. این قول در خاطرات زخمی شدو پنهان شد؛ قولی که قرار بود روزی دوباره راهش را روشن کند.',
    stages: [
      { type: 'survive', title: 'آرک زیر آتش', detail: '۸۰ ثانیه محاصرهٔ راهروهای اضطراری را تحمل کن.', target: 80, scene: 'ark-corridor', dialogue: [{ speaker: 'راوی', text: 'صدای آژیر جای صدای قدم‌های آرام ماریا را گرفته است. نیروهای G.U.N. همهٔ راه‌های خروج را بسته‌اند.' }, { speaker: 'شدو', text: 'یک مسیر دیگر پیدا می‌کنم. هنوز وقت داریم.' }], radio: { speaker: 'ماریا', text: 'در سمت راکتور یک راه اضطراری هست! از آنجا برو.' } },
      { type: 'interact', title: 'باز کردن مسیر اضطراری', detail: 'سه مدار راکتور را با ایستادن کنار کنسول‌ها آزاد کن.', target: 3, scene: 'ark-reactor', dialogue: [{ speaker: 'ماریا', text: 'کلیدهای اصلی قطع شده‌اند. باید سه مدار پشتیبان را یکی‌یکی روشن کنی.' }, { speaker: 'شدو', text: 'پس همین کار را می‌کنیم. تو به آشیانه برو.' }] },
      { type: 'eliminate', title: 'آخرین راهرو', detail: '۳۶ نگهبان را متوقف کن تا ماریا به آشیانه برسد.', target: 36, scene: 'ark-corridor', dialogue: [{ speaker: 'شدو', text: 'آن‌ها دوباره برگشته‌اند. این راهرو آخرین مانع بین ما و کپسول است.' }, { speaker: 'ماریا', text: 'من آماده‌سازی کپسول را شروع می‌کنم. مراقب خودت باش.' }] },
      { type: 'defend', title: 'محافظت از امید ماریا', detail: '۹۰ ثانیه از کپسول فرار محافظت کن؛ نگذار سلامتی آن تمام شود.', target: 90, objectLabel: 'کپسول فرار ماریا', scene: 'ark-hangar', dialogue: [{ speaker: 'ماریا', text: 'سامانهٔ پرتاب باید گرم شود. شدو، اگر کپسول سالم بماند، هنوز راهی برای نجات هست.' }, { speaker: 'شدو', text: 'قول می‌دهم. هیچ‌کس این کپسول را از ما نمی‌گیرد.' }], radio: { speaker: 'ماریا', text: 'سامانه دارد آماده می‌شود. من کنار اهرم پرتاب هستم.' } },
      { type: 'collect', title: 'یادگار آبی', detail: '۱۴ نگهبان محفظه را شکست بده و امرالد آبی را بردار.', target: 1, guards: 14, emeralds: [1], scene: 'ark-hangar', dialogue: [{ speaker: 'ماریا', text: 'این امرالد را هم با خودت ببر. شاید یک روز کمکت کند آنچه اینجا اتفاق افتاد را به یاد بیاوری.' }, { speaker: 'شدو', text: 'با خودم می‌برمش. اما بدون تو جایی نمی‌روم.' }] },
      { type: 'reach', title: 'آخرین قول', detail: '۱۶ ربات آخر را شکست بده و ۸ ثانیه کنار کپسول پرتاب بمان.', target: 8, guards: 16, scene: 'ark-hangar', dialogue: [{ speaker: 'ماریا', text: 'شدو، یک خواهش دارم. آن پایین، به مردم فرصتی بده... برای خوشبختی.' }, { speaker: 'شدو', text: 'ماریا؟ چرا فقط یک کپسول آماده است؟ صبر کن!' }] },
    ],
  },
  {
    id: 2,
    title: 'خاطرات گمشده',
    subtitle: 'پنجاه سال بعد',
    location: 'سنترال سیتی',
    paragraphs: [
      'پنجاه سال پس از حادثهٔ آرک، دکتر اگمن شدو را از محفظهٔ نگهداری آزاد کرد. شدو ابتدا فکر می‌کرد خواستهٔ ماریا انتقام است؛ اما با کمک سونیک و دوستانش، حقیقت آخرین قول او را به یاد آورد و برای نجات زمین جنگید.',
      'پس از نبرد با بایولیزارد و سقوط از آرک، شدو دوباره با خاطراتی شکسته بیدار شد. او همراه روژ و اُمگا به دنبال پاسخ رفت: آیا او شدوی واقعی است؟ در خیابان‌های سنترال سیتی، تنها راه رسیدن به حقیقت، عبور از ربات‌هاست.',
    ],
    mission: 'شهر را پاک کن، دو امرالد دیگر را پیدا کن و رد گذشته‌ات را دنبال کن.',
    arena: 'city',
    faction: 'gun',
    estimatedMinutes: '۶ تا ۹',
    epilogue: 'فایل‌های آرک یک پاسخ روشن داشتند: ماریا انتقام نخواسته بود. روژ در سکوت کنار شدو ایستاد و اُمگا نگهبانی داد. شدو هنوز همهٔ گذشته‌اش را به یاد نمی‌آورد، اما حالا می‌دانست برای چه باید بجنگد. آن شب، سایهٔ دنباله‌دار سیاه روی شهر افتاد.',
    stages: [
      { type: 'eliminate', title: 'بیداری در شهر', detail: '۳۶ ربات خیابان‌های سنترال سیتی را پاک‌سازی کن.', target: 36, scene: 'city-street', dialogue: [{ speaker: 'راوی', text: 'پنجاه سال گذشته است. پس از نبرد آرک و بیداری دوباره، خاطرات شدو مانند شیشهٔ شکسته‌اند.' }, { speaker: 'روژ', text: 'اگمن نسخه‌ای از اسناد پروژهٔ شدو را نگه داشته. برای رسیدن به آن باید از این خیابان بگذریم.' }] },
      { type: 'interact', title: 'پروندهٔ پروژهٔ شدو', detail: 'چهار پایانهٔ اسناد را فعال کن و پرونده‌های آرک را بازیابی کن.', target: 4, scene: 'city-archive', dialogue: [{ speaker: 'اُمگا', text: 'پایگاه دادهٔ اگمن شناسایی شد. چهار پایانه لازم است. دشمن در مسیر.' }, { speaker: 'شدو', text: 'اگر پاسخ‌ها اینجا هستند، تا پیدایشان نکنم نمی‌روم.' }] },
      { type: 'collect', title: 'دو خاطرهٔ روشن', detail: '۱۸ نگهبان اسناد را شکست بده؛ سپس امرالد زرد و سفید را پیدا کن.', target: 2, guards: 18, emeralds: [2, 3], scene: 'city-archive', dialogue: [{ speaker: 'روژ', text: 'این دو امرالد کنار فایل‌های آرک پنهان شده‌اند. ربات‌های نگهبان قفل میدان را نگه داشته‌اند.' }, { speaker: 'شدو', text: 'صدای ماریا را به یاد می‌آورم... اما هنوز نمی‌دانم آخرین حرفش چه بود.' }] },
      { type: 'survive', title: 'محاصره روی پل', detail: '۹۰ ثانیه راه تخلیهٔ پل شهر را باز نگه دار.', target: 90, scene: 'city-bridge', dialogue: [{ speaker: 'روژ', text: 'نیروهای امنیتی ما را پیدا کرده‌اند. مردم هنوز روی این پل هستند.' }, { speaker: 'شدو', text: 'پس اینجا می‌ایستیم. این بار کسی به خاطر من جا نمی‌ماند.' }], radio: { speaker: 'اُمگا', text: 'تخلیه ادامه دارد. مقاومت تو موثر است.' } },
      { type: 'eliminate', title: 'حقیقت پشت انتقام', detail: '۴۰ ربات را شکست بده تا روژ آخرین فایل ماریا را رمزگشایی کند.', target: 40, scene: 'city-street', dialogue: [{ speaker: 'روژ', text: 'یک بخش از پیام باز شد: ماریا از تو انتقام نخواسته بود. باید فایل آخر را نجات دهیم.' }, { speaker: 'شدو', text: 'پس تمام این مدت... نه. این بار حقیقت را پیدا می‌کنم.' }], radio: { speaker: 'روژ', text: 'او گفت: فرصتی برای خوشبختی. شدو، این همان قول توست.' } },
      { type: 'reach', title: 'انتخاب دوباره', detail: '۱۲ ربات باقی‌مانده را نابود کن و ۱۰ ثانیه در نقطهٔ ملاقات بمان.', target: 10, guards: 12, scene: 'city-archive', dialogue: [{ speaker: 'شدو', text: 'من یک آزمایش یا یک خاطرهٔ ناقص نیستم. قولی داده‌ام و می‌خواهم آن را نگه دارم.' }, { speaker: 'اُمگا', text: 'هدف جدید ثبت شد: محافظت از زمین.' }] },
    ],
  },
  {
    id: 3,
    title: 'بازگشت بلک دووم',
    subtitle: 'خون تاریکی، انتخاب روشنایی',
    location: 'سنترال سیتی، منطقهٔ اشغال‌شده',
    paragraphs: [
      'با بازگشت دنباله‌دار سیاه، ارتش بلک آرمز به زمین حمله کرد. بلک دووم به شدو گفت که در آفرینش او نقش داشته و حالا باید هفت کیاس امرالد را برایش جمع کند. او می‌خواست از پیوند خونشان برای کنترل شدو استفاده کند.',
      'اما گذشته قرار نبود آیندهٔ شدو را تعیین کند. شدو در میان نبرد، خودش را شناخت و تصمیم گرفت مقابل بلک آرمز بایستد. نیروهای مهاجم را عقب بران و فرماندهٔ آن‌ها را از میان بردار.',
    ],
    mission: 'مهاجمان بلک آرمز را عقب بران و فرماندهٔ آن‌ها را شکست بده.',
    arena: 'city',
    faction: 'arms',
    estimatedMinutes: '۷ تا ۱۰',
    epilogue: 'فرماندهٔ بلک آرمز سقوط کرد و مسیر تخلیه باز شد. بلک دووم از دور به ذهن شدو فشار آورد، اما پاسخ او روشن بود: «خون تو انتخاب مرا تعیین نمی‌کند.» با پنج امرالد، راه رسیدن به دنباله‌دار سیاه پیدا شد.',
    stages: [
      { type: 'eliminate', title: 'آسمان اشغال‌شده', detail: '۴۲ مهاجم را از خیابان‌های آلوده به بلک آرمز عقب بران.', target: 42, scene: 'city-occupied', dialogue: [{ speaker: 'بلک دووم', text: 'شدو، من در آفرینش تو نقش داشتم. امرالدها را برای من بیاور؛ این زمین سهم من است.' }, { speaker: 'شدو', text: 'ممکن است خون تو در من باشد، اما من دستور تو را اجرا نمی‌کنم.' }] },
      { type: 'defend', title: 'مردم پشت درهای پناهگاه', detail: '۹۰ ثانیه از سامانهٔ در پناهگاه محافظت کن.', target: 90, objectLabel: 'سامانهٔ پناهگاه', scene: 'city-occupied', dialogue: [{ speaker: 'روژ', text: 'مردم این ساختمان هنوز تخلیه نشده‌اند. اگر مهاجمان در را بشکنند، راه فرار ندارند.' }, { speaker: 'شدو', text: 'به آن‌ها بگو عقب بمانند. من از در محافظت می‌کنم.' }], radio: { speaker: 'روژ', text: 'گروه آخر به پل رسیده است. فقط کمی دیگر.' } },
      { type: 'interact', title: 'خاموش کردن فرستنده‌ها', detail: 'سه فرستندهٔ مهاجمان روی پل را از کار بینداز.', target: 3, scene: 'city-bridge', dialogue: [{ speaker: 'اُمگا', text: 'فرستنده‌ها نیروهای بلک آرمز را هدایت می‌کنند. حذف سه نقطه، مسیر دنباله‌دار را باز می‌کند.' }, { speaker: 'شدو', text: 'هر سه را خاموش می‌کنم. وقت تمام کردن این حمله است.' }] },
      { type: 'collect', title: 'سنگی میان تاریکی', detail: '۲۰ محافظ را شکست بده و امرالد بنفش را پیش از بلک دووم بردار.', target: 1, guards: 20, emeralds: [4], scene: 'city-occupied', dialogue: [{ speaker: 'بلک دووم', text: 'آن سنگ به من تعلق دارد. بدون من هیچ بودی.' }, { speaker: 'شدو', text: 'ارزش من را گذشته‌ام تعیین نمی‌کند. این امرالد برای نجات زمین است.' }] },
      { type: 'survive', title: 'موج انتقام بلک آرمز', detail: '۸۵ ثانیه در برابر ضدحملهٔ ارتش تاریکی مقاومت کن.', target: 85, scene: 'city-occupied', dialogue: [{ speaker: 'روژ', text: 'فرمانده تمام نیروهایش را فرستاده. می‌خواهد قبل از رسیدن به دنباله‌دار ما را متوقف کند.' }, { speaker: 'شدو', text: 'پس فرصت دیگری برای فرار به آن‌ها نمی‌دهم.' }], radio: { speaker: 'اُمگا', text: 'نیروهای دشمن کاهش یافتند. فرمانده در حال ورود است.' } },
      { type: 'boss', title: 'فرماندهٔ بلک آرمز', detail: 'خود فرمانده را شکست بده؛ پیروزی با نابودی سربازها به دست نمی‌آید.', target: 1, boss: 'commander', scene: 'city-occupied', dialogue: [{ speaker: 'راوی', text: 'فرماندهٔ بلک آرمز آخرین مانع رسیدن به کشتی مهاجمان است. زمین هنوز زیر سایهٔ دنباله‌دار قرار دارد.' }, { speaker: 'شدو', text: 'تمامش می‌کنم. بعد نوبت خود بلک دووم است.' }] },
    ],
  },
  {
    id: 4,
    title: 'من، شدو هستم',
    subtitle: 'گذشته دیگر فرمان نمی‌دهد',
    location: 'قلب دنباله‌دار سیاه',
    paragraphs: [
      'بلک دووم نقشهٔ واقعی خود را آشکار کرد: زمین و انسان‌هایش باید قربانی ارتش او می‌شدند. شدو در برابر کنترل او مقاومت کرد. قدرت امرالدها، ارادهٔ خودش و قولی که به ماریا داده بود، راه پیروزی را نشان دادند.',
      'در این نبرد نهایی، دو امرالد آخر را بردار، ارتش تاریکی را پشت سر بگذار و با بلک دووم روبه‌رو شو. با هر هفت امرالد، شدو می‌تواند به سوپر شدو تبدیل شود و سرنوشت زمین را تغییر دهد.',
    ],
    mission: 'هفت امرالد را کامل کن، نیروی تاریکی را در هم بشکن و بلک دووم را شکست بده.',
    arena: 'city',
    faction: 'arms',
    estimatedMinutes: '۸ تا ۱۲',
    epilogue: 'بلک دووم در برابر ارادهٔ شدو شکست خورد. هفت امرالد درخشیدند و خطر دنباله‌دار سیاه از زمین دور شد. شدو دیگر به دنبال اجازهٔ گذشته نبود: «من، شدو خارپشت هستم.» در سکوت، قول ماریا زنده ماند.',
    stages: [
      { type: 'survive', title: 'فرود روی دنباله‌دار سیاه', detail: '۱۰۰ ثانیه روی سطح دنباله‌دار زنده بمان تا راه هسته پیدا شود.', target: 100, scene: 'comet-surface', dialogue: [{ speaker: 'روژ', text: 'ارتباط از اینجا ضعیف می‌شود. شدو، اگر وارد شوی شاید نتوانیم کمکت کنیم.' }, { speaker: 'شدو', text: 'زمین هنوز منتظر ماست. من برمی‌گردم.' }], radio: { speaker: 'روژ', text: 'یک شکاف انرژی در سطح پیدا شد. راه هسته از همان‌جا می‌گذرد.' } },
      { type: 'eliminate', title: 'شکستن نگهبانان پوسته', detail: '۴۸ نگهبان پوستهٔ دنباله‌دار را نابود کن.', target: 48, scene: 'comet-surface', dialogue: [{ speaker: 'بلک دووم', text: 'اینجا قلمرو من است. راهی برای بازگشت نداری.' }, { speaker: 'شدو', text: 'برای بازگشت نیامده‌ام. برای پایان دادن به این جنگ آمده‌ام.' }] },
      { type: 'interact', title: 'قلب زندهٔ دنباله‌دار', detail: 'چهار گرهٔ انرژی هسته را با ایستادن در محدوده‌شان خاموش کن.', target: 4, scene: 'comet-core', dialogue: [{ speaker: 'راوی', text: 'هسته مثل موجودی زنده می‌تپد. چهار گره، قدرت تالار بلک دووم را تغذیه می‌کنند.' }, { speaker: 'شدو', text: 'اگر راه باز نمی‌شود، من خودم آن را باز می‌کنم.' }] },
      { type: 'collect', title: 'کامل شدن هفت امرالد', detail: '۲۲ نگهبان هسته را شکست بده؛ سپس امرالد لاجوردی و قرمز را بردار.', target: 2, guards: 22, emeralds: [5, 6], scene: 'comet-core', dialogue: [{ speaker: 'بلک دووم', text: 'با هفت امرالد، قدرت تو متعلق به من خواهد بود.' }, { speaker: 'شدو', text: 'نه. با هفت امرالد، قولی را که به ماریا دادم نگه می‌دارم.' }] },
      { type: 'survive', title: 'مقاومت در برابر کنترل ذهن', detail: '۹۰ ثانیه در برابر ارتش هسته مقاومت کن و اختیار خودت را نگه دار.', target: 90, scene: 'comet-core', dialogue: [{ speaker: 'بلک دووم', text: 'صدای مرا در ذهنت می‌شنوی. مقاومت فایده‌ای ندارد؛ تو بخشی از من هستی.' }, { speaker: 'شدو', text: 'من ساختهٔ تو نیستم. انتخابم از آن خودم است.' }], radio: { speaker: 'خاطرهٔ ماریا', text: 'به آن‌ها فرصتی بده، شدو... برای خوشبختی.' } },
      { type: 'interact', title: 'باز کردن تالار تاریکی', detail: 'سه مهر تالار را بشکن و مسیر رویارویی با خود بلک دووم را باز کن.', target: 3, scene: 'doom-throne', dialogue: [{ speaker: 'راوی', text: 'تالار در برابر شدو گشوده می‌شود. این بار خبری از جانشین یا فرمانده نیست؛ خود بلک دووم منتظر است.' }, { speaker: 'شدو', text: 'این آخرین مانع است. حالا فقط من و او.' }] },
      { type: 'boss', title: 'رویارویی با خود بلک دووم', detail: 'خود بلک دووم را در سه فاز نبرد شکست بده؛ از حمله‌های نشان‌دار جاخالی بده.', target: 1, boss: 'black-doom', scene: 'doom-throne', dialogue: [{ speaker: 'بلک دووم', text: 'من بلک دووم هستم. این دنیا را می‌گیرم، حتی اگر مجبور شوم تو را از میان بردارم.' }, { speaker: 'شدو', text: 'من، شدو خارپشت هستم. نه تو، نه گذشته‌ام، سرنوشت من را تعیین نمی‌کنید.' }] },
    ],
    finale: [
      { speaker: 'بلک دووم', text: 'غیرممکن است... من از تو ساخته شدم، تو از من! اگر من نابود شوم، تو هم... تو هم چیزی برای ماندن نداری!' },
      { speaker: 'شدو', text: 'اشتباه می‌کنی. من چیزی برای ماندن دارم؛ قولی که پنجاه سال پیش داده شد.' },
      { speaker: 'راوی', text: 'آخرین فریاد بلک دووم در تالار پیچید و در نور هفت امرالد محو شد. دنباله‌دار سیاه از هم پاشید و آسمان زمین، برای اولین بار بعد از روزها، دوباره آرام شد.' },
      { speaker: 'خاطرهٔ ماریا', text: 'شدو... به آن‌ها فرصتی بده. برای خوشبختی. این تنها خواستهٔ من بود.' },
      { speaker: 'شدو', text: 'قولت را نگه داشتم، ماریا. حالا دیگر نه خاطرات، نه خون بلک دووم؛ هیچ‌کدام تعیین نمی‌کنند من که هستم.' },
      { speaker: 'روژ', text: 'شدو، صدای ما را می‌شنوی؟ دنباله‌دار نابود شد... تو موفق شدی.' },
      { speaker: 'اُمگا', text: 'تهدید حذف شد. وضعیت زمین: امن. وضعیت شدو خارپشت: قهرمان.' },
      { speaker: 'شدو', text: 'من فقط کاری را کردم که باید می‌کردم. من، شدو خارپشت هستم... و این انتخاب خودم بود.' },
      { speaker: 'راوی', text: 'سایه‌ای که زمانی فقط برای جنگیدن ساخته شده بود، حالا نگهبان همان دنیایی شد که ماریا دوستش داشت. پایان یک داستان، آغاز یک انتخاب تازه.' },
    ],
  },
];

export const superShadow = {
  name: 'سوپر شدو',
  english: 'SUPER SHADOW',
  duration: 40,
  cooldown: 3,
  description: 'وقتی هر هفت کیاس امرالد در اختیار توست و انرژی کیاس کامل است، شدو برای ۴۰ ثانیه به فرم طلایی خود تبدیل می‌شود: آسیب‌ناپذیر، سریع‌تر، با شلیک دو برابر قوی‌تر و قدرت‌های کیاس رایگان. پس از پایان فرم، ۳ ثانیه طول می‌کشد تا دوباره آمادهٔ تبدیل شدن شوی.',
};

export const chaosTeleport = {
  name: 'تله‌پورت کیاس',
  key: 'T',
  range: 320,
  cooldown: 0.5,
  cost: 20,
  color: '#bb9bff',
  protection: .4,
  description: 'با کلید T به سمت نشانه‌گیر جابه‌جا شو. روی موبایل، جهت جوی‌استیک را نگه دار و دکمهٔ تله‌پورت را بزن؛ بدون جهت، به سمت روبه‌روی شدو می‌روی. هر بار ۲۰ انرژی مصرف می‌کند و فقط ۰٫۵ ثانیه (نیم ثانیه) بازیابی دارد؛ در فرم سوپر رایگان است.',
};

export const doomPowers: { id: DoomPower; name: string; shortName: string; english: string; key: string; color: string; cooldown: number; form: boolean; description: string }[] = [
  { id: 'spear', name: 'دووم اسپیزر', shortName: 'اسپیزر', english: 'DOOM SPEARS', key: '1', color: '#ffd36f', cooldown: .75, form: false, description: 'تا پنج دشمن را هم‌زمان قفل و با نیزه‌های تعقیب‌کنندهٔ دووم هدف بگیر. دشمنان عادی برای لحظه‌ای متوقف می‌شوند. کلید ۱ را نگه دار تا حمله تکرار شود؛ بازیابی فقط ۰٫۷۵ ثانیه است.' },
  { id: 'morph', name: 'دووم مورف', shortName: 'مورف', english: 'DOOM MORPH', key: '2', color: '#c796ff', cooldown: 0, form: true, description: 'به موجودی سیال و شاخک‌دار تبدیل شو. در این میدان دوبعدی، شلیک با شاخک‌ها تا چهار دشمن را هم‌زمان می‌گیرد، به سمت تو می‌کشد و آسیب می‌زند. سرعت بیشتر و ۶۵٪ کاهش آسیب داری؛ دوباره ۲ را بزن تا برگردی.' },
  { id: 'surf', name: 'دووم سورف', shortName: 'سورف', english: 'DOOM SURF', key: '3', color: '#69dfd3', cooldown: 0, form: true, description: 'روی سازه‌ای شبیه سفره‌ماهی سوار شو؛ در این نسخه روی همهٔ کف‌های میدان قابل استفاده است. سریع‌تر حرکت کن و با Shift حملهٔ چرخشی بزن، دشمنان را عقب بران و تیرهای نزدیک را برگردان. دوباره ۳، فرم را خاموش می‌کند.' },
  { id: 'blast', name: 'دووم بلست', shortName: 'بلست', english: 'DOOM BLAST', key: '4', color: '#ff835f', cooldown: 1.5, form: false, description: 'به دشمن نزدیک شو و با یک ضربه او را به پرتابه تبدیل کن؛ برخوردش به دشمنان دیگر انفجار ایجاد می‌کند. باس‌ها به‌جای پرتاب شدن، ضربهٔ سنگین می‌خورند. بدون مصرف انرژی، با بازیابی ۱٫۵ ثانیه.' },
  { id: 'wing', name: 'دووم وینگ', shortName: 'وینگ', english: 'DOOM WING', key: '5', color: '#ed789b', cooldown: 0, form: true, description: 'بال‌های سیاه باز می‌شوند و شدو بالای میدان پرواز می‌کند: آسیب‌ناپذیر، سریع و با برخورد تهاجمی. پرواز نه زمان محدود دارد، نه انرژی مصرف می‌کند. با ۵ فرود بیا؛ سوپر شدو هم می‌تواند هم‌زمان فعال باشد.' },
];

export const doomRules = 'هر پنج دووم پاور از شروع بازی در هر دو حالت آزاد و بدون مصرف انرژی هستند. مورف، سورف و وینگ تا خاموش کردن فعال می‌مانند؛ فقط یکی از این سه فرم هم‌زمان فعال است. حمله‌ها در تمام فرم‌ها و همراه سوپر شدو قابل استفاده‌اند.';

export interface Session {
  id: number;
  mode: GameMode;
  chapter: number;
  settings: Settings;
  emeralds: number[];
  startStage?: number;
}

export interface StoryCheckpoint {
  chapter: number;
  stage: number;
  emeralds: number[];
  savedAt: string;
  version: number;
}

export const campaignVersion = 2;

export interface GameResult {
  mode: GameMode;
  chapter: number;
  victory: boolean;
  score: number;
  kills: number;
  wave: number;
  duration: number;
  bossKills: number;
  difficulty: Difficulty;
  emeralds: number[];
  superUsed: boolean;
}

export interface Progress {
  completedChapters: number;
  bestScore: number;
  bestWave: number;
  totalKills: number;
  gamesPlayed: number;
  bossKills: number;
  emeralds: number[];
  superUses: number;
  checkpoints: Record<string, StoryCheckpoint>;
  runs: (GameResult & { date: string })[];
}

export const defaultSettings: Settings = {
  sound: true,
  difficulty: 'normal',
  screenShake: true,
  autoAim: true,
};

export const emptyProgress: Progress = {
  completedChapters: 0,
  bestScore: 0,
  bestWave: 0,
  totalKills: 0,
  gamesPlayed: 0,
  bossKills: 0,
  emeralds: [],
  superUses: 0,
  checkpoints: {},
  runs: [],
};

export const difficultyLabels: Record<Difficulty, string> = {
  easy: 'آسان',
  normal: 'معمولی',
  hard: 'سخت',
};

export const stageLabels: Record<StageType, string> = {
  eliminate: 'نابودسازی',
  survive: 'مقاومت',
  collect: 'جمع‌آوری امرالد',
  defend: 'محافظت',
  boss: 'نبرد با فرمانده',
  interact: 'فعال‌سازی نقاط',
  reach: 'رسیدن به خروج',
};

export const powers: { id: Power; name: string; english: string; key: string; color: string; cost: number; description: string }[] = [
  { id: 'spear', name: 'نیزهٔ کیاس', english: 'CHAOS SPEAR', key: 'Q', color: '#9deb72', cost: 22, description: 'پنج نیزهٔ انرژی به سمت هدف پرتاب کن؛ نیزه‌ها از دشمن عبور می‌کنند و آسیب زیادی وارد می‌کنند.' },
  { id: 'control', name: 'کنترل کیاس', english: 'CHAOS CONTROL', key: 'E', color: '#6ecfff', cost: 38, description: 'زمان را برای دشمنان و تیرهایشان به مدت پنج ثانیه کند کن؛ تو همچنان با سرعت کامل حرکت می‌کنی.' },
  { id: 'blast', name: 'انفجار کیاس', english: 'CHAOS BLAST', key: 'R', color: '#fb424b', cost: 65, description: 'موجی از انرژی آشوب آزاد کن و تمام دشمنان اطرافت را با یک انفجار قدرتمند در هم بکوب.' },
];

export const fa = (value: number) => Math.floor(value).toLocaleString('fa-IR');

export function readSaved<T extends object>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (!saved) return fallback;
    const parsed: unknown = JSON.parse(saved);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...fallback, ...parsed } : fallback;
  } catch {
    return fallback;
  }
}

export function loadSettings(): Settings {
  const saved = readSaved('shadow-settings-v1', defaultSettings);
  return {
    sound: typeof saved.sound === 'boolean' ? saved.sound : defaultSettings.sound,
    screenShake: typeof saved.screenShake === 'boolean' ? saved.screenShake : defaultSettings.screenShake,
    autoAim: typeof saved.autoAim === 'boolean' ? saved.autoAim : defaultSettings.autoAim,
    difficulty: ['easy', 'normal', 'hard'].includes(saved.difficulty) ? saved.difficulty : 'normal',
  };
}

const nonNegative = (value: unknown, max = Number.MAX_SAFE_INTEGER) => typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(0, Math.floor(value))) : 0;

export const cleanEmeralds = (value: unknown): number[] => Array.isArray(value)
  ? [...new Set(value.filter(id => typeof id === 'number' && Number.isInteger(id) && id >= 0 && id < emeralds.length))].sort((a, b) => a - b)
  : [];

function validRun(value: unknown): value is Progress['runs'][number] {
  if (!value || typeof value !== 'object') return false;
  const run = value as Partial<Progress['runs'][number]>;
  return (run.mode === 'story' || run.mode === 'survival')
    && typeof run.chapter === 'number' && Number.isInteger(run.chapter) && run.chapter >= 0 && run.chapter < chapters.length
    && typeof run.victory === 'boolean'
    && ['easy', 'normal', 'hard'].includes(run.difficulty ?? '')
    && [run.score, run.kills, run.wave, run.duration, run.bossKills].every(n => typeof n === 'number' && Number.isFinite(n) && n >= 0)
    && typeof run.date === 'string' && Number.isFinite(Date.parse(run.date));
}

export function loadProgress(): Progress {
  const saved = readSaved('shadow-progress-v1', emptyProgress);
  const completedChapters = nonNegative(saved.completedChapters, chapters.length);
  const checkpoints: Record<string, StoryCheckpoint> = {};
  if (saved.checkpoints && typeof saved.checkpoints === 'object') {
    Object.values(saved.checkpoints).forEach(value => {
      if (!value || typeof value !== 'object') return;
      const checkpoint = value as Partial<StoryCheckpoint>;
      const chapter = chapters[checkpoint.chapter ?? -1];
      if (!chapter || checkpoint.version !== campaignVersion || typeof checkpoint.stage !== 'number'
        || !Number.isInteger(checkpoint.stage) || checkpoint.stage < 0 || checkpoint.stage >= chapter.stages.length
        || typeof checkpoint.savedAt !== 'string' || !Number.isFinite(Date.parse(checkpoint.savedAt))) return;
      checkpoints[String(chapter.id)] = { chapter: chapter.id, stage: checkpoint.stage, emeralds: cleanEmeralds(checkpoint.emeralds), savedAt: checkpoint.savedAt, version: campaignVersion };
    });
  }
  const previouslyEarned = chapters.slice(0, completedChapters).flatMap(chapter => chapter.stages.flatMap(stage => stage.emeralds ?? []));
  return {
    completedChapters,
    bestScore: nonNegative(saved.bestScore),
    bestWave: nonNegative(saved.bestWave),
    totalKills: nonNegative(saved.totalKills),
    gamesPlayed: nonNegative(saved.gamesPlayed),
    bossKills: nonNegative(saved.bossKills),
    emeralds: cleanEmeralds([...cleanEmeralds(saved.emeralds), ...previouslyEarned]),
    superUses: nonNegative(saved.superUses),
    checkpoints,
    runs: Array.isArray(saved.runs) ? saved.runs.filter(validRun).map(run => ({ ...run, emeralds: cleanEmeralds(run.emeralds), superUsed: run.superUsed === true })).slice(0, 10) : [],
  };
}

export function saveLocal(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // The game still works when browser storage is unavailable.
  }
}
