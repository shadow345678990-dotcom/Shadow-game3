import hero from '../public/images/shadow-hero.png?inline';
import logo from '../public/images/shadow-logo.png?inline';
import story from '../public/images/story-ark.png?inline';
import blackDoom from '../public/images/black-doom.png?inline';
import superShadow from '../public/images/super-shadow.png?inline';
import arkLab from '../public/images/arena-ark-lab.jpg?inline';
import arkHangar from '../public/images/arena-ark-hangar.jpg?inline';
import city from '../public/images/arena-central-city.jpg?inline';
import comet from '../public/images/arena-black-comet.jpg?inline';
import favicon from '../public/favicon.svg?inline';

// Inline the original files so the exported HTML needs no asset folder.
export const gameAssets = { hero, logo, story, blackDoom, superShadow, arkLab, arkHangar, city, comet, favicon };