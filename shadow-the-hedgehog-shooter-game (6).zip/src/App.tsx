import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowUpLeft, BookOpen, Check, ChevronLeft, Crosshair, Flame, Gamepad2, Gem, HelpCircle, Lock, Orbit, Play, Settings2, Shield, Sparkles, Target, Timer, Trash2, Trophy, Volume2, VolumeX, Zap } from 'lucide-react';
import Game from './components/Game';
import Modal from './components/Modal';
import { Emerald, ShadowMark } from './components/Visuals';
import { chaosTeleport, chapters, cleanEmeralds, difficultyLabels, emeralds, emptyProgress, fa, loadProgress, loadSettings, powers, saveLocal, stageLabels, superShadow, type Difficulty, type GameMode, type GameResult, type Power, type Progress, type Session, type Settings, type StoryCheckpoint } from './data';
import { unlockAudio } from './game/audio';
import { worlds } from './game/arenas';
import { gameAssets } from './assets';
import DoomPowerIcon from './components/DoomPowerIcon';
import { DoomPowerGuide } from './components/DoomPowers';

type Dialog = 'modes' | 'story' | 'settings' | 'controls' | 'achievements' | 'records' | 'power' | 'super' | 'doom' | null;
type Section = 'home' | 'modes' | 'powers' | 'emeralds';
const reveal = { initial: { opacity: 0, y: 22 }, animate: { opacity: 1, y: 0 } };

function Toggle({ active, onChange, label }: { active: boolean; onChange: () => void; label: string }) {
  return <button type="button" className={`toggle ${active ? 'toggle-on' : ''}`} role="switch" aria-checked={active} aria-label={label} onClick={onChange}><span /></button>;
}

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [progress, setProgress] = useState<Progress>(loadProgress);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [activeSection, setActiveSection] = useState<Section>('home');
  const [selectedChapter, setSelectedChapter] = useState(0);
  const [selectedPower, setSelectedPower] = useState<Power>('spear');
  const [session, setSession] = useState<Session | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const sessionId = useRef(0);
  const closeDialog = useCallback(() => { setDialog(null); setConfirmReset(false); }, []);

  useEffect(() => { saveLocal('shadow-settings-v1', settings); }, [settings]);
  useEffect(() => { saveLocal('shadow-progress-v1', progress); }, [progress]);

  const navigate = (section: Section) => {
    setActiveSection(section);
    const anchors: Record<Section, string> = { home: 'home', modes: 'game-modes', powers: 'chaos-powers', emeralds: 'chaos-emeralds' };
    document.getElementById(anchors[section])?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const openStory = () => {
    setSelectedChapter(Math.min(progress.completedChapters, chapters.length - 1));
    setDialog('story');
  };

  const startGame = (mode: GameMode, chapter = 0, fromBeginning = false) => {
    if (settings.sound) unlockAudio();
    sessionId.current++;
    setDialog(null);
    setConfirmReset(false);
    const checkpoint = mode === 'story' && !fromBeginning ? progress.checkpoints[String(chapter)] : undefined;
    setSession({ id: sessionId.current, mode, chapter, settings: { ...settings }, emeralds: cleanEmeralds([...progress.emeralds, ...(checkpoint?.emeralds ?? [])]), startStage: checkpoint?.stage ?? 0 });
  };

  const recordCheckpoint = useCallback((checkpoint: StoryCheckpoint) => {
    setProgress(previous => ({ ...previous, emeralds: cleanEmeralds([...previous.emeralds, ...checkpoint.emeralds]), checkpoints: { ...previous.checkpoints, [String(checkpoint.chapter)]: checkpoint } }));
  }, []);

  const recordResult = useCallback((result: GameResult) => {
    setProgress(previous => {
      const checkpoints = { ...previous.checkpoints };
      if (result.mode === 'story' && result.victory) delete checkpoints[String(result.chapter)];
      return {
        ...previous,
        completedChapters: result.mode === 'story' && result.victory ? Math.max(previous.completedChapters, result.chapter + 1) : previous.completedChapters,
        bestScore: result.mode === 'survival' ? Math.max(previous.bestScore, result.score) : previous.bestScore,
        bestWave: result.mode === 'survival' ? Math.max(previous.bestWave, result.wave) : previous.bestWave,
        totalKills: previous.totalKills + result.kills,
        gamesPlayed: previous.gamesPlayed + 1,
        bossKills: previous.bossKills + result.bossKills,
        emeralds: cleanEmeralds([...previous.emeralds, ...result.emeralds]),
        superUses: previous.superUses + (result.superUsed ? 1 : 0),
        checkpoints,
        runs: [{ ...result, date: new Date().toISOString() }, ...previous.runs].slice(0, 10),
      };
    });
  }, []);

  const toggleSound = () => {
    if (!settings.sound) unlockAudio();
    setSettings(previous => ({ ...previous, sound: !previous.sound }));
  };

  const chapter = chapters[selectedChapter];
  const checkpoint = progress.checkpoints[String(selectedChapter)];
  const power = powers.find(item => item.id === selectedPower)!;
  const achievements = [
    { title: 'اولین جرقه', description: 'اولین دشمن را شکست بده.', unlocked: progress.totalKills >= 1, Icon: Zap },
    { title: 'شکارچی ربات‌ها', description: 'در مجموع ۱۰۰ دشمن را از میان بردار.', unlocked: progress.totalKills >= 100, Icon: Crosshair },
    { title: 'خاطره‌ای از آرک', description: 'اولین فصل داستانی را کامل کن.', unlocked: progress.completedChapters >= 1, Icon: BookOpen },
    { title: 'توقف‌ناپذیر', description: 'در نبرد آزاد به موج پنجم برس.', unlocked: progress.bestWave >= 5, Icon: Flame },
    { title: 'شکست تاریکی', description: 'یک فرماندهٔ بلک آرمز را شکست بده.', unlocked: progress.bossKills >= 1, Icon: Shield },
    { title: 'جمع‌کنندهٔ امرالد', description: 'اولین کیاس امرالد را به دست بیاور.', unlocked: progress.emeralds.length >= 1, Icon: Gem },
    { title: 'هفت سنگ سرنوشت', description: 'هر هفت کیاس امرالد را جمع کن.', unlocked: progress.emeralds.length >= 7, Icon: Sparkles },
    { title: 'فرم طلایی', description: 'یک بار به سوپر شدو تبدیل شو.', unlocked: progress.superUses >= 1, Icon: Flame },
    { title: 'من، شدو هستم', description: 'هر پنج فصل داستان را به پایان برسان.', unlocked: progress.completedChapters >= 5, Icon: Trophy },
  ];

  if (session) {
    return <Game key={session.id} session={session} onExit={() => { setSession(null); setActiveSection('home'); }} onRestart={() => startGame(session.mode, session.chapter)} onNext={() => { setSelectedChapter(Math.min(session.chapter + 1, 4)); setSession(null); setDialog('story'); }} onResult={recordResult} onCheckpoint={recordCheckpoint} onSoundChange={enabled => setSettings(previous => ({ ...previous, sound: enabled }))} />;
  }

  return (
    <div className="app-shell" id="home">
      <aside className="rail" aria-label="ناوبری اصلی">
        <button className="rail-logo" onClick={() => navigate('home')} aria-label="خانه"><img src={gameAssets.logo} alt="لوگوی بازی شدو خارپشت" /></button>
        <div className="rail-navigation">
          <button className={`rail-button ${activeSection === 'home' ? 'rail-active' : ''}`} onClick={() => navigate('home')} aria-label="پایگاه بازی"><Gamepad2 size={22} /><span>پایگاه بازی</span></button>
          <button className="rail-button" onClick={openStory} aria-label="داستان شدو"><BookOpen size={21} /><span>داستان شدو</span></button>
          <button className={`rail-button ${activeSection === 'modes' ? 'rail-active' : ''}`} onClick={() => navigate('modes')} aria-label="حالت‌های بازی"><Crosshair size={22} /><span>حالت‌های بازی</span></button>
          <button className={`rail-button ${activeSection === 'powers' ? 'rail-active' : ''}`} onClick={() => navigate('powers')} aria-label="قدرت‌های کیاس"><Gem size={21} /><span>قدرت‌های کیاس</span></button>
          <button className="rail-button" onClick={() => setDialog('doom')} aria-label="منوی دووم پاورها"><DoomPowerIcon power="wing" size={22} /><span>منوی دووم پاورها</span></button>
          <button className={`rail-button ${activeSection === 'emeralds' ? 'rail-active' : ''}`} onClick={() => navigate('emeralds')} aria-label="هفت امرالد و سوپر شدو"><Sparkles size={21} /><span>امرالدها و سوپر شدو</span></button>
          <div className="rail-divider" />
          <button className="rail-button" onClick={() => setDialog('achievements')} aria-label="دستاوردها"><Trophy size={21} /><span>دستاوردها</span></button>
        </div>
        <div className="rail-bottom">
          <button className="rail-button" onClick={() => setDialog('controls')} aria-label="راهنمای بازی"><HelpCircle size={20} /><span>راهنمای بازی</span></button>
          <button className="rail-button" onClick={toggleSound} aria-label={settings.sound ? 'قطع صدا' : 'فعال کردن صدا'}>{settings.sound ? <Volume2 size={20} /> : <VolumeX size={20} />}<span>{settings.sound ? 'قطع صدا' : 'فعال کردن صدا'}</span></button>
          <button className="rail-button" onClick={() => setDialog('settings')} aria-label="تنظیمات"><Settings2 size={20} /><span>تنظیمات</span></button>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button className="wordmark" onClick={() => navigate('home')} aria-label="خانه شدو">SHADOW<span className="wordmark-dot" /></button>
          <span className="topbar-tagline">THE ULTIMATE LIFE FORM</span>
          <nav className="top-navigation" dir="rtl" aria-label="بخش‌های بازی">
            <button className={activeSection === 'home' ? 'nav-active' : ''} onClick={() => navigate('home')}>خانه</button>
            <button className={activeSection === 'modes' ? 'nav-active' : ''} onClick={() => navigate('modes')}>حالت‌های بازی</button>
            <button className={activeSection === 'powers' ? 'nav-active' : ''} onClick={() => navigate('powers')}>قدرت‌های کیاس</button>
            <button className={activeSection === 'emeralds' ? 'nav-active' : ''} onClick={() => navigate('emeralds')}>امرالدها</button>
            <button onClick={() => setDialog('records')}>رکوردها</button>
          </nav>
          <button className="profile-button" onClick={() => setDialog('records')} aria-label="رکوردهای بازیکن"><span className="profile-avatar">S</span><span className="profile-name" dir="rtl">بازیکن ۰۱<small><span />آمادهٔ نبرد</small></span></button>
          <button className="mobile-settings icon-button" onClick={() => setDialog('settings')} aria-label="تنظیمات"><Settings2 size={21} /></button>
        </header>

        <section className="hero" aria-label="شدو: قدرت آشوب">
          <motion.img className="hero-image" src={gameAssets.hero} alt="شدو خارپشت با سلاح و انرژی کیاس در شهری با آسمان سرخ" initial={{ scale: 1.045, opacity: .5 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1.8, ease: 'easeOut' }} fetchPriority="high" />
          <div className="hero-shade" />
          <div className="hero-atmosphere" aria-hidden="true"><span /><span /><span /><span /><span /></div>
          <div className="hero-content">
            <motion.div className="hero-eyebrow" dir="rtl" {...reveal} transition={{ duration: .7, delay: .1 }}><span />فراتر از یک قهرمان</motion.div>
            <motion.div className="hero-brand" {...reveal} transition={{ duration: .8, delay: .2 }}><h1>SHADOW</h1><span>CHAOS UNLEASHED</span></motion.div>
            <motion.div className="hero-copy" dir="rtl" {...reveal} transition={{ duration: .7, delay: .35 }}><h2>گذشته‌ات را پیدا کن.<br />قدرتت را آزاد کن.</h2><p>از خاطرات آرک تا نبرد با بلک دووم؛<br />این بار، سرنوشت شدو در دستان توست.</p></motion.div>
            <motion.div className="hero-actions" dir="rtl" {...reveal} transition={{ duration: .7, delay: .5 }}><button className="button button-primary" onClick={() => setDialog('modes')}><Play size={17} fill="currentColor" />شروع بازی<ArrowUpLeft size={19} /></button><button className="button button-secondary" onClick={() => setDialog('controls')}><Gamepad2 size={19} />راهنمای بازی</button></motion.div>
          </div>
          <div className="hero-bottom-line" />
        </section>

        <section className="modes-section section-container" id="game-modes">
          <div className="section-heading"><span className="section-index">01 <i /> CHOOSE YOUR PATH</span><div dir="rtl"><h2>مسیرت را انتخاب کن<span>.</span></h2><p>یک گذشته برای کشف کردن. یک میدان برای جنگیدن.</p></div></div>
          <div className="mode-grid">
            <motion.button className="mode-card story-card" onClick={openStory} whileHover={{ y: -4 }} whileTap={{ scale: .995 }} transition={{ duration: .25 }}>
              <img src={gameAssets.story} alt="ایستگاه فضایی آرک در مدار زمین" loading="lazy" /><span className="mode-card-shade" /><div className="mode-card-copy" dir="rtl"><span className="mode-label"><BookOpen size={13} />STORY MODE</span><h3>حالت داستانی</h3><p>هر خاطره، بخشی از حقیقت.<br />داستان زندگی شدو را تجربه کن.</p><span className="mode-link">{progress.completedChapters > 0 && progress.completedChapters < 5 ? 'ادامهٔ داستان' : 'ورود به داستان'}<ArrowUpLeft size={17} /></span></div><span className="mode-card-number">01</span>
            </motion.button>
            <motion.button className="mode-card survival-card" onClick={() => startGame('survival')} whileHover={{ y: -4 }} whileTap={{ scale: .995 }} transition={{ duration: .25 }}>
              <img src={gameAssets.blackDoom} alt="ارتش ربات‌ها و نیروهای بلک دووم" loading="lazy" /><span className="mode-card-shade" /><div className="mode-card-copy" dir="rtl"><span className="mode-label"><Crosshair size={13} />SURVIVAL MODE</span><h3>نبرد بی‌پایان</h3><p>موج‌های ربات‌ها و ارتش بلک دووم.<br />تا کجا دوام می‌آوری؟</p><span className="mode-link">شروع نبرد<ArrowUpLeft size={17} /></span></div><span className="mode-card-number">02</span>
            </motion.button>
          </div>
        </section>

        <section className="powers-section section-container" id="chaos-powers">
          <div className="section-heading"><span className="section-index">02 <i /> MASTER THE CHAOS</span><div dir="rtl"><h2>آشوب در دستان توست<span>.</span></h2><p>انرژی کیاس امرالدها را به سلاح خودت تبدیل کن.</p></div></div>
          <div className="powers-grid">{powers.map(item => <button className="power-item" key={item.id} style={{ '--power-color': item.color } as CSSProperties} onClick={() => { setSelectedPower(item.id); setDialog('power'); }}><div className="power-visual"><Emerald color={item.color} /><span /></div><div className="power-item-copy" dir="rtl"><span>{item.english}</span><h3>{item.name}</h3><p>{item.id === 'spear' ? 'انرژی را به یک ضربهٔ مرگبار تبدیل کن.' : item.id === 'control' ? 'زمان را خم کن. میدان را به دست بگیر.' : 'یک انفجار. هیچ‌کس در امان نیست.'}</p><span className="power-key"><kbd>{item.key}</kbd>جزئیات قدرت<ChevronLeft size={14} /></span></div></button>)}</div>
          <button className="doom-guide-launch" onClick={() => setDialog('doom')} dir="rtl"><DoomPowerIcon power="wing" size={25} /><div><strong>دووم پاورهای شدو</strong><span>پنج قدرت تازه. از همان شروع، بدون مصرف انرژی.</span></div><span className="doom-guide-launch-action">راهنمای قدرت‌ها<ChevronLeft size={16} /></span></button>
        </section>

        <section className="emerald-section section-container" id="chaos-emeralds">
          <div className="section-heading"><span className="section-index">03 <i /> SEVEN CHAOS EMERALDS</span><div dir="rtl"><h2>هفت امرالد، یک سرنوشت<span>.</span></h2><p>هر امرالد را در ماموریت‌های داستانی پیدا کن و فرم طلایی را آزاد کن.</p></div></div>
          <div className="emerald-layout">
            <div className="emerald-grid" role="list">
              {emeralds.map(emerald => {
                const owned = progress.emeralds.includes(emerald.id);
                return <div role="listitem" key={emerald.id} className={`emerald-card ${owned ? 'emerald-owned' : ''}`} style={{ '--gem': emerald.color } as CSSProperties} dir="rtl">
                  <Emerald color={owned ? emerald.color : '#5b5564'} />
                  <strong>{emerald.name}</strong>
                  <span>{owned ? emerald.gift : 'هنوز پیدا نشده'}</span>
                  {owned ? <Check size={14} className="emerald-check" /> : <Lock size={12} />}
                </div>;
              })}
            </div>
            <button className="super-card" onClick={() => setDialog('super')} dir="rtl">
              <img src={gameAssets.superShadow} alt="سوپر شدو در فرم طلایی با هفت کیاس امرالد" loading="lazy" />
              <span className="super-card-shade" />
              <div className="super-card-copy">
                <span className="mode-label"><Sparkles size={13} />{superShadow.english}</span>
                <h3>{superShadow.name}</h3>
                <p>با هر هفت امرالد و انرژی کامل، با کلید <kbd>F</kbd> به فرم طلایی تبدیل شو.</p>
                <div className="super-progress"><div><span style={{ width: `${progress.emeralds.length / 7 * 100}%` }} /></div><small>{fa(progress.emeralds.length)} از ۷ امرالد</small></div>
                <span className="mode-link">{progress.emeralds.length >= 7 ? 'آمادهٔ تبدیل شدن' : 'چگونه آزاد می‌شود؟'}<ArrowUpLeft size={17} /></span>
              </div>
            </button>
          </div>
        </section>

        <footer className="site-footer"><span className="footer-signature"><ShadowMark />A SHADOW FAN EXPERIENCE</span><p dir="rtl">ساخته‌شده برای طرفداران. شخصیت‌ها متعلق به SEGA هستند.</p><span className="footer-version">V. 1.0</span></footer>
      </main>

      <AnimatePresence mode="wait">
        {dialog === 'modes' && <Modal key="modes" title="برای کدام نبرد آماده‌ای؟" subtitle="CHOOSE YOUR PATH" onClose={closeDialog} wide>
          <p className="modal-intro">داستان شدو را دنبال کن یا مستقیم به دل آشوب برو.</p>
          <div className="dialog-mode-grid"><button className="dialog-mode" onClick={openStory}><img src={gameAssets.story} alt="ایستگاه آرک" /><div><BookOpen size={25} /><span className="overline">STORY MODE</span><h3>حالت داستانی</h3><p>{fa(chapters.length)} فصل و {fa(chapters.reduce((sum, item) => sum + item.stages.length, 0))} مرحله تا رویارویی با بلک دووم.</p><span className="mode-link">انتخاب فصل<ArrowLeft size={16} /></span></div></button><button className="dialog-mode" onClick={() => startGame('survival')}><img src={gameAssets.blackDoom} alt="نیروهای بلک دووم" /><div><Crosshair size={25} /><span className="overline">SURVIVAL MODE</span><h3>نبرد بی‌پایان</h3><p>موج‌های بی‌پایان. رکورد تازه. بدون توقف.</p><span className="mode-link">ورود به نبرد<ArrowLeft size={16} /></span></div></button></div>
          <div className="dialog-bottom-note"><Shield size={15} /><span>درجهٔ سختی: {difficultyLabels[settings.difficulty]}</span><button className="text-button" onClick={() => setDialog('settings')}>تغییر تنظیمات<Settings2 size={14} /></button></div>
        </Modal>}

        {dialog === 'story' && <Modal key="story" title="داستان یک سایه" subtitle="THE SHADOW CHRONICLES" onClose={closeDialog} wide>
          <div className="story-layout"><div className="chapter-list">{chapters.map(item => { const locked = item.id > progress.completedChapters; const completed = item.id < progress.completedChapters; return <button key={item.id} className={`chapter-button ${selectedChapter === item.id ? 'chapter-selected' : ''} ${locked ? 'chapter-locked' : ''}`} onClick={() => setSelectedChapter(item.id)} disabled={locked} title={locked ? 'ابتدا فصل قبلی را کامل کن' : item.title}><span className="chapter-number">{locked ? <Lock size={15} /> : completed ? <Check size={18} /> : `0${item.id + 1}`}</span><div><small>فصل {fa(item.id + 1)}</small><strong>{item.title}</strong></div><ChevronLeft size={15} /></button>; })}<div className="chapter-progress"><span>{fa(progress.completedChapters)} از ۵ فصل تکمیل شده</span><div className="chapter-progress-track"><span style={{ width: `${progress.completedChapters / 5 * 100}%` }} /></div></div></div>
            <article className="chapter-detail"><div className="chapter-art"><img src={worlds[chapter.stages[0].scene].image} alt={chapter.location} /><span>{chapter.location}</span></div><div className="chapter-content"><span className="overline">CHAPTER 0{chapter.id + 1}</span><h3>{chapter.title}</h3><p className="chapter-subtitle">{chapter.subtitle}</p><div className="chapter-length"><Timer size={13} /><span>{chapter.estimatedMinutes} دقیقه · {fa(chapter.stages.length)} مرحلهٔ داستانی</span></div>{chapter.paragraphs.map((paragraph, index) => <p className="story-paragraph" key={index}>{paragraph}</p>)}<div className="mission-note"><Target size={18} /><p>{chapter.mission}</p></div>
              <div className="stage-plan"><span className="stage-plan-title">مراحل ماموریت</span>{chapter.stages.map((stage, index) => <div className={`stage-row ${checkpoint?.stage === index ? 'stage-checkpoint' : ''}`} key={index}><span className="stage-step">{checkpoint && index < checkpoint.stage ? <Check size={12} /> : fa(index + 1)}</span><div><strong>{stage.title}</strong><span>{worlds[stage.scene].name}</span><span>{stage.detail}</span></div><span className="stage-tag">{stage.boss === 'black-doom' ? 'خود بلک دووم' : stageLabels[stage.type]}</span></div>)}{chapter.stages.some(stage => stage.type === 'collect') && <p className="stage-reward"><Gem size={14} />{chapter.stages.flatMap(stage => stage.emeralds ?? []).map(id => emeralds[id].name).join(' و ')} در این فصل به دست می‌آید.</p>}</div>
              {checkpoint && <p className="checkpoint-note"><Shield size={14} />ذخیرهٔ خودکار: مرحلهٔ {fa(checkpoint.stage + 1)}؛ مراحل قبلی دوباره تکرار نمی‌شوند.</p>}
              <button className="button button-primary" onClick={() => startGame('story', selectedChapter)}><Play size={16} fill="currentColor" />{checkpoint ? 'ادامه از نقطهٔ ذخیره' : 'شروع ماموریت'}<ArrowLeft size={17} /></button>
              {checkpoint && <button className="text-button chapter-restart" onClick={() => startGame('story', selectedChapter, true)}>شروع فصل از ابتدا</button>}
            </div></article>
          </div><p className="story-disclaimer">روایتی طرفداری بر پایهٔ گذشتهٔ شدو؛ ماموریت‌های مبارزه، بازآفرینی آزاد داستان هستند.</p>
        </Modal>}

        {dialog === 'controls' && <Modal key="controls" title="قبل از نبرد، آماده شو." subtitle="HOW TO PLAY" onClose={closeDialog}>
          <p className="modal-intro">حرکت کن، جاخالی بده و قدرت آشوب را آزاد کن.</p><div className="controls-list"><div><span><Gamepad2 size={19} />حرکت در میدان</span><kbd>W A S D / ARROWS</kbd></div><div><span><Crosshair size={19} />نشانه‌گیری و شلیک</span><kbd>MOUSE + CLICK</kbd></div><div><span><Target size={19} />شلیک با هدف‌گیری خودکار</span><kbd>SPACE</kbd></div><div><span><Zap size={19} />جهش سریع و جاخالی</span><kbd>SHIFT</kbd></div><div><span><Orbit size={19} />تله‌پورت به سمت نشانه‌گیر</span><kbd>{chaosTeleport.key}</kbd></div><div><span><Gem size={19} />نیزه / کنترل / انفجار کیاس</span><kbd>Q / E / R</kbd></div><div><span><Sparkles size={19} />تبدیل به سوپر شدو (۷ امرالد)</span><kbd>F</kbd></div><div><span><Timer size={19} />توقف و ادامهٔ بازی</span><kbd>ESC</kbd></div></div><div className="help-note"><Sparkles size={21} /><div><strong>کنترل هم‌زمان روی موبایل.</strong><p>با یک انگشت جوی‌استیک را نگه دار، با انگشت دوم شلیک کن و با انگشت سوم قدرت‌ها یا منوی دووم را بزن. لمس دکمه‌ها حرکت را قطع نمی‌کند.</p></div></div><p className="help-tip">{chaosTeleport.description}</p><p className="help-tip">امرالدهای سبز، انرژی کیاس را بازیابی می‌کنند. نشان‌های قرمز سلامتی می‌دهند. انرژی با گذر زمان و شکست دشمنان هم بیشتر می‌شود.</p><button className="button button-primary full-button" onClick={() => setDialog('modes')}><Play size={16} fill="currentColor" />آماده‌ام. شروع کنیم.</button>
          <button className="doom-controls-help" onClick={() => setDialog('doom')}><DoomPowerIcon power="wing" size={19} /><span>دووم پاورها با کلیدهای <kbd>1 - 5</kbd></span><ChevronLeft size={15} /></button>
        </Modal>}

        {dialog === 'settings' && <Modal key="settings" title="قوانین نبرد تو" subtitle="GAME SETTINGS" onClose={closeDialog}>
          <div className="settings-block"><h3>درجهٔ سختی</h3><div className="difficulty-options" role="group" aria-label="درجهٔ سختی">{(['easy', 'normal', 'hard'] as Difficulty[]).map((item, index) => <button key={item} className={settings.difficulty === item ? 'difficulty-selected' : ''} aria-pressed={settings.difficulty === item} onClick={() => setSettings(previous => ({ ...previous, difficulty: item }))}><span>0{index + 1}</span>{difficultyLabels[item]}{settings.difficulty === item && <Check size={15} />}</button>)}</div><p className="setting-hint">{settings.difficulty === 'easy' ? 'سلامتی بیشتر و دشمنان ضعیف‌تر؛ برای اولین تجربه.' : settings.difficulty === 'hard' ? 'سلامتی کمتر و دشمنان قوی‌تر؛ امتیاز بالاتر برای ریسک بیشتر.' : 'توازن بین چالش و قدرت؛ همان تجربهٔ واقعی شدو.'}</p></div>
          <div className="setting-row"><div><strong>صدای بازی</strong><p>افکت شلیک، نبرد و قدرت‌های کیاس</p></div><Toggle active={settings.sound} onChange={toggleSound} label="صدای بازی" /></div><div className="setting-row"><div><strong>لرزش صفحه</strong><p>بازخورد تصویری انفجار و برخورد</p></div><Toggle active={settings.screenShake} onChange={() => setSettings(previous => ({ ...previous, screenShake: !previous.screenShake }))} label="لرزش صفحه" /></div><div className="setting-row"><div><strong>هدف‌گیری کمکی</strong><p>با Space نزدیک‌ترین دشمن را هدف بگیر</p></div><Toggle active={settings.autoAim} onChange={() => setSettings(previous => ({ ...previous, autoAim: !previous.autoAim }))} label="هدف‌گیری کمکی" /></div><div className="settings-storage"><Shield size={17} /><p>تنظیمات، فصل‌های تکمیل‌شده و رکوردها به‌صورت خودکار در همین مرورگر ذخیره می‌شوند.</p></div>
          {confirmReset ? <div className="reset-confirm"><p>همهٔ پیشرفت‌ها و رکوردهای این مرورگر پاک شوند؟</p><button className="text-button danger-text" onClick={() => { setProgress({ ...emptyProgress, runs: [] }); setSelectedChapter(0); setConfirmReset(false); }}>بله، پاک کن</button><button className="text-button" onClick={() => setConfirmReset(false)}>انصراف</button></div> : <button className="text-button danger-text" onClick={() => setConfirmReset(true)}><Trash2 size={15} />پاک کردن پیشرفت بازی</button>}
          <div className="settings-links"><button className="text-button" onClick={() => setDialog('achievements')}><Trophy size={15} />دستاوردهای من</button><button className="text-button" onClick={() => setDialog('records')}><Crosshair size={15} />رکوردهای من</button></div>
        </Modal>}

        {dialog === 'achievements' && <Modal key="achievements" title="نامت را در تاریکی حک کن." subtitle="ACHIEVEMENTS" onClose={closeDialog}>
          <div className="achievement-summary"><span>دستاوردهای بازشده</span><strong>{fa(achievements.filter(item => item.unlocked).length)} <small>/ {fa(achievements.length)}</small></strong></div><div className="achievement-list">{achievements.map(({ title, description, unlocked, Icon }) => <div className={`achievement-row ${unlocked ? 'achievement-unlocked' : ''}`} key={title}><span className="achievement-icon"><Icon size={24} /></span><div><h3>{title}</h3><p>{description}</p></div>{unlocked ? <Check size={19} className="achievement-check" /> : <Lock size={15} />}</div>)}</div><p className="saved-note">دستاوردها با بازی کردن به‌صورت خودکار باز می‌شوند.</p>
        </Modal>}

        {dialog === 'records' && <Modal key="records" title="هر نبرد، یک رکورد تازه." subtitle="YOUR BATTLE RECORDS" onClose={closeDialog} wide>
          {progress.runs.length === 0 ? <div className="empty-records"><Trophy size={49} strokeWidth={1} /><h3>هنوز میدان را ندیده‌ای.</h3><p>اولین نبردت را شروع کن؛ اینجا داستان رکوردهای تو نوشته می‌شود.</p><button className="button button-primary" onClick={() => startGame('survival')}><Crosshair size={18} />شروع اولین نبرد</button></div> : <><div className="records-summary"><div><span>بهترین امتیاز نبرد آزاد</span><strong>{fa(progress.bestScore)}</strong></div><div><span>بالاترین موج</span><strong>{fa(progress.bestWave)}</strong></div><div><span>دشمنان شکست‌خورده</span><strong>{fa(progress.totalKills)}</strong></div><div><span>کیاس امرالد</span><strong>{fa(progress.emeralds.length)} <small>/ ۷</small></strong></div></div><div className="records-table-wrap"><table className="records-table"><thead><tr><th>نبرد</th><th>امتیاز</th><th>موج</th><th>سختی</th><th>نتیجه</th></tr></thead><tbody>{progress.runs.map((run, index) => <tr key={`${run.date}-${index}`}><td><strong>{run.mode === 'story' ? chapters[run.chapter].title : 'نبرد بی‌پایان'}</strong><span>{new Date(run.date).toLocaleDateString('fa-IR')}</span></td><td>{fa(run.score)}</td><td>{fa(run.wave)}</td><td>{difficultyLabels[run.difficulty]}</td><td className={run.victory ? 'record-victory' : ''}>{run.victory ? 'ماموریت کامل' : 'پایان نبرد'}</td></tr>)}</tbody></table></div><p className="saved-note">۱۰ نبرد اخیر شما در این مرورگر. این جدول آنلاین نیست.</p></>}
        </Modal>}

        {dialog === 'super' && <Modal key="super" title={superShadow.name} subtitle={superShadow.english} onClose={closeDialog} wide>
          <div className="super-dialog">
            <img src={gameAssets.superShadow} alt="سوپر شدو در فرم طلایی" />
            <div dir="rtl">
              <p className="super-dialog-text">{superShadow.description}</p>
              <div className="super-dialog-list">
                <div><Sparkles size={16} /><span>آسیب‌ناپذیری کامل تا {fa(superShadow.duration)} ثانیه</span></div>
                <div><Zap size={16} /><span>سرعت حرکت و آهنگ شلیک بسیار بیشتر</span></div>
                <div><Flame size={16} /><span>برخورد مستقیم با دشمنان آن‌ها را نابود می‌کند</span></div>
                <div><Gem size={16} /><span>نیزه، کنترل و انفجار کیاس بدون مصرف انرژی</span></div>
              </div>
              <div className="super-progress big"><div><span style={{ width: `${progress.emeralds.length / 7 * 100}%` }} /></div><small>{fa(progress.emeralds.length)} از ۷ امرالد جمع‌آوری شده</small></div>
              <p className="help-tip">{progress.emeralds.length >= 7 ? 'همه چیز آماده است: در میدان، انرژی کیاس را کامل کن و کلید F را بزن.' : 'امرالدها در مراحل «جمع‌آوری» فصل‌های داستانی و هر دو موج در نبرد بی‌پایان پیدا می‌شوند.'}</p>
              <button className="button button-primary full-button" onClick={() => startGame(progress.emeralds.length >= 7 ? 'survival' : 'story', Math.min(progress.completedChapters, chapters.length - 1))}><Play size={16} fill="currentColor" />{progress.emeralds.length >= 7 ? 'امتحان فرم سوپر' : 'شکار امرالد بعدی'}</button>
            </div>
          </div>
        </Modal>}

        {dialog === 'doom' && <Modal key="doom" title="قدرت‌های دووم در دستان شدو" subtitle="SHADOW GENERATIONS / DOOM POWERS" onClose={closeDialog} wide><DoomPowerGuide /><button className="button button-primary full-button" onClick={() => startGame('survival')}><Play size={16} fill="currentColor" />امتحان دووم پاورها در میدان</button></Modal>}

        {dialog === 'power' && <Modal key="power" title={power.name} subtitle={power.english} onClose={closeDialog}>
          <div className="power-detail" style={{ '--power-color': power.color } as CSSProperties}><Emerald color={power.color} /><p>{power.description}</p><div className="power-detail-meta"><span>انرژی مورد نیاز <strong>{fa(power.cost)} / ۱۰۰</strong></span><span>کلید فعال‌سازی <kbd>{power.key}</kbd></span></div></div><p className="help-tip">با جمع کردن امرالدهای میدان و شکست دشمنان، انرژی‌ات را دوباره پر کن. دکمه‌های قدرت در پایین میدان هم قابل لمس هستند.</p><button className="button button-primary full-button" onClick={() => startGame('survival')}><Play size={16} fill="currentColor" />امتحان در میدان نبرد</button>
        </Modal>}
      </AnimatePresence>
    </div>
  );
}