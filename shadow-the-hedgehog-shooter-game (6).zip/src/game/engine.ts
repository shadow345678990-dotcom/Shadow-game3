import { campaignVersion, chaosTeleport, chapters, doomPowers, emeralds as allEmeralds, superShadow, type DialogueLine, type DoomForm, type DoomPower, type GameResult, type Power, type Session, type Stage, type StoryCheckpoint } from '../data';
import { playSound, unlockAudio } from './audio';
import { buildArena, drawAtmosphere, worlds, type SceneId } from './arenas';
import { drawDoomForm } from './doomVisuals';

const WIDTH = 1280;
const HEIGHT = 720;
const TAU = Math.PI * 2;
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const distance = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);

function inputKey(event: KeyboardEvent) {
  // Physical keys keep the controls working with a Persian keyboard layout.
  if (/^Key[A-Z]$/.test(event.code)) return event.code.slice(3).toLowerCase();
  if (/^(Digit|Numpad)[1-5]$/.test(event.code)) return event.code.slice(-1);
  if (event.code === 'Space') return ' ';
  if (event.code.startsWith('Shift')) return 'shift';
  return event.key.toLowerCase();
}

interface Enemy {
  id: number;
  x: number;
  y: number;
  kind: 'robot' | 'alien' | 'boss' | 'black-doom';
  hp: number;
  maxHp: number;
  speed: number;
  fire: number;
  angle: number;
  radius: number;
  dead: boolean;
  phase: number;
  shield: number;
  special: number;
  summon: number;
  attacks: number;
  stun: number;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  kind: 'shot' | 'spear' | 'enemy' | 'doom-spear' | 'doom-blast';
  damage: number;
  hit: Set<number>;
  targetId?: number;
  cargo?: 'robot' | 'alien';
}

interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; color: string; size: number }
interface Pickup { x: number; y: number; kind: 'energy' | 'health' | 'emerald'; life: number; emeraldId?: number }
interface Ring { x: number; y: number; radius: number; maxRadius: number; life: number; maxLife: number; color: string }
interface Pod { x: number; y: number; hp: number; maxHp: number }
interface Beacon { x: number; y: number; charge: number; target: number; done: boolean }
interface Hazard { x: number; y: number; kind: 'burst' | 'beam'; angle: number; radius: number; delay: number; totalDelay: number; life: number; hit: boolean }
interface Portal { x: number; y: number; life: number; maxLife: number; arrival: boolean }
interface Tendril { x: number; y: number; endX: number; endY: number; life: number; maxLife: number }

export interface StoryDialogue extends DialogueLine {
  index: number;
  total: number;
  title: string;
  image: string;
  location: string;
  kind: 'briefing' | 'finale';
}

export interface HUD {
  health: number;
  maxHealth: number;
  energy: number;
  score: number;
  wave: number;
  targetWaves: number;
  remaining: number;
  kills: number;
  time: number;
  controlTime: number;
  dashReady: boolean;
  teleportReady: boolean;
  teleportCooldown: number;
  bossHealth: number;
  bossMax: number;
  announcement: string;
  announcementDetail: string;
  toast: string;
  emeralds: number[];
  superTime: number;
  superReady: boolean;
  superCooldown: number;
  objective: string;
  objectiveValue: string;
  objectiveProgress: number;
  podHealth: number;
  podMax: number;
  podLabel: string;
  dialogue: StoryDialogue | null;
  radio: DialogueLine | null;
  location: string;
  scene: SceneId;
  objectiveDetail: string;
  bossName: string;
  bossPhase: number;
  bossAttack: string;
  doomForm: DoomForm | null;
  doomCooldowns: Record<DoomPower, number>;
}

export const initialHUD: HUD = { health: 120, maxHealth: 120, energy: 100, score: 0, wave: 0, targetWaves: 0, remaining: 0, kills: 0, time: 0, controlTime: 0, dashReady: true, teleportReady: true, teleportCooldown: 0, bossHealth: 0, bossMax: 0, announcement: 'آمادهٔ نبرد', announcementDetail: 'قدرت آشوب در دستان توست', toast: '', emeralds: [], superTime: 0, superReady: false, superCooldown: 0, objective: '', objectiveValue: '', objectiveProgress: 0, podHealth: 0, podMax: 0, podLabel: '', dialogue: null, radio: null, location: '', scene: 'city-street', objectiveDetail: '', bossName: '', bossPhase: 0, bossAttack: '', doomForm: null, doomCooldowns: { spear: 0, morph: 0, surf: 0, blast: 0, wing: 0 } };

function polygon(ctx: CanvasRenderingContext2D, points: number[][]) {
  ctx.beginPath();
  points.forEach(([x, y], index) => index ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.closePath();
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private background: HTMLCanvasElement;
  private session: Session;
  private emit: (hud: HUD) => void;
  private onFinish: (result: GameResult) => void;
  private onPause: () => void;
  private onCheckpoint: (checkpoint: StoryCheckpoint) => void;
  private arenaImages = new Map<string, HTMLImageElement>();
  private scene: SceneId = 'city-street';
  private resizeObserver: ResizeObserver;
  private raf = 0;
  private lastFrame = 0;
  private scale = 1;
  private offsetX = 0;
  private offsetY = 0;
  private pixelRatio = 1;
  private viewportWidth = WIDTH;
  private viewportHeight = HEIGHT;
  private worldWidth = WIDTH;
  private worldHeight = HEIGHT;
  private keys = new Set<string>();
  private mouse = { x: WIDTH / 2 + 120, y: HEIGHT / 2 };
  private mouseActive = false;
  private pointerDown = false;
  private pointerId: number | null = null;
  private touch = { x: 0, y: 0, firing: false };
  private paused = false;
  private ended = false;
  private disposed = false;
  private elapsed = 0;
  private hudWait = 0;
  private player = { x: WIDTH / 2, y: HEIGHT / 2, angle: -Math.PI / 2, hp: 120, maxHp: 120, energy: 100, invincible: 1, fire: 0, dash: 0, dashCooldown: 0, dashX: 0, dashY: -1, superTime: 0, superCooldown: 0 };
  private teleportCooldown = 0;
  private portals: Portal[] = [];
  private doomForm: DoomForm | null = null;
  private doomCooldowns: Record<DoomPower, number> = { spear: 0, morph: 0, surf: 0, blast: 0, wing: 0 };
  private tendrils: Tendril[] = [];
  private surfSpin = 0;
  private ownedEmeralds: Set<number>;
  private superUsed = false;
  private pod: Pod | null = null;
  private stageIndex = 0;
  private stageKills = 0;
  private stageCollected = 0;
  private stageTimer = 0;
  private stageElapsed = 0;
  private stageActive = false;
  private bossSpawned = false;
  private blackDoomDefeated = false;
  private emeraldsReleased = false;
  private briefing = false;
  private cutscene: DialogueLine[] | null = null;
  private dialogueIndex = 0;
  private radio: DialogueLine | null = null;
  private radioTime = 0;
  private radioPlayed = false;
  private beacons: Beacon[] = [];
  private hazards: Hazard[] = [];
  private bossAttack = '';
  private bossAttackTime = 0;
  private enemies: Enemy[] = [];
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];
  private pickups: Pickup[] = [];
  private rings: Ring[] = [];
  private entityId = 0;
  private wave = 0;
  private spawnRemaining = 0;
  private spawnWait = 0;
  private waveWait = 2.8;
  private score = 0;
  private kills = 0;
  private bossKills = 0;
  private controlTime = 0;
  private shake = 0;
  private flash = 0;
  private announcement = 'آمادهٔ نبرد';
  private announcementDetail = 'قدرت آشوب در دستان توست';
  private announcementTime = 2.8;
  private toast = '';
  private toastTime = 0;
  private powerCooldowns: Record<Power, number> = { spear: 0, control: 0, blast: 0 };
  private trailWait = 0;
  private difficulty = 1;
  private reducedMotion = false;

  constructor(canvas: HTMLCanvasElement, session: Session, emit: (hud: HUD) => void, finish: (result: GameResult) => void, onPause: () => void, onCheckpoint: (checkpoint: StoryCheckpoint) => void = () => {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.session = session;
    this.emit = emit;
    this.onFinish = finish;
    this.onPause = onPause;
    this.onCheckpoint = onCheckpoint;
    if (session.mode === 'story') {
      this.stageIndex = clamp(Math.floor(session.startStage ?? 0), 0, chapters[session.chapter].stages.length - 1);
      this.scene = chapters[session.chapter].stages[this.stageIndex].scene;
    }
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.ownedEmeralds = new Set(session.emeralds);
    this.difficulty = session.settings.difficulty === 'easy' ? .72 : session.settings.difficulty === 'hard' ? 1.3 : 1;
    this.player.maxHp = session.settings.difficulty === 'easy' ? 160 : session.settings.difficulty === 'hard' ? 100 : 120;
    this.player.hp = this.player.maxHp;
    this.background = this.makeBackground();
    this.loadArenaArt();
    this.resizeObserver = new ResizeObserver(this.resize);
    this.resizeObserver.observe(canvas);
    this.resize();
    window.addEventListener('keydown', this.keyDown);
    window.addEventListener('keyup', this.keyUp);
    window.addEventListener('blur', this.blur);
    canvas.addEventListener('pointerdown', this.pointerStart);
    canvas.addEventListener('pointermove', this.pointerMove);
    canvas.addEventListener('lostpointercapture', this.pointerEnd);
    canvas.addEventListener('contextmenu', this.preventMenu);
    window.addEventListener('pointerup', this.pointerEnd);
    window.addEventListener('pointercancel', this.pointerEnd);
    if (session.mode === 'story') this.beginStage();
    this.publish();
    this.raf = requestAnimationFrame(this.frame);
  }

  private resize = () => {
    const rect = this.canvas.getBoundingClientRect();
    this.viewportWidth = Math.max(1, rect.width);
    this.viewportHeight = Math.max(1, rect.height);
    const portrait = this.viewportWidth < 720 && this.viewportHeight > this.viewportWidth;
    const nextWidth = portrait ? 720 : WIDTH;
    const nextHeight = portrait ? Math.round(clamp(720 * this.viewportHeight / this.viewportWidth, 720, 1536)) : HEIGHT;
    if (nextWidth !== this.worldWidth || nextHeight !== this.worldHeight) {
      const ratioX = nextWidth / this.worldWidth;
      const ratioY = nextHeight / this.worldHeight;
      [this.player, this.mouse, ...this.enemies, ...this.bullets, ...this.particles, ...this.pickups, ...this.rings, ...this.beacons, ...this.hazards, ...this.portals, ...(this.pod ? [this.pod] : [])].forEach(entity => {
        entity.x *= ratioX;
        entity.y *= ratioY;
      });
      this.tendrils.forEach(tendril => { tendril.x *= ratioX; tendril.y *= ratioY; tendril.endX *= ratioX; tendril.endY *= ratioY; });
      this.worldWidth = nextWidth;
      this.worldHeight = nextHeight;
      this.background = this.makeBackground();
    }
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.viewportWidth * this.pixelRatio);
    this.canvas.height = Math.round(this.viewportHeight * this.pixelRatio);
    this.scale = Math.min(this.viewportWidth / this.worldWidth, this.viewportHeight / this.worldHeight);
    this.offsetX = (this.viewportWidth - this.worldWidth * this.scale) / 2;
    this.offsetY = (this.viewportHeight - this.worldHeight * this.scale) / 2;
  };

  private keyDown = (event: KeyboardEvent) => {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    const key = inputKey(event);
    if (key === 'escape' && !event.repeat && !this.ended) { event.preventDefault(); this.onPause(); return; }
    if (this.paused || this.ended) return;
    if (this.briefing) {
      if (event.target instanceof HTMLElement && event.target.closest('button')) return;
      if (['enter', ' '].includes(key)) { event.preventDefault(); if (!event.repeat) this.advanceDialogue(); }
      return;
    }
    if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' ', 'shift', 'q', 'e', 'r', 'f', 't', '1', '2', '3', '4', '5'].includes(key)) event.preventDefault();
    unlockAudio();
    this.keys.add(key);
    if (!event.repeat) {
      if (key === 'q') this.castPower('spear');
      if (key === 'e') this.castPower('control');
      if (key === 'r') this.castPower('blast');
      if (key === 'f') this.goSuper();
      if (key === 't') this.teleport();
      if (key === 'shift') this.dash();
      const doom = doomPowers.find(power => power.key === key);
      if (doom) this.castDoomPower(doom.id);
    }
  };

  private keyUp = (event: KeyboardEvent) => { this.keys.delete(inputKey(event)); };
  private blur = () => { if (!this.paused && !this.ended) this.onPause(); };
  private preventMenu = (event: Event) => event.preventDefault();
  private pointerStart = (event: PointerEvent) => {
    if (event.button !== 0 || this.paused || this.ended || this.briefing) return;
    if (this.pointerId !== null && this.pointerId !== event.pointerId) return;
    event.preventDefault();
    unlockAudio();
    this.pointerMove(event);
    this.pointerDown = true;
    this.pointerId = event.pointerId;
    this.canvas.setPointerCapture(event.pointerId);
  };
  private pointerMove = (event: PointerEvent) => {
    if (this.pointerId !== null && this.pointerId !== event.pointerId) return;
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x = (event.clientX - rect.left - this.offsetX) / this.scale;
    this.mouse.y = (event.clientY - rect.top - this.offsetY) / this.scale;
    this.mouseActive = event.pointerType !== 'touch';
  };
  private pointerEnd = (event: PointerEvent) => {
    if (event.pointerId === this.pointerId) { this.pointerDown = false; this.pointerId = null; }
  };

  setPaused(paused: boolean) {
    this.paused = paused;
    this.keys.clear();
    this.pointerDown = false;
    this.pointerId = null;
    this.touch = { x: 0, y: 0, firing: false };
  }

  setSound(enabled: boolean) {
    this.session.settings.sound = enabled;
    if (enabled) unlockAudio();
  }

  setTouchMovement(x: number, y: number) { this.touch.x = x; this.touch.y = y; }
  setTouchFire(firing: boolean) { this.touch.firing = firing; if (firing) unlockAudio(); }

  dash() {
    if (this.paused || this.ended || this.briefing || this.player.dashCooldown > 0) return;
    const { x, y } = this.getMovement();
    this.player.dashX = x || y ? x : Math.cos(this.player.angle);
    this.player.dashY = x || y ? y : Math.sin(this.player.angle);
    this.player.dash = .18;
    this.player.dashCooldown = this.doomForm === 'surf' ? .65 : this.doomForm === 'wing' ? .75 : this.doomForm === 'morph' ? 1 : 2.2;
    this.player.invincible = Math.max(this.player.invincible, .35);
    this.rings.push({ x: this.player.x, y: this.player.y, radius: 5, maxRadius: 65, life: .3, maxLife: .3, color: '#f9414b' });
    if (this.doomForm === 'surf') this.surfAttack();
  }

  castDoomPower(power: DoomPower, quiet = false) {
    if (this.disposed || this.paused || this.ended || this.briefing) return;
    const config = doomPowers.find(item => item.id === power)!;
    if (this.doomCooldowns[power] > 0) return;
    if (power === 'morph' || power === 'surf' || power === 'wing') {
      this.doomForm = this.doomForm === power ? null : power;
      this.player.dash = 0;
      this.player.dashCooldown = 0;
      this.player.fire = 0;
      this.burst(this.player.x, this.player.y, config.color, this.reducedMotion ? 8 : 32);
      this.rings.push({ x: this.player.x, y: this.player.y, radius: 0, maxRadius: 100, life: .55, maxLife: .55, color: config.color });
      this.showToast(this.doomForm ? `${config.name} فعال شد؛ بدون محدودیت زمان` : `${config.name} خاموش شد`);
    } else if (power === 'spear') {
      const targets = this.enemies.filter(enemy => !enemy.dead && distance(enemy, this.player) < 950)
        .sort((a, b) => distance(a, this.player) - distance(b, this.player)).slice(0, 5);
      for (let i = 0; i < 5; i++) {
        const target = targets[i];
        const angle = target ? Math.atan2(target.y - this.player.y, target.x - this.player.x) : this.player.angle + (i - 2) * .15;
        this.fireBullet(angle, 'doom-spear', 880, 185, target?.id);
      }
      this.doomCooldowns.spear = config.cooldown;
      this.burst(this.player.x, this.player.y, config.color, 15);
      if (!quiet) this.showToast(config.name);
    } else {
      const targets = this.enemies.filter(enemy => !enemy.dead && distance(enemy, this.player) < 640)
        .sort((a, b) => distance(a, this.player) - distance(b, this.player));
      const target = targets[0];
      if (!target) { if (!quiet) { this.showToast('برای دووم بلست، یک دشمن را در برد نزدیک پیدا کن'); this.publish(); } return; }
      const origin = { x: this.player.x, y: this.player.y };
      const impact = { x: target.x, y: target.y };
      const next = this.enemies.filter(enemy => !enemy.dead && enemy.id !== target.id)
        .sort((a, b) => distance(a, target) - distance(b, target))[0];
      const aim = this.mouseActive && distance(target, this.mouse) > 60 ? this.mouse : next;
      const angle = aim ? Math.atan2(aim.y - target.y, aim.x - target.x) : Math.atan2(target.y - this.player.y, target.x - this.player.x);
      this.player.x = clamp(target.x - Math.cos(angle) * 58, 32, this.worldWidth - 32);
      this.player.y = clamp(target.y - Math.sin(angle) * 58, 32, this.worldHeight - 32);
      this.player.invincible = Math.max(this.player.invincible, .55);
      this.player.dash = 0;
      this.player.angle = angle;
      this.damageEnemy(target, target.kind === 'boss' || target.kind === 'black-doom' ? 620 : Math.max(330, target.hp));
      if (target.kind === 'robot' || target.kind === 'alien') {
        this.bullets.push({ ...impact, vx: Math.cos(angle) * 820, vy: Math.sin(angle) * 820, life: 1.4, kind: 'doom-blast', damage: 420, cargo: target.kind, hit: new Set([target.id]) });
      } else this.doomExplosion(impact.x, impact.y, 150);
      this.portals.push({ ...origin, life: .45, maxLife: .45, arrival: false });
      this.tendrils.push({ ...origin, endX: impact.x, endY: impact.y, life: .3, maxLife: .3 });
      this.burst(impact.x, impact.y, config.color, 28);
      this.doomCooldowns.blast = config.cooldown;
      this.showToast(config.name);
    }
    unlockAudio();
    playSound('doom', this.session.settings.sound);
    this.publish();
  }

  private morphAttack() {
    const targets = this.enemies.filter(enemy => !enemy.dead && distance(enemy, this.player) < 410)
      .sort((a, b) => distance(a, this.player) - distance(b, this.player)).slice(0, 4);
    const points = targets.length ? targets : [{ x: this.player.x + Math.cos(this.player.angle) * 175, y: this.player.y + Math.sin(this.player.angle) * 175 }];
    points.forEach(point => this.tendrils.push({ x: this.player.x, y: this.player.y, endX: point.x, endY: point.y, life: .3, maxLife: .3 }));
    targets.forEach(enemy => {
      const angle = Math.atan2(this.player.y - enemy.y, this.player.x - enemy.x);
      if (enemy.kind === 'robot' || enemy.kind === 'alien') {
        enemy.x = clamp(enemy.x + Math.cos(angle) * 70, 20, this.worldWidth - 20);
        enemy.y = clamp(enemy.y + Math.sin(angle) * 70, 20, this.worldHeight - 20);
        enemy.stun = .9;
      }
      this.damageEnemy(enemy, this.player.superTime > 0 ? 245 : 175);
    });
    playSound('doom', this.session.settings.sound);
  }

  private surfAttack() {
    this.surfSpin = .5;
    this.rings.push({ x: this.player.x, y: this.player.y, radius: 10, maxRadius: 190, life: .5, maxLife: .5, color: '#69dfd3' });
    this.enemies.forEach(enemy => {
      if (enemy.dead || distance(enemy, this.player) > 190) return;
      this.damageEnemy(enemy, 245);
      if (enemy.kind === 'robot' || enemy.kind === 'alien') {
        const angle = Math.atan2(enemy.y - this.player.y, enemy.x - this.player.x);
        enemy.x = clamp(enemy.x + Math.cos(angle) * 75, 20, this.worldWidth - 20);
        enemy.y = clamp(enemy.y + Math.sin(angle) * 75, 20, this.worldHeight - 20);
        enemy.stun = .45;
      }
    });
    this.bullets.forEach(bullet => {
      if (bullet.kind !== 'enemy' || bullet.life <= 0 || distance(bullet, this.player) > 190) return;
      const angle = Math.atan2(bullet.y - this.player.y, bullet.x - this.player.x);
      bullet.kind = 'shot'; bullet.vx = Math.cos(angle) * 760; bullet.vy = Math.sin(angle) * 760;
      bullet.damage = 65; bullet.life = 1.5; bullet.hit = new Set();
    });
    this.burst(this.player.x, this.player.y, '#69dfd3', 18);
    playSound('doom', this.session.settings.sound);
  }

  private doomExplosion(x: number, y: number, damage = 175) {
    this.enemies.forEach(enemy => { if (!enemy.dead && distance(enemy, { x, y }) < 172) this.damageEnemy(enemy, damage); });
    this.rings.push({ x, y, radius: 8, maxRadius: 172, life: .5, maxLife: .5, color: '#ff835f' });
    this.burst(x, y, '#ff835f', 32);
  }

  get teleportReady() {
    return this.teleportCooldown <= 0 && (this.player.superTime > 0 || this.player.energy >= chaosTeleport.cost);
  }

  teleport(useMovement = false) {
    if (this.disposed || this.paused || this.ended || this.briefing) return;
    if (this.teleportCooldown > 0) {
      this.showToast(`تله‌پورت در حال بازیابی است؛ ${this.teleportCooldown.toLocaleString('fa-IR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ثانیه`);
      this.publish();
      return;
    }
    const cost = this.player.superTime > 0 ? 0 : chaosTeleport.cost;
    if (this.player.energy < cost) { this.showToast('برای تله‌پورت انرژی کیاس کافی نیست'); this.publish(); return; }

    const movement = this.getMovement();
    const aimAtPointer = this.mouseActive && !useMovement;
    let dx = aimAtPointer ? this.mouse.x - this.player.x : movement.x;
    let dy = aimAtPointer ? this.mouse.y - this.player.y : movement.y;
    if (!aimAtPointer && Math.hypot(dx, dy) < .05) { dx = Math.cos(this.player.angle); dy = Math.sin(this.player.angle); }
    const length = Math.hypot(dx, dy);
    if (length < .001) { this.showToast('برای تله‌پورت مقصد دیگری را نشانه بگیر'); this.publish(); return; }

    // Pointer targeting uses arena coordinates; all destinations stay inside the playable floor.
    const range = aimAtPointer ? Math.min(chaosTeleport.range, length) : chaosTeleport.range;
    const destination = {
      x: clamp(this.player.x + dx / length * range, 32, this.worldWidth - 32),
      y: clamp(this.player.y + dy / length * range, 32, this.worldHeight - 32),
    };
    if (distance(this.player, destination) < 8) {
      this.showToast('این مسیر به لبهٔ میدان می‌رسد؛ جهت دیگری را انتخاب کن');
      this.publish();
      return;
    }

    const origin = { x: this.player.x, y: this.player.y };
    this.player.energy -= cost;
    this.player.x = destination.x;
    this.player.y = destination.y;
    this.player.dash = 0;
    this.player.invincible = Math.max(this.player.invincible, chaosTeleport.protection);
    this.teleportCooldown = chaosTeleport.cooldown;
    this.portals.push(
      { ...origin, life: .55, maxLife: .55, arrival: false },
      { ...destination, life: .55, maxLife: .55, arrival: true },
    );
    for (const point of [origin, destination]) {
      this.burst(point.x, point.y, chaosTeleport.color, this.reducedMotion ? 8 : 26);
      this.rings.push({ ...point, radius: 7, maxRadius: 66, life: .45, maxLife: .45, color: chaosTeleport.color });
    }
    unlockAudio();
    playSound('teleport', this.session.settings.sound);
    this.showToast('تله‌پورت کیاس');
    this.publish();
  }

  get superReady() {
    return this.ownedEmeralds.size >= allEmeralds.length && this.player.superTime <= 0 && this.player.superCooldown <= 0 && this.player.energy >= 100;
  }

  goSuper() {
    if (this.paused || this.ended || this.briefing || this.player.superTime > 0) return;
    if (this.ownedEmeralds.size < allEmeralds.length) {
      this.showToast(`برای سوپر شدو هر ۷ امرالد لازم است (${this.ownedEmeralds.size.toLocaleString('fa-IR')} از ۷)`);
      return;
    }
    if (this.player.superCooldown > 0) {
      this.showToast(`انرژی آشوب در حال بازیابی است؛ ${Math.ceil(this.player.superCooldown).toLocaleString('fa-IR')} ثانیه تا تبدیل دوباره`);
      return;
    }
    if (this.player.energy < 100) { this.showToast('برای تبدیل شدن، انرژی کیاس باید کامل باشد'); return; }
    unlockAudio();
    this.player.energy = 0;
    this.player.superTime = superShadow.duration;
    this.player.invincible = Math.max(this.player.invincible, superShadow.duration);
    this.player.hp = Math.min(this.player.maxHp, this.player.hp + 40);
    this.superUsed = true;
    this.shake = .5;
    this.flash = .25;
    this.burst(this.player.x, this.player.y, '#ffd84a', 90);
    this.rings.push({ x: this.player.x, y: this.player.y, radius: 0, maxRadius: 420, life: 1, maxLife: 1, color: '#ffd84a' });
    this.announcement = 'سوپر شدو';
    this.announcementDetail = 'هفت امرالد بیدار شدند. حالا هیچ‌کس جلودار تو نیست.';
    this.announcementTime = 2.6;
    playSound('power', this.session.settings.sound);
    this.publish();
  }

  castPower(power: Power) {
    if (this.paused || this.ended || this.briefing) return;
    const base = power === 'spear' ? 22 : power === 'control' ? 38 : 65;
    const cost = this.player.superTime > 0 ? 0 : base;
    if (this.player.energy < cost) { this.showToast('انرژی کیاس کافی نیست'); return; }
    if (this.powerCooldowns[power] > 0) { this.showToast('این قدرت هنوز آماده نیست'); return; }
    unlockAudio();
    this.player.energy -= cost;
    playSound('power', this.session.settings.sound);
    if (power === 'spear') {
      const target = this.nearestEnemy();
      const angle = target && !this.pointerDown ? Math.atan2(target.y - this.player.y, target.x - this.player.x) : this.player.angle;
      for (let i = -2; i <= 2; i++) this.fireBullet(angle + i * .12, 'spear', 900, 75);
      this.powerCooldowns.spear = .65;
      this.burst(this.player.x, this.player.y, '#a9ff79', 16);
      this.showToast('نیزهٔ کیاس');
    } else if (power === 'control') {
      this.controlTime = 5;
      this.powerCooldowns.control = 6;
      this.rings.push({ x: this.player.x, y: this.player.y, radius: 0, maxRadius: 900, life: .9, maxLife: .9, color: '#6ecfff' });
      this.showToast('کنترل کیاس: زمان کند شد');
    } else {
      this.powerCooldowns.blast = 4;
      this.rings.push({ x: this.player.x, y: this.player.y, radius: 0, maxRadius: 335, life: .8, maxLife: .8, color: '#ff3847' });
      this.burst(this.player.x, this.player.y, '#ff3847', 70);
      this.enemies.forEach(enemy => { if (distance(enemy, this.player) < 335) this.damageEnemy(enemy, 210); });
      this.bullets = this.bullets.filter(bullet => bullet.kind !== 'enemy' || distance(bullet, this.player) > 335);
      this.shake = .45;
      this.flash = .18;
      this.player.invincible = Math.max(this.player.invincible, .6);
      this.showToast('انفجار کیاس');
    }
    this.publish();
  }

  private showToast(text: string) { this.toast = text; this.toastTime = 2; }

  private getMovement() {
    let x = (this.keys.has('d') || this.keys.has('arrowright') ? 1 : 0) - (this.keys.has('a') || this.keys.has('arrowleft') ? 1 : 0) + this.touch.x;
    let y = (this.keys.has('s') || this.keys.has('arrowdown') ? 1 : 0) - (this.keys.has('w') || this.keys.has('arrowup') ? 1 : 0) + this.touch.y;
    const length = Math.hypot(x, y);
    if (length > 1) { x /= length; y /= length; }
    return { x, y };
  }

  private nearestEnemy() {
    let nearest: Enemy | undefined;
    let closest = Infinity;
    this.enemies.forEach(enemy => {
      const d = distance(enemy, this.player);
      if (!enemy.dead && d < closest) { closest = d; nearest = enemy; }
    });
    return nearest;
  }

  private frame = (timestamp: number) => {
    if (this.disposed) return;
    const dt = this.lastFrame ? Math.min((timestamp - this.lastFrame) / 1000, .035) : 0;
    this.lastFrame = timestamp;
    if (!this.paused && !this.ended && !this.briefing) this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.frame);
  };

  private update(dt: number) {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    this.elapsed += dt;
    this.announcementTime -= dt;
    this.toastTime -= dt;
    this.radioTime = Math.max(0, this.radioTime - dt);
    this.bossAttackTime = Math.max(0, this.bossAttackTime - dt);
    this.controlTime = Math.max(0, this.controlTime - dt);
    this.shake = Math.max(0, this.shake - dt);
    this.flash = Math.max(0, this.flash - dt);
    this.player.invincible = Math.max(0, this.player.invincible - dt);
    this.player.fire -= dt;
    this.player.dashCooldown = Math.max(0, this.player.dashCooldown - dt);
    this.teleportCooldown = Math.max(0, this.teleportCooldown - dt);
    this.portals = this.portals.filter(portal => { portal.life -= dt; return portal.life > 0; });
    this.surfSpin = Math.max(0, this.surfSpin - dt);
    this.tendrils = this.tendrils.filter(tendril => { tendril.life -= dt; return tendril.life > 0; });
    (Object.keys(this.doomCooldowns) as DoomPower[]).forEach(power => { this.doomCooldowns[power] = Math.max(0, this.doomCooldowns[power] - dt); });
    if (this.player.superTime > 0) {
      this.player.superTime = Math.max(0, this.player.superTime - dt);
      this.player.invincible = Math.max(this.player.invincible, Math.min(.2, this.player.superTime));
      if (this.player.superTime === 0) {
        this.player.superCooldown = superShadow.cooldown;
        this.showToast(`فرم سوپر پایان یافت؛ ${superShadow.cooldown.toLocaleString('fa-IR')} ثانیه تا آمادگی دوباره`);
        this.burst(this.player.x, this.player.y, '#ffd84a', 30);
      }
    } else if (this.player.superCooldown > 0) {
      this.player.superCooldown = Math.max(0, this.player.superCooldown - dt);
      if (this.player.superCooldown === 0 && this.ownedEmeralds.size >= allEmeralds.length) {
        // After the short pause the emeralds recharge Shadow so he can transform again right away.
        this.player.energy = 100;
        this.rings.push({ x: this.player.x, y: this.player.y, radius: 0, maxRadius: 180, life: .7, maxLife: .7, color: '#ffd84a' });
        this.showToast(`قدرت امرالدها بازگشت؛ با کلید F دوباره ${superShadow.duration.toLocaleString('fa-IR')} ثانیه سوپر شدو شو`);
      }
    }
    this.player.energy = Math.min(100, this.player.energy + dt * (this.player.superTime > 0 ? 0 : 6));
    (Object.keys(this.powerCooldowns) as Power[]).forEach(power => { this.powerCooldowns[power] = Math.max(0, this.powerCooldowns[power] - dt); });
    const movement = this.getMovement();
    if (this.player.dash > 0) {
      this.player.dash -= dt;
      const speed = this.doomForm === 'surf' ? 1150 : this.doomForm === 'wing' ? 1200 : 950;
      this.player.x += this.player.dashX * speed * dt;
      this.player.y += this.player.dashY * speed * dt;
    } else {
      const formSpeed = this.doomForm === 'surf' ? 450 : this.doomForm === 'wing' ? 425 : this.doomForm === 'morph' ? 330 : 265;
      const speed = Math.max(formSpeed, this.player.superTime > 0 ? 400 : 265);
      this.player.x += movement.x * speed * dt;
      this.player.y += movement.y * speed * dt;
    }
    this.player.x = clamp(this.player.x, 32, WIDTH - 32);
    this.player.y = clamp(this.player.y, 32, HEIGHT - 32);
    this.trailWait -= dt;
    if (this.trailWait <= 0 && (movement.x || movement.y || this.player.dash > 0)) {
      this.trailWait = .035;
      const trailColor = this.player.superTime > 0 ? '#ffd84a' : this.doomForm ? doomPowers.find(power => power.id === this.doomForm)!.color : this.controlTime ? '#6ecfff' : '#ef3548';
      this.particles.push({ x: this.player.x - 8, y: this.player.y, vx: 0, vy: 0, life: .25, maxLife: .25, color: trailColor, size: this.player.dash > 0 ? 12 : this.player.superTime > 0 ? 6 : 3 });
    }
    const target = this.nearestEnemy();
    const autoFiring = this.keys.has(' ') || this.touch.firing;
    if (this.pointerDown || (this.mouseActive && !(autoFiring && this.session.settings.autoAim))) {
      this.player.angle = Math.atan2(this.mouse.y - this.player.y, this.mouse.x - this.player.x);
    } else if (target && this.session.settings.autoAim) {
      this.player.angle = Math.atan2(target.y - this.player.y, target.x - this.player.x);
    } else if (movement.x || movement.y) {
      this.player.angle = Math.atan2(movement.y, movement.x);
    }
    if (this.keys.has('1') && this.doomCooldowns.spear <= 0) this.castDoomPower('spear', true);
    if ((this.pointerDown || autoFiring) && this.player.fire <= 0) {
      const sup = this.player.superTime > 0;
      if (this.doomForm === 'morph') {
        this.morphAttack();
        this.player.fire = .45;
      } else {
        this.fireBullet(this.player.angle + (Math.random() - .5) * (sup ? .02 : .035), 'shot', sup ? 980 : 820, sup ? 58 : 27);
        this.player.fire = sup ? .085 : .135;
        playSound('shot', this.session.settings.sound);
      }
    }
    this.updateWaves(dt);
    if (this.ended || this.briefing) return;
    const slowed = this.controlTime > 0 ? .23 : 1;
    this.enemies.forEach(enemy => this.updateEnemy(enemy, dt * slowed));
    this.updateHazards(dt * slowed);
    if (this.ended) return;
    this.updateBullets(dt, slowed);
    if (this.ended) return;
    this.enemies = this.enemies.filter(enemy => !enemy.dead);
    this.pickups = this.pickups.filter(pickup => {
      pickup.life -= dt;
      const d = distance(pickup, this.player);
      if (d < 125) {
        pickup.x += (this.player.x - pickup.x) * dt * 6;
        pickup.y += (this.player.y - pickup.y) * dt * 6;
      }
      if (d < 28) {
        if (pickup.kind === 'emerald') this.takeEmerald(pickup);
        else if (pickup.kind === 'energy') this.player.energy = Math.min(100, this.player.energy + 20);
        else this.player.hp = Math.min(this.player.maxHp, this.player.hp + 25);
        playSound('pickup', this.session.settings.sound);
        this.burst(pickup.x, pickup.y, pickup.kind === 'emerald' ? (allEmeralds[pickup.emeraldId ?? 0]?.color ?? '#ffd84a') : pickup.kind === 'energy' ? '#a9ff79' : '#ff8895', pickup.kind === 'emerald' ? 40 : 8);
        return false;
      }
      return pickup.life > 0;
    });
    this.particles = this.particles.filter(particle => {
      particle.life -= dt;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= .98;
      particle.vy *= .98;
      return particle.life > 0;
    }).slice(-600);
    this.rings = this.rings.filter(ring => {
      ring.life -= dt;
      ring.radius = ring.maxRadius * (1 - Math.pow(Math.max(0, ring.life / ring.maxLife), 2));
      return ring.life > 0;
    });
    this.hudWait -= dt;
    if (this.hudWait <= 0) { this.publish(); this.hudWait = .1; }
  }

  private get stages(): Stage[] { return chapters[this.session.chapter].stages; }

  private saveCheckpoint() {
    if (this.session.mode !== 'story' || this.ended) return;
    this.onCheckpoint({ chapter: this.session.chapter, stage: this.stageIndex, emeralds: [...this.ownedEmeralds], savedAt: new Date().toISOString(), version: campaignVersion });
  }

  advanceDialogue(skip = false) {
    if (!this.briefing || this.paused || this.ended) return;
    this.keys.clear();
    this.pointerDown = false;
    this.touch = { x: 0, y: 0, firing: false };
    const lines = this.cutscene ?? this.stages[this.stageIndex].dialogue;
    if (!skip && this.dialogueIndex < lines.length - 1) {
      this.dialogueIndex++;
    } else if (this.cutscene) {
      this.briefing = false;
      this.cutscene = null;
      this.finish(true);
      return;
    } else {
      this.briefing = false;
      this.startStageCombat();
    }
    this.publish();
  }

  private startFinale(lines: DialogueLine[]) {
    this.stageActive = false;
    this.enemies = [];
    this.bullets = [];
    this.hazards = [];
    this.beacons = [];
    this.pickups = [];
    this.pod = null;
    this.portals = [];
    this.tendrils = [];
    this.keys.clear();
    this.pointerDown = false;
    this.touch = { x: 0, y: 0, firing: false };
    this.cutscene = lines;
    this.dialogueIndex = 0;
    this.briefing = true;
    this.announcementTime = 0;
    this.toastTime = 0;
    this.radioTime = 0;
    this.publish();
  }

  private updateWaves(dt: number) {
    if (this.session.mode === 'story') this.updateStages(dt);
    else this.updateSurvival(dt);
  }

  private updateStages(dt: number) {
    if (!this.stageActive) {
      this.waveWait -= dt;
      if (this.waveWait <= 0) this.beginStage();
      return;
    }
    const stage = this.stages[this.stageIndex];
    this.stageElapsed += dt;
    const radioAt = stage.type === 'survive' || stage.type === 'defend' ? stage.target * .55 : 24;
    if (stage.radio && !this.radioPlayed && this.stageElapsed > radioAt) {
      this.radio = stage.radio;
      this.radioTime = 9;
      this.radioPlayed = true;
    }
    if (stage.type === 'survive' || stage.type === 'defend') this.stageTimer = Math.max(0, this.stageTimer - dt);
    if (stage.type === 'defend') this.updatePod(dt);
    if (this.ended) return;
    const minions = this.enemies.filter(enemy => !enemy.dead && enemy.kind !== 'boss' && enemy.kind !== 'black-doom').length;
    const requiredKills = stage.type === 'eliminate' ? stage.target : stage.guards;
    const left = requiredKills === undefined ? 99 : requiredKills - this.stageKills - minions;
    this.spawnWait -= dt;
    const maxMinions = stage.type === 'interact' ? 7 : stage.type === 'boss' ? 4 : 9;
    if (stage.boss !== 'black-doom' && this.spawnWait <= 0 && minions < maxMinions && left > 0) {
      this.spawnEnemy();
      this.spawnWait = Math.max(.78, 1.6 - this.stageIndex * .065 - this.session.chapter * .065);
    }
    if (stage.type === 'collect' && !this.emeraldsReleased && this.stageKills >= (stage.guards ?? 0)) {
      this.emeraldsReleased = true;
      (stage.emeralds ?? []).forEach(id => this.spawnEmerald(id));
      this.showToast('قفل محفظه شکست؛ کیاس امرالدها آزاد شدند');
    }
    if (stage.type === 'interact' || stage.type === 'reach') {
      const unlocked = this.stageKills >= (stage.guards ?? 0);
      this.beacons.forEach(beacon => {
        if (beacon.done || !unlocked || distance(beacon, this.player) > 64) return;
        beacon.charge = Math.min(beacon.target, beacon.charge + dt);
        if (beacon.charge >= beacon.target) {
          beacon.done = true;
          this.score += 200;
          this.player.energy = Math.min(100, this.player.energy + 16);
          this.burst(beacon.x, beacon.y, worlds[this.scene].accent, 22);
          playSound('pickup', this.session.settings.sound);
          this.showToast(stage.type === 'reach' ? 'مسیر خروج امن شد' : 'نقطهٔ انرژی فعال شد');
        }
      });
    }
    if (this.stageDone(stage)) this.completeStage();
  }

  private stageDone(stage: Stage) {
    if (stage.type === 'eliminate') return this.stageKills >= stage.target;
    if (stage.type === 'collect') return this.stageCollected >= stage.target;
    if (stage.type === 'boss') {
      if (stage.boss === 'black-doom') return this.blackDoomDefeated;
      return this.bossSpawned && !this.enemies.some(enemy => enemy.kind === 'boss' && !enemy.dead);
    }
    if (stage.type === 'interact' || stage.type === 'reach') return this.beacons.length > 0 && this.beacons.every(beacon => beacon.done);
    return this.stageTimer <= 0;
  }

  private beginStage() {
    const stage = this.stages[this.stageIndex];
    this.stageActive = false;
    this.scene = stage.scene;
    this.background = this.makeBackground();
    this.enemies = [];
    this.bullets = [];
    this.hazards = [];
    this.beacons = [];
    this.pickups = [];
    this.rings = [];
    this.particles = [];
    this.portals = [];
    this.teleportCooldown = 0;
    this.tendrils = [];
    this.surfSpin = 0;
    (Object.keys(this.doomCooldowns) as DoomPower[]).forEach(power => { this.doomCooldowns[power] = 0; });
    this.pod = null;
    this.player.x = this.worldWidth * .5;
    this.player.y = this.worldHeight * (stage.boss === 'black-doom' ? .76 : .6);
    this.player.fire = 0;
    this.player.dash = 0;
    this.player.dashCooldown = 0;
    this.player.invincible = Math.max(this.player.invincible, 1.2);
    this.shake = 0;
    this.flash = 0;
    this.keys.clear();
    this.pointerDown = false;
    this.touch = { x: 0, y: 0, firing: false };
    this.stageKills = 0;
    this.stageCollected = 0;
    this.stageElapsed = 0;
    this.radio = null;
    this.radioTime = 0;
    this.radioPlayed = false;
    this.bossSpawned = false;
    this.blackDoomDefeated = false;
    this.emeraldsReleased = false;
    this.stageTimer = stage.type === 'survive' || stage.type === 'defend' ? stage.target : 0;
    this.wave = this.stageIndex + 1;
    this.briefing = true;
    this.dialogueIndex = 0;
    this.announcementTime = 0;
    this.toastTime = 0;
    this.bossAttack = '';
    this.saveCheckpoint();
    if (stage.dialogue.length === 0) { this.briefing = false; this.startStageCombat(); }
    this.publish();
  }

  private startStageCombat() {
    const stage = this.stages[this.stageIndex];
    this.stageActive = true;
    this.spawnWait = .5;
    this.announcement = stage.title;
    this.announcementDetail = stage.detail;
    this.announcementTime = 3.2;
    if (stage.type === 'boss') {
      this.spawnEnemy(stage.boss === 'black-doom' ? 'black-doom' : 'boss');
      this.bossSpawned = true;
      if (stage.boss === 'black-doom') {
        this.player.energy = 100;
        this.player.hp = this.player.maxHp;
        this.showToast('نبرد نهایی: هفت امرالد و کلید F را فراموش نکن');
      }
    }
    if (stage.type === 'defend') this.pod = { x: this.worldWidth / 2, y: this.worldHeight / 2, hp: 620, maxHp: 620 };
    if (stage.type === 'interact' || stage.type === 'reach') {
      const anchors = stage.type === 'reach' ? [[.76, .3]] : [[.24, .28], [.76, .28], [.76, .72], [.24, .72]];
      const count = stage.type === 'reach' ? 1 : stage.target;
      this.beacons = anchors.slice(0, count).map(([x, y]) => ({ x: this.worldWidth * x, y: this.worldHeight * y, charge: 0, target: stage.type === 'reach' ? stage.target : 6, done: false }));
    }
    playSound('wave', this.session.settings.sound);
  }

  private completeStage() {
    this.stageActive = false;
    this.pod = null;
    this.enemies = [];
    this.bullets = [];
    this.hazards = [];
    this.beacons = [];
    this.score += Math.round(400 * this.difficulty);
    this.player.hp = Math.min(this.player.maxHp, this.player.hp + 18);
    this.player.energy = Math.min(100, this.player.energy + 25);
    this.stageIndex++;
    if (this.stageIndex >= this.stages.length) {
      const finale = chapters[this.session.chapter].finale;
      if (finale?.length) this.startFinale(finale);
      else this.finish(true);
      return;
    }
    this.saveCheckpoint();
    this.waveWait = 3;
    this.announcement = 'مرحله کامل شد';
    this.announcementDetail = `هدف بعدی: ${this.stages[this.stageIndex].title}`;
    this.announcementTime = 2.6;
    playSound('wave', this.session.settings.sound);
  }

  private updatePod(dt: number) {
    const pod = this.pod;
    if (!pod) return;
    let attacked = false;
    this.enemies.forEach(enemy => {
      if (!enemy.dead && enemy.stun <= 0 && distance(enemy, pod) < enemy.radius + 46) {
        pod.hp -= (enemy.kind === 'boss' ? 30 : 10) * this.difficulty * dt;
        attacked = true;
      }
    });
    if (attacked) this.burst(pod.x + (Math.random() - .5) * 60, pod.y + (Math.random() - .5) * 60, '#ffb169', 1);
    if (pod.hp <= 0) {
      pod.hp = 0;
      this.burst(pod.x, pod.y, '#ff6a4a', 70);
      this.shake = .6;
      this.showToast(`${this.stages[this.stageIndex].objectLabel ?? 'هدف محافظت'} نابود شد`);
      this.finish(false);
    }
  }

  private updateSurvival(dt: number) {
    if (this.waveWait > 0) {
      this.waveWait -= dt;
      if (this.waveWait <= 0) this.beginWave();
      return;
    }
    if (this.spawnRemaining > 0) {
      this.spawnWait -= dt;
      if (this.spawnWait <= 0 && this.enemies.length < 24) {
        this.spawnEnemy();
        this.spawnRemaining--;
        this.spawnWait = Math.max(.32, .9 - this.wave * .04);
      }
    } else if (this.enemies.length === 0 && this.wave > 0) {
      this.bullets = this.bullets.filter(bullet => bullet.kind !== 'enemy');
      this.score += Math.round(200 * this.difficulty);
      this.waveWait = 3;
      this.announcement = 'موج پاک‌سازی شد';
      this.announcementDetail = 'نفس بگیر. موج بعدی در راه است.';
      this.announcementTime = 2.4;
      this.player.hp = Math.min(this.player.maxHp, this.player.hp + 12);
      this.player.energy = Math.min(100, this.player.energy + 18);
      if (this.wave % 2 === 0) this.spawnWildEmerald();
    }
  }

  private beginWave() {
    this.wave++;
    this.spawnRemaining = Math.min(34, 5 + this.wave * 2);
    this.spawnWait = .15;
    this.announcement = `موج ${this.wave.toLocaleString('fa-IR')}`;
    this.announcementDetail = this.wave >= 3 ? 'ارتش تاریکی عقب‌نشینی نمی‌کند' : 'به آن‌ها نشان بده شدو کیست';
    this.announcementTime = 2;
    if (this.wave % 5 === 0) {
      this.spawnEnemy('boss');
      this.announcement = 'فرماندهٔ بلک آرمز';
      this.announcementDetail = 'نبرد اصلی از اینجا شروع می‌شود';
      this.announcementTime = 3;
    }
    playSound('wave', this.session.settings.sound);
  }

  private spawnEmerald(id: number) {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    let x = 0;
    let y = 0;
    for (let attempt = 0; attempt < 12; attempt++) {
      x = 110 + Math.random() * (WIDTH - 220);
      y = 110 + Math.random() * (HEIGHT - 220);
      if (distance({ x, y }, this.player) > 260) break;
    }
    this.pickups.push({ x, y, kind: 'emerald', life: Number.POSITIVE_INFINITY, emeraldId: id });
    this.rings.push({ x, y, radius: 0, maxRadius: 150, life: .8, maxLife: .8, color: allEmeralds[id].color });
  }

  private spawnWildEmerald() {
    const missing = allEmeralds.find(emerald => !this.ownedEmeralds.has(emerald.id));
    if (!missing || this.pickups.some(pickup => pickup.kind === 'emerald')) return;
    this.spawnEmerald(missing.id);
    this.showToast('یک کیاس امرالد در میدان ظاهر شد');
  }

  private takeEmerald(pickup: Pickup) {
    const id = pickup.emeraldId ?? 0;
    const emerald = allEmeralds[id];
    this.stageCollected++;
    this.score += 600;
    this.player.energy = 100;
    this.shake = .25;
    this.rings.push({ x: pickup.x, y: pickup.y, radius: 0, maxRadius: 260, life: .8, maxLife: .8, color: emerald.color });
    if (this.ownedEmeralds.has(id)) {
      this.showToast(`${emerald.name} دوباره درخشید؛ انرژی کامل شد`);
      return;
    }
    this.ownedEmeralds.add(id);
    this.saveCheckpoint();
    if (this.ownedEmeralds.size >= allEmeralds.length) {
      this.announcement = 'هفت امرالد کامل شد';
      this.announcementDetail = 'با کلید F یا دکمهٔ سوپر شدو، فرم طلایی را آزاد کن.';
      this.announcementTime = 3.4;
      this.flash = .2;
    } else {
      this.showToast(`${emerald.name} به دست آمد (${this.ownedEmeralds.size.toLocaleString('fa-IR')} از ۷)`);
    }
  }

  private get combatPressure() {
    // Later stages throw denser, tougher waves at the player so the Doom Powers become the practical answer.
    return this.session.mode === 'story'
      ? 1 + this.stageIndex * .065 + this.session.chapter * .075
      : 1 + Math.min(this.wave * .04, .7);
  }

  private spawnEnemy(forced?: Enemy['kind']) {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    const arms = this.session.mode === 'survival' ? this.wave > 1 : chapters[this.session.chapter].faction === 'arms';
    const kind = forced ?? (arms && Math.random() < .55 ? 'alien' : 'robot');
    const side = Math.floor(Math.random() * 4);
    let x = side === 0 ? 22 : side === 1 ? WIDTH - 22 : 70 + Math.random() * (WIDTH - 140);
    let y = side === 2 ? 22 : side === 3 ? HEIGHT - 22 : 70 + Math.random() * (HEIGHT - 140);
    if (distance({ x, y }, this.player) < 230) { x = WIDTH - x; y = HEIGHT - y; }
    if (kind === 'black-doom') { x = WIDTH * .5; y = HEIGHT * .26; }
    const pressure = this.combatPressure;
    const hp = (kind === 'black-doom' ? 12800 : kind === 'boss' ? (this.session.mode === 'story' ? 2250 : 620 + this.wave * 80) : kind === 'alien' ? 54 + this.wave * 5 : 42 + this.wave * 5) * (kind === 'black-doom' ? 1 : pressure);
    this.enemies.push({ id: ++this.entityId, x, y, kind, hp: hp * this.difficulty, maxHp: hp * this.difficulty, speed: ((kind === 'boss' ? 54 : kind === 'alien' ? 92 : 68) + Math.min(this.wave * 2.5, 55)) * (1 + (pressure - 1) * .45), fire: .75 + Math.random() * .9, angle: 0, radius: kind === 'black-doom' ? 65 : kind === 'boss' ? 43 : kind === 'alien' ? 19 : 18, dead: false, phase: 1, shield: 0, special: 5, summon: 12, attacks: 0, stun: 0 });
    this.rings.push({ x, y, radius: 4, maxRadius: kind === 'black-doom' ? 175 : kind === 'boss' ? 90 : 35, life: .8, maxLife: .8, color: '#f9414b' });
  }

  private updateEnemy(enemy: Enemy, dt: number) {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    if (enemy.dead || this.ended) return;
    if (enemy.stun > 0) { enemy.stun = Math.max(0, enemy.stun - dt); return; }
    if (enemy.kind === 'black-doom') { this.updateBlackDoom(enemy, dt); return; }
    const d = distance(enemy, this.player);
    enemy.angle = Math.atan2(this.player.y - enemy.y, this.player.x - enemy.x);
    // During escort stages the attackers push toward the pod while still shooting at Shadow.
    const goal = this.pod ?? this.player;
    const moveAngle = Math.atan2(goal.y - enemy.y, goal.x - enemy.x);
    const goalDistance = distance(enemy, goal);
    const stoppingDistance = this.pod ? 40 : enemy.kind === 'alien' ? 24 : enemy.kind === 'boss' ? 240 : 185;
    if (goalDistance > stoppingDistance) {
      enemy.x += Math.cos(moveAngle) * enemy.speed * dt;
      enemy.y += Math.sin(moveAngle) * enemy.speed * dt;
    } else if (enemy.kind === 'robot' || enemy.kind === 'boss') {
      enemy.x += Math.cos(moveAngle + Math.PI / 2) * enemy.speed * dt * .35;
      enemy.y += Math.sin(moveAngle + Math.PI / 2) * enemy.speed * dt * .35;
    }
    enemy.x = clamp(enemy.x, 20, WIDTH - 20);
    enemy.y = clamp(enemy.y, 20, HEIGHT - 20);
    enemy.fire -= dt;
    if (enemy.fire <= 0 && d < 680) {
      const count = enemy.kind === 'boss' ? 6 : 1;
      for (let i = 0; i < count; i++) {
        const angle = enemy.angle + (i - (count - 1) / 2) * .16;
        const speed = (enemy.kind === 'boss' ? 235 : 198) + Math.min(this.wave * 3.5, 82);
        this.bullets.push({ x: enemy.x + Math.cos(angle) * enemy.radius, y: enemy.y + Math.sin(angle) * enemy.radius, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: 6, kind: 'enemy', damage: (enemy.kind === 'boss' ? 19 : 11) * this.difficulty, hit: new Set() });
      }
      enemy.fire = (enemy.kind === 'boss' ? 1.5 : enemy.kind === 'alien' ? 3 : 2.4) / Math.sqrt(this.difficulty) / this.combatPressure;
    }
    if (d < enemy.radius + (this.doomForm ? 29 : 18)) {
      if (this.player.superTime > 0 || this.doomForm) this.damageEnemy(enemy, (this.player.superTime > 0 ? 320 : this.doomForm === 'wing' ? 360 : this.doomForm === 'surf' ? 310 : 215) * dt);
      if (!enemy.dead && this.player.superTime <= 0 && this.doomForm !== 'wing') this.hurtPlayer((enemy.kind === 'boss' ? 24 : 13) * this.difficulty);
      enemy.x -= Math.cos(enemy.angle) * 30;
      enemy.y -= Math.sin(enemy.angle) * 30;
    }
  }

  private enemyBullet(enemy: Enemy, angle: number, speed: number, damage: number) {
    this.bullets.push({ x: enemy.x + Math.cos(angle) * enemy.radius, y: enemy.y + Math.sin(angle) * enemy.radius, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: 7, kind: 'enemy', damage: damage * this.difficulty, hit: new Set() });
  }

  private updateBlackDoom(enemy: Enemy, dt: number) {
    enemy.shield = Math.max(0, enemy.shield - dt);
    const targetX = this.worldWidth * (.5 + Math.cos(this.elapsed * .23) * .26);
    const targetY = this.worldHeight * (.36 + Math.sin(this.elapsed * .32) * .19);
    enemy.x += (targetX - enemy.x) * dt * .7;
    enemy.y += (targetY - enemy.y) * dt * .7;
    enemy.angle = Math.atan2(this.player.y - enemy.y, this.player.x - enemy.x);
    if (enemy.shield > 0) return;
    enemy.fire -= dt;
    enemy.special -= dt;
    enemy.summon -= dt;
    if (enemy.fire <= 0) {
      const count = 3 + (enemy.phase - 1) * 2;
      for (let i = 0; i < count; i++) this.enemyBullet(enemy, enemy.angle + (i - (count - 1) / 2) * .19, 210 + enemy.phase * 18, 14);
      enemy.fire = 1.95 - enemy.phase * .25;
    }
    if (enemy.special <= 0) {
      enemy.attacks++;
      if (enemy.phase >= 2 && enemy.attacks % 2 === 0) {
        this.hazards.push({ x: enemy.x, y: enemy.y, kind: 'beam', angle: enemy.angle, radius: 24, delay: 1.7, totalDelay: 1.7, life: .65, hit: false });
        this.bossAttack = 'پرتوی چشم: از خط سرخ فاصله بگیر';
      } else {
        const count = enemy.phase + 1;
        for (let i = 0; i < count; i++) {
          const x = i ? clamp(this.player.x + (Math.random() - .5) * 350, 80, this.worldWidth - 80) : this.player.x;
          const y = i ? clamp(this.player.y + (Math.random() - .5) * 300, 80, this.worldHeight - 80) : this.player.y;
          this.hazards.push({ x, y, kind: 'burst', angle: 0, radius: 88 + enemy.phase * 8, delay: 1.65, totalDelay: 1.65, life: .55, hit: false });
        }
        this.bossAttack = 'باران آشوب: از حلقه‌های سرخ بیرون برو';
      }
      if (enemy.phase >= 2) {
        const count = enemy.phase === 3 ? 20 : 14;
        for (let i = 0; i < count; i++) this.enemyBullet(enemy, i * TAU / count + this.elapsed * .1, 150 + enemy.phase * 17, 12);
      }
      this.bossAttackTime = 3.5;
      enemy.special = 7 - enemy.phase * .65;
    }
    if (enemy.summon <= 0) {
      const minions = this.enemies.filter(item => !item.dead && item.kind !== 'black-doom').length;
      if (minions < 5) for (let i = 0; i < Math.min(enemy.phase + 1, 5 - minions); i++) this.spawnEnemy('alien');
      enemy.summon = 15 - enemy.phase;
    }
    if (distance(enemy, this.player) < enemy.radius + 18) {
      if (this.player.superTime > 0 || this.doomForm) this.damageEnemy(enemy, (this.player.superTime > 0 ? 210 : this.doomForm === 'wing' ? 255 : 205) * dt);
      if (!enemy.dead && this.player.superTime <= 0 && this.doomForm !== 'wing') this.hurtPlayer(22 * this.difficulty);
    }
  }

  private updateHazards(dt: number) {
    this.hazards = this.hazards.filter(hazard => {
      if (hazard.delay > 0) { hazard.delay = Math.max(0, hazard.delay - dt); return true; }
      hazard.life -= dt;
      let collision = distance(hazard, this.player) < hazard.radius;
      if (hazard.kind === 'beam') {
        const dx = this.player.x - hazard.x;
        const dy = this.player.y - hazard.y;
        const along = dx * Math.cos(hazard.angle) + dy * Math.sin(hazard.angle);
        const across = Math.abs(dx * Math.sin(hazard.angle) - dy * Math.cos(hazard.angle));
        collision = along > 0 && along < Math.max(this.worldWidth, this.worldHeight) * 1.2 && across < hazard.radius + 12;
      }
      if (this.doomForm === 'morph' && hazard.kind === 'burst') collision = false;
      if (!hazard.hit && collision) {
        hazard.hit = true;
        this.hurtPlayer((hazard.kind === 'beam' ? 28 : 24) * this.difficulty);
      }
      return hazard.life > 0;
    });
  }

  private fireBullet(angle: number, kind: 'shot' | 'spear' | 'doom-spear', speed: number, damage: number, targetId?: number) {
    const side = kind === 'shot' ? 12 : 0;
    const x = this.player.x + Math.cos(angle) * 36 - Math.sin(angle) * side;
    const y = this.player.y + Math.sin(angle) * 36 + Math.cos(angle) * side;
    this.bullets.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: kind === 'doom-spear' ? 3 : 2.2, kind, damage, hit: new Set(), targetId });
    if (kind === 'shot') this.burst(x, y, '#ffdd9a', 2);
  }

  private updateBullets(dt: number, slowed: number) {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    this.bullets = this.bullets.filter(bullet => {
      if (this.ended) return false;
      const step = dt * (bullet.kind === 'enemy' ? slowed : 1);
      if (bullet.kind === 'doom-spear') {
        let target = this.enemies.find(enemy => !enemy.dead && enemy.id === bullet.targetId);
        if (!target) {
          target = this.enemies.filter(enemy => !enemy.dead && !bullet.hit.has(enemy.id))
            .sort((a, b) => distance(a, bullet) - distance(b, bullet))[0];
          bullet.targetId = target?.id;
        }
        if (target) {
          const angle = Math.atan2(target.y - bullet.y, target.x - bullet.x);
          const turn = Math.min(1, dt * 15);
          bullet.vx += (Math.cos(angle) * 830 - bullet.vx) * turn;
          bullet.vy += (Math.sin(angle) * 830 - bullet.vy) * turn;
        }
      }
      bullet.x += bullet.vx * step;
      bullet.y += bullet.vy * step;
      bullet.life -= step;
      if (bullet.life <= 0 || bullet.x < -30 || bullet.x > WIDTH + 30 || bullet.y < -30 || bullet.y > HEIGHT + 30) {
        if (bullet.kind === 'doom-blast') this.doomExplosion(clamp(bullet.x, 25, WIDTH - 25), clamp(bullet.y, 25, HEIGHT - 25));
        return false;
      }
      if (bullet.kind === 'enemy') {
        if (distance(bullet, this.player) < 17) {
          this.hurtPlayer(bullet.damage);
          return false;
        }
      } else {
        for (const enemy of this.enemies) {
          const radius = bullet.kind === 'doom-blast' ? 22 : bullet.kind === 'spear' || bullet.kind === 'doom-spear' ? 8 : 4;
          if (!enemy.dead && !bullet.hit.has(enemy.id) && distance(bullet, enemy) < enemy.radius + radius) {
            this.damageEnemy(enemy, bullet.damage);
            bullet.hit.add(enemy.id);
            if (bullet.kind === 'doom-spear' && enemy.kind !== 'boss' && enemy.kind !== 'black-doom') enemy.stun = .9;
            if (bullet.kind === 'doom-blast') { this.doomExplosion(bullet.x, bullet.y); return false; }
            if (bullet.kind === 'shot' || bullet.kind === 'doom-spear') return false;
          }
        }
      }
      return true;
    });
  }

  private damageEnemy(enemy: Enemy, amount: number) {
    if (enemy.dead) return;
    if (enemy.kind === 'black-doom') {
      if (enemy.shield > 0) return;
      const nextHp = enemy.hp - amount * .6;
      const threshold = enemy.maxHp * (1 - enemy.phase / 3);
      if (enemy.phase < 3 && nextHp <= threshold) {
        enemy.hp = threshold;
        enemy.phase++;
        enemy.shield = 2.8;
        enemy.special = 3;
        this.bullets.forEach(bullet => { if (bullet.kind === 'enemy') bullet.life = 0; });
        this.hazards = [];
        this.rings.push({ x: enemy.x, y: enemy.y, radius: 0, maxRadius: 320, life: 1, maxLife: 1, color: '#dc648e' });
        this.radio = { speaker: 'بلک دووم', text: enemy.phase === 2 ? 'گمان می‌کنی مرا شکست می‌دهی؟ حالا قدرت واقعی بلک آرمز را ببین!' : 'من فرمانروای این دنباله‌دارم! زمین و امرالدها را از تو پس می‌گیرم!' };
        this.radioTime = 8;
        this.bossAttack = `فاز ${enemy.phase.toLocaleString('fa-IR')}: بلک دووم قدرت بیشتری آزاد کرد`;
        this.bossAttackTime = 4;
        this.shake = .35;
        this.publish();
        return;
      }
      enemy.hp = nextHp;
    } else enemy.hp -= amount;
    this.burst(enemy.x, enemy.y, enemy.kind === 'robot' ? '#ffb86b' : '#ee557c', 4);
    if (enemy.hp <= 0) {
      enemy.dead = true;
      this.kills++;
      this.stageKills++;
      const boss = enemy.kind === 'boss' || enemy.kind === 'black-doom';
      if (boss) this.bossKills++;
      if (enemy.kind === 'black-doom') this.blackDoomDefeated = true;
      this.score += Math.round((enemy.kind === 'black-doom' ? 10000 : enemy.kind === 'boss' ? 1800 : enemy.kind === 'alien' ? 150 : 100) * this.difficulty);
      this.player.energy = Math.min(100, this.player.energy + 4);
      this.burst(enemy.x, enemy.y, boss ? '#ff3847' : '#e88c6d', boss ? 90 : 18);
      if (Math.random() < .32 || boss) this.pickups.push({ x: enemy.x, y: enemy.y, kind: 'energy', life: 18 });
      if (Math.random() < .14 || boss) this.pickups.push({ x: enemy.x + 15, y: enemy.y - 15, kind: 'health', life: 18 });
      if (boss) { this.shake = .5; this.showToast(enemy.kind === 'black-doom' ? 'بلک دووم شکست خورد؛ زمین نجات یافت' : 'فرمانده شکست خورد'); }
      playSound('hit', this.session.settings.sound);
    }
  }

  private hurtPlayer(damage: number) {
    if (this.player.superTime > 0 || this.doomForm === 'wing' || this.player.invincible > 0 || this.ended) return;
    const reduction = this.doomForm === 'morph' ? .35 : this.doomForm === 'surf' ? .6 : 1;
    this.player.hp = Math.max(0, this.player.hp - damage * reduction);
    this.player.invincible = .65;
    this.shake = .2;
    this.flash = .08;
    this.burst(this.player.x, this.player.y, '#ff3649', 12);
    playSound('hit', this.session.settings.sound);
    if (this.player.hp <= 0) this.finish(false);
  }

  private burst(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * TAU;
      const speed = 35 + Math.random() * 190;
      const life = .2 + Math.random() * .65;
      this.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life, maxLife: life, color, size: 1 + Math.random() * 3 });
    }
  }

  private finish(victory: boolean) {
    if (this.ended) return;
    this.ended = true;
    this.keys.clear();
    this.pointerDown = false;
    if (victory) this.score += 1000 + this.session.chapter * 300;
    this.publish();
    this.onFinish({ mode: this.session.mode, chapter: this.session.chapter, victory, score: this.score, kills: this.kills, wave: this.wave, duration: Math.floor(this.elapsed), bossKills: this.bossKills, difficulty: this.session.settings.difficulty, emeralds: [...this.ownedEmeralds].sort((a, b) => a - b), superUsed: this.superUsed });
  }

  retire() { this.finish(false); }

  private objectiveState() {
    if (this.session.mode !== 'story') return { objective: `موج ${this.wave.toLocaleString('fa-IR')}`, objectiveValue: '', objectiveProgress: 0 };
    const stage = this.stages[Math.min(this.stageIndex, this.stages.length - 1)];
    if (!this.stageActive) return { objective: this.briefing ? 'مرور داستان و هدف ماموریت' : 'آماده‌سازی مرحله', objectiveValue: '', objectiveProgress: 0 };
    const seconds = (value: number) => `${Math.ceil(value).toLocaleString('fa-IR')} ثانیه`;
    if (stage.type === 'eliminate') return { objective: stage.title, objectiveValue: `${Math.min(this.stageKills, stage.target).toLocaleString('fa-IR')} از ${stage.target.toLocaleString('fa-IR')}`, objectiveProgress: this.stageKills / stage.target };
    if (stage.guards && this.stageKills < stage.guards) return { objective: stage.title, objectiveValue: `نگهبانان: ${this.stageKills.toLocaleString('fa-IR')} از ${stage.guards.toLocaleString('fa-IR')}`, objectiveProgress: this.stageKills / stage.guards * .5 };
    if (stage.type === 'collect') return { objective: stage.title, objectiveValue: `${this.stageCollected.toLocaleString('fa-IR')} از ${stage.target.toLocaleString('fa-IR')} امرالد`, objectiveProgress: .5 + this.stageCollected / stage.target * .5 };
    if (stage.type === 'interact' || stage.type === 'reach') {
      const completed = this.beacons.filter(beacon => beacon.done).length;
      const charge = this.beacons.reduce((sum, beacon) => sum + beacon.charge / beacon.target, 0);
      return { objective: stage.title, objectiveValue: stage.type === 'reach' ? 'داخل حلقهٔ خروج بایست' : `${completed.toLocaleString('fa-IR')} از ${stage.target.toLocaleString('fa-IR')} نقطه؛ کنار حلقه بایست`, objectiveProgress: charge / Math.max(1, this.beacons.length) };
    }
    if (stage.type === 'boss') {
      const boss = this.enemies.find(enemy => !enemy.dead && (enemy.kind === 'boss' || enemy.kind === 'black-doom'));
      return { objective: stage.title, objectiveValue: stage.boss === 'black-doom' ? 'پیروزی فقط با شکست خود بلک دووم' : 'شکست فرمانده', objectiveProgress: boss ? 1 - boss.hp / boss.maxHp : 0 };
    }
    return { objective: stage.title, objectiveValue: seconds(this.stageTimer), objectiveProgress: 1 - this.stageTimer / stage.target };
  }

  private publish() {
    const boss = this.enemies.find(enemy => (enemy.kind === 'boss' || enemy.kind === 'black-doom') && !enemy.dead);
    const story = this.session.mode === 'story';
    const stage = this.stages[Math.min(this.stageIndex, this.stages.length - 1)];
    const lines = this.cutscene ?? stage.dialogue;
    const line = this.briefing ? lines[this.dialogueIndex] : null;
    const finale = !!this.cutscene;
    this.emit({
      health: this.player.hp, maxHealth: this.player.maxHp, energy: this.player.energy, score: this.score,
      wave: story ? Math.min(this.stageIndex + 1, this.stages.length) : this.wave,
      targetWaves: story ? this.stages.length : 0,
      remaining: this.spawnRemaining + this.enemies.filter(enemy => !enemy.dead).length,
      kills: this.kills, time: this.elapsed, controlTime: this.controlTime, dashReady: this.player.dashCooldown <= 0,
      teleportReady: this.teleportReady,
      teleportCooldown: this.teleportCooldown,
      bossHealth: boss?.hp ?? 0, bossMax: boss?.maxHp ?? 0,
      announcement: this.announcementTime > 0 ? this.announcement : '',
      announcementDetail: this.announcementTime > 0 ? this.announcementDetail : '',
      toast: this.toastTime > 0 ? this.toast : '',
      emeralds: [...this.ownedEmeralds].sort((a, b) => a - b),
      superTime: this.player.superTime,
      superReady: this.superReady,
      superCooldown: this.player.superCooldown,
      podHealth: this.pod?.hp ?? 0,
      podMax: this.pod?.maxHp ?? 0,
      podLabel: stage.objectLabel ?? 'هدف محافظت',
      dialogue: line ? { ...line, index: this.dialogueIndex, total: lines.length, title: finale ? 'پایان داستان شدو' : stage.title, image: worlds[this.scene].image, location: finale ? 'زمین، پس از نبرد' : worlds[this.scene].name, kind: (finale ? 'finale' : 'briefing') as 'briefing' | 'finale' } : null,
      radio: this.radioTime > 0 ? this.radio : null,
      location: worlds[this.scene].name,
      scene: this.scene,
      objectiveDetail: story ? stage.detail : 'موج‌های ربات‌ها و بلک آرمز را پشت سر بگذار.',
      bossName: boss?.kind === 'black-doom' ? 'بلک دووم' : 'فرماندهٔ بلک آرمز',
      bossPhase: boss?.kind === 'black-doom' ? boss.phase : 0,
      bossAttack: this.bossAttackTime > 0 ? this.bossAttack : '',
      doomForm: this.doomForm,
      doomCooldowns: { ...this.doomCooldowns },
      ...this.objectiveState(),
    });
  }

  private makeBackground() {
    return buildArena(this.worldWidth, this.worldHeight, this.scene, this.arenaImages.get(worlds[this.scene].image));
  }

  private loadArenaArt() {
    const locations = this.session.mode === 'story' ? this.stages.map(stage => stage.scene) : [this.scene];
    locations.forEach(scene => {
      const url = worlds[scene].image;
      if (this.arenaImages.has(url)) return;
      const image = new Image();
      this.arenaImages.set(url, image);
      image.onload = () => {
        if (!this.disposed && worlds[this.scene].image === url) this.background = this.makeBackground();
      };
      image.src = url;
    });
  }

  private render() {
    const WIDTH = this.worldWidth;
    const HEIGHT = this.worldHeight;
    const ctx = this.ctx;
    ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
    ctx.fillStyle = '#080a0d';
    ctx.fillRect(0, 0, this.viewportWidth, this.viewportHeight);
    ctx.save();
    ctx.translate(this.offsetX, this.offsetY);
    ctx.scale(this.scale, this.scale);
    ctx.beginPath();
    ctx.rect(0, 0, WIDTH, HEIGHT);
    ctx.clip();
    if (this.shake && this.session.settings.screenShake && !this.reducedMotion && !this.paused) ctx.translate((Math.random() - .5) * this.shake * 20, (Math.random() - .5) * this.shake * 20);
    ctx.drawImage(this.background, 0, 0);
    drawAtmosphere(ctx, WIDTH, HEIGHT, this.scene, this.reducedMotion ? 0 : this.elapsed);
    if (this.controlTime > 0) {
      ctx.fillStyle = '#299fdb0b'; ctx.fillRect(0, 0, WIDTH, HEIGHT);
      ctx.strokeStyle = '#6ecfff30'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(this.player.x, this.player.y, 58 + Math.sin(this.elapsed * 3) * 5, 0, TAU); ctx.stroke();
    }
    this.hazards.forEach(hazard => this.drawHazard(hazard));
    this.beacons.forEach(beacon => this.drawBeacon(beacon));
    this.portals.forEach(portal => this.drawPortal(portal));
    if (this.pod) this.drawPod(this.pod);
    this.pickups.forEach(pickup => this.drawPickup(pickup));
    this.rings.forEach(ring => {
      ctx.globalAlpha = Math.max(0, ring.life / ring.maxLife);
      ctx.strokeStyle = ring.color;
      ctx.lineWidth = 4 + 10 * ring.life / ring.maxLife;
      ctx.beginPath(); ctx.arc(ring.x, ring.y, ring.radius, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 1;
    });
    this.enemies.forEach(enemy => this.drawEnemy(enemy));
    this.tendrils.forEach(tendril => {
      ctx.save();
      const length = distance(tendril, { x: tendril.endX, y: tendril.endY });
      ctx.globalAlpha = Math.max(0, tendril.life / tendril.maxLife);
      ctx.strokeStyle = '#47285e'; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(tendril.x, tendril.y);
      ctx.quadraticCurveTo((tendril.x + tendril.endX) / 2, (tendril.y + tendril.endY) / 2 - Math.min(60, length * .2), tendril.endX, tendril.endY); ctx.stroke();
      ctx.strokeStyle = '#ee7dc0'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#ffabd8'; ctx.beginPath(); ctx.arc(tendril.endX, tendril.endY, 6, 0, TAU); ctx.fill();
      ctx.restore();
    });
    this.drawPlayer();
    this.bullets.forEach(bullet => {
      const angle = Math.atan2(bullet.vy, bullet.vx);
      if (bullet.kind === 'doom-blast') {
        ctx.save(); ctx.translate(bullet.x, bullet.y); ctx.rotate(angle + this.elapsed * 10);
        ctx.shadowColor = '#ff835f'; ctx.shadowBlur = 16;
        ctx.strokeStyle = '#ff9c77'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(0, 0, 25, 0, TAU); ctx.stroke();
        ctx.fillStyle = bullet.cargo === 'robot' ? '#83909e' : '#63415f';
        polygon(ctx, [[-14, -12], [9, -16], [17, -4], [13, 14], [-12, 12]]); ctx.fill();
        ctx.fillStyle = '#ed465b'; ctx.beginPath(); ctx.arc(6, -1, 5, 0, TAU); ctx.fill();
        ctx.shadowBlur = 0; ctx.restore();
        return;
      }
      const color = bullet.kind === 'doom-spear' ? '#ffd36f' : bullet.kind === 'spear' ? '#b0ff79' : bullet.kind === 'enemy' ? '#ff4c61' : '#ffe6aa';
      const length = bullet.kind === 'doom-spear' ? 39 : bullet.kind === 'spear' ? 30 : bullet.kind === 'enemy' ? 9 : 13;
      ctx.strokeStyle = color;
      ctx.lineWidth = bullet.kind === 'spear' || bullet.kind === 'doom-spear' ? 4 : 3;
      ctx.shadowColor = color; ctx.shadowBlur = bullet.kind === 'doom-spear' ? 18 : bullet.kind === 'spear' ? 14 : 8;
      ctx.beginPath(); ctx.moveTo(bullet.x, bullet.y); ctx.lineTo(bullet.x - Math.cos(angle) * length, bullet.y - Math.sin(angle) * length); ctx.stroke();
      ctx.shadowBlur = 0;
      if (bullet.kind === 'doom-spear') {
        ctx.strokeStyle = '#fff0d2'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(bullet.x - Math.cos(angle) * 8, bullet.y - Math.sin(angle) * 8);
        ctx.lineTo(bullet.x + Math.cos(angle) * 7, bullet.y + Math.sin(angle) * 7); ctx.stroke();
      }
    });
    const lockedTargets = new Set(this.bullets.filter(bullet => bullet.kind === 'doom-spear').map(bullet => bullet.targetId));
    this.enemies.forEach(enemy => {
      if (!lockedTargets.has(enemy.id) || enemy.dead) return;
      ctx.strokeStyle = '#ffd36f80'; ctx.lineWidth = 1.5; ctx.setLineDash([7, 5]);
      ctx.beginPath(); ctx.arc(enemy.x, enemy.y, enemy.radius + 12, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    });
    this.particles.forEach(particle => {
      ctx.globalAlpha = Math.max(0, particle.life / particle.maxLife);
      ctx.fillStyle = particle.color;
      ctx.fillRect(particle.x - particle.size / 2, particle.y - particle.size / 2, particle.size, particle.size);
    });
    ctx.globalAlpha = 1;
    const emeraldTarget = this.pickups.find(pickup => pickup.kind === 'emerald');
    const pointTarget = this.beacons.find(beacon => !beacon.done);
    const objectiveTarget = emeraldTarget ?? pointTarget;
    if (objectiveTarget) {
      const angle = Math.atan2(objectiveTarget.y - this.player.y, objectiveTarget.x - this.player.x);
      const color = emeraldTarget ? allEmeralds[emeraldTarget.emeraldId ?? 0].color : worlds[this.scene].accent;
      ctx.save();
      ctx.translate(this.player.x + Math.cos(angle) * 58, this.player.y + Math.sin(angle) * 58);
      ctx.rotate(angle);
      ctx.globalAlpha = .55 + Math.sin(this.elapsed * 5) * .25;
      ctx.fillStyle = color;
      polygon(ctx, [[10, 0], [-4, -7], [-1, 0], [-4, 7]]);
      ctx.fill();
      ctx.restore();
      ctx.globalAlpha = 1;
    }
    if (this.mouseActive && !this.paused && !this.ended && !this.briefing) {
      const target = this.keys.has(' ') && this.session.settings.autoAim ? this.nearestEnemy() : undefined;
      const { x, y } = target ?? this.mouse;
      ctx.strokeStyle = '#ffffffa0'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, 9, 0, TAU); ctx.stroke();
      [[-15, 0, -6, 0], [6, 0, 15, 0], [0, -15, 0, -6], [0, 6, 0, 15]].forEach(([x1, y1, x2, y2]) => { ctx.beginPath(); ctx.moveTo(x + x1, y + y1); ctx.lineTo(x + x2, y + y2); ctx.stroke(); });
      ctx.fillStyle = '#f74750'; ctx.fillRect(x - 1, y - 1, 2, 2);
    }
    const vignette = ctx.createRadialGradient(WIDTH / 2, HEIGHT / 2, 220, WIDTH / 2, HEIGHT / 2, 780);
    vignette.addColorStop(0, 'transparent'); vignette.addColorStop(1, '#02040990');
    ctx.fillStyle = vignette; ctx.fillRect(0, 0, WIDTH, HEIGHT);
    if (this.flash > 0) { ctx.fillStyle = `rgba(255, 35, 59, ${this.flash * 1.1})`; ctx.fillRect(0, 0, WIDTH, HEIGHT); }
    ctx.restore();
  }

  private drawPortal(portal: Portal) {
    const ctx = this.ctx;
    const progress = 1 - portal.life / portal.maxLife;
    const radius = this.reducedMotion ? 26 : portal.arrival ? 15 + progress * 28 : 43 - progress * 26;
    ctx.save(); ctx.translate(portal.x, portal.y);
    ctx.globalAlpha = portal.life / portal.maxLife;
    ctx.shadowColor = chaosTeleport.color; ctx.shadowBlur = this.reducedMotion ? 0 : 18;
    ctx.strokeStyle = chaosTeleport.color; ctx.lineWidth = 3;
    ctx.fillStyle = '#bc9bff20';
    ctx.beginPath(); ctx.ellipse(0, 0, radius * .7, radius, -.25, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = '#eae0ff'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.ellipse(0, 0, radius * .38, radius * .76, .2, 0, TAU); ctx.stroke();
    if (!this.reducedMotion) for (let i = 0; i < 6; i++) {
      const angle = i * TAU / 6 + progress * 4;
      ctx.beginPath(); ctx.moveTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
      ctx.lineTo(Math.cos(angle + .12) * (radius + 9), Math.sin(angle + .12) * (radius + 9)); ctx.stroke();
    }
    ctx.restore();
  }

  private drawPlayer() {
    const ctx = this.ctx;
    const p = this.player;
    const sup = p.superTime > 0;
    const quill = sup ? '#f7c62c' : '#08090e';
    const stripe = sup ? '#ffe07a' : '#e0303a';
    const body = sup ? '#d49a1c' : '#191a22';
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.fillStyle = '#00000065'; ctx.beginPath(); ctx.ellipse(0, 9, 24, 17, 0, 0, TAU); ctx.fill();
    if (sup) {
      const pulse = 42 + Math.sin(this.elapsed * 9) * 5;
      const aura = ctx.createRadialGradient(0, 0, 10, 0, 0, pulse + 26);
      aura.addColorStop(0, '#ffe98a70'); aura.addColorStop(.6, '#ffc63330'); aura.addColorStop(1, '#ffb60000');
      ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(0, 0, pulse + 26, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#ffe07a90'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, pulse, 0, TAU); ctx.stroke();
      for (let i = 0; i < 7; i++) {
        const angle = this.elapsed * 2.2 + i * TAU / 7;
        ctx.fillStyle = allEmeralds[i].color;
        ctx.beginPath(); ctx.arc(Math.cos(angle) * (pulse + 14), Math.sin(angle) * (pulse + 14), 3.4, 0, TAU); ctx.fill();
      }
    } else if (p.invincible > 0 && this.doomForm !== 'wing' && Math.floor(this.elapsed * 14) % 2 === 0) ctx.globalAlpha = .6;
    if (this.doomForm) {
      drawDoomForm(ctx, this.doomForm, p.angle, this.reducedMotion ? 0 : this.elapsed, sup, p.dash > 0, this.surfSpin);
      if (this.doomForm === 'morph') { ctx.restore(); return; }
    }
    ctx.rotate(p.angle);
    ctx.shadowColor = sup ? '#ffd84a' : this.controlTime > 0 ? '#6ecfff' : '#ef3548';
    ctx.shadowBlur = sup ? 26 : p.dash > 0 ? 25 : 9;
    ctx.fillStyle = quill;
    polygon(ctx, [[16, -8], [3, -20], [-11, -35], [-5, -13], [-30, -27], [-22, -4], [-35, 2], [-21, 8], [-27, 27], [-8, 18], [-4, 34], [10, 18], [17, 10]]); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = stripe;
    polygon(ctx, [[0, -17], [-11, -34], [-5, -12], [-17, -8], [-31, -26], [-11, -1], [-32, 1], [-15, 7], [-27, 27], [-3, 14]]); ctx.fill();
    ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(0, 0, 16, 14, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e7e5e4';
    polygon(ctx, [[8, -11], [17, -7], [13, -1], [5, -3]]); ctx.fill();
    polygon(ctx, [[8, 11], [17, 7], [13, 1], [5, 3]]); ctx.fill();
    ctx.fillStyle = '#f53346'; ctx.fillRect(11, -8, 3, 5); ctx.fillRect(11, 3, 3, 5);
    ctx.fillStyle = '#c9a589'; ctx.beginPath(); ctx.ellipse(16, 0, 5.5, 7.5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#08090e'; ctx.beginPath(); ctx.arc(21, 0, 2.9, 0, TAU); ctx.fill();
    for (const side of [-1, 1]) {
      ctx.fillStyle = '#eae9e8'; ctx.fillRect(-12, side * 20 - 5, 16, 9);
      ctx.fillStyle = '#e63243'; ctx.fillRect(-15, side * 20 - 5, 6, 9); ctx.fillRect(-10, side * 20 - 5, 11, 2);
      ctx.fillStyle = '#aa8151'; ctx.fillRect(-3, side * 20 - 6, 3, 11);
      ctx.fillStyle = '#e8e5e2'; ctx.beginPath(); ctx.arc(11, side * 15, 5, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#d3ab62'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(7, side * 14, 4, -Math.PI / 2, Math.PI / 2); ctx.stroke();
    }
    ctx.fillStyle = '#252932'; ctx.fillRect(13, 9, 22, 7);
    ctx.fillStyle = '#7a8590'; ctx.fillRect(16, 9, 19, 2);
    ctx.fillStyle = '#10121a'; ctx.fillRect(32, 10, 7, 5); ctx.fillRect(19, 14, 5, 5);
    ctx.restore();
  }

  private drawPod(pod: Pod) {
    const ctx = this.ctx;
    const ratio = Math.max(0, pod.hp / pod.maxHp);
    ctx.save();
    ctx.translate(pod.x, pod.y);
    ctx.fillStyle = '#00000055'; ctx.beginPath(); ctx.ellipse(0, 14, 50, 22, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = ratio > .35 ? '#7fd4e855' : '#ff556655'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 52 + Math.sin(this.elapsed * 2) * 4, 0, TAU); ctx.stroke();
    if (this.scene === 'city-occupied') {
      ctx.fillStyle = '#203442'; ctx.fillRect(-38, -26, 76, 57);
      ctx.strokeStyle = '#abc4d578'; ctx.lineWidth = 2; ctx.strokeRect(-38, -26, 76, 57);
      ctx.fillStyle = '#385a64'; ctx.fillRect(-28, -17, 38, 35);
      ctx.fillStyle = '#a9e88b'; ctx.fillRect(17, -16, 12, 5); ctx.fillRect(17, -7, 12, 5);
    } else {
      ctx.fillStyle = '#2b3a46'; polygon(ctx, [[-26, -16], [26, -16], [34, 6], [0, 30], [-34, 6]]); ctx.fill();
      ctx.fillStyle = '#48606f'; polygon(ctx, [[-20, -12], [20, -12], [26, 4], [0, 23], [-26, 4]]); ctx.fill();
    }
    ctx.fillStyle = ratio > .35 ? '#9fe6ff' : '#ff8a93';
    ctx.shadowColor = ratio > .35 ? '#9fe6ff' : '#ff8a93'; ctx.shadowBlur = 16;
    ctx.beginPath(); ctx.ellipse(0, -2, 13, 10, 0, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
    ctx.fillStyle = '#16212a'; ctx.fillRect(-30, -24, 60, 8);
    ctx.fillStyle = '#05080ccc'; ctx.fillRect(-32, -42, 64, 6);
    ctx.fillStyle = ratio > .35 ? '#6fd08d' : '#f0545f'; ctx.fillRect(-32, -42, 64 * ratio, 6);
    ctx.restore();
  }

  private drawBeacon(beacon: Beacon) {
    const ctx = this.ctx;
    const stage = this.stages[Math.min(this.stageIndex, this.stages.length - 1)];
    const locked = this.stageKills < (stage.guards ?? 0);
    const color = beacon.done ? '#93eda5' : locked ? '#9a889e' : worlds[this.scene].accent;
    ctx.save(); ctx.translate(beacon.x, beacon.y);
    ctx.fillStyle = color + '15'; ctx.strokeStyle = color + 'b0'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 60, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.setLineDash([8, 8]); ctx.strokeStyle = color + '60';
    ctx.beginPath(); ctx.arc(0, 0, 48, this.elapsed * .35, this.elapsed * .35 + TAU); ctx.stroke(); ctx.setLineDash([]);
    if (beacon.charge > 0) {
      ctx.strokeStyle = color; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.arc(0, 0, 60, -Math.PI / 2, -Math.PI / 2 + TAU * beacon.charge / beacon.target); ctx.stroke();
    }
    ctx.strokeStyle = color; ctx.lineWidth = 3;
    if (beacon.done) {
      ctx.beginPath(); ctx.moveTo(-12, 0); ctx.lineTo(-3, 9); ctx.lineTo(16, -11); ctx.stroke();
    } else if (stage.type === 'reach') {
      ctx.strokeRect(-15, -18, 26, 36);
      ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(23, 0); ctx.lineTo(15, -7); ctx.moveTo(23, 0); ctx.lineTo(15, 7); ctx.stroke();
    } else {
      ctx.fillStyle = '#101827de'; ctx.fillRect(-18, -15, 36, 30); ctx.strokeRect(-18, -15, 36, 30);
      ctx.fillStyle = color; ctx.fillRect(-10, -7, 20, 3); ctx.fillRect(-10, 1, 12, 3);
    }
    ctx.font = '11px Vazirmatn, sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = color;
    ctx.fillText(beacon.done ? 'انجام شد' : locked ? 'ابتدا نگهبانان را شکست بده' : 'اینجا بایست', 0, 82);
    ctx.restore();
  }

  private drawHazard(hazard: Hazard) {
    const ctx = this.ctx;
    const charging = hazard.delay > 0;
    ctx.save();
    ctx.strokeStyle = charging ? '#fa7278aa' : '#ff8fa7';
    ctx.fillStyle = charging ? '#f129481a' : '#ff24558c';
    if (hazard.kind === 'burst') {
      const progress = 1 - hazard.delay / hazard.totalDelay;
      ctx.lineWidth = charging ? 2 : 6;
      ctx.beginPath(); ctx.arc(hazard.x, hazard.y, hazard.radius, 0, TAU); ctx.fill(); ctx.stroke();
      if (charging) {
        ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(hazard.x, hazard.y, hazard.radius * progress, 0, TAU); ctx.stroke();
        ctx.font = 'bold 25px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#ff9eac'; ctx.fillText('!', hazard.x, hazard.y + 8);
      }
    } else {
      const length = Math.max(this.worldWidth, this.worldHeight) * 1.2;
      const x = hazard.x + Math.cos(hazard.angle) * length;
      const y = hazard.y + Math.sin(hazard.angle) * length;
      if (charging) {
        ctx.setLineDash([15, 10]); ctx.lineWidth = 3;
      } else {
        ctx.strokeStyle = '#ff245b80'; ctx.lineWidth = hazard.radius * 2; ctx.shadowColor = '#ff4c65'; ctx.shadowBlur = 25;
      }
      ctx.beginPath(); ctx.moveTo(hazard.x, hazard.y); ctx.lineTo(x, y); ctx.stroke();
      if (!charging) { ctx.strokeStyle = '#fff3ef'; ctx.lineWidth = 7; ctx.shadowBlur = 0; ctx.stroke(); }
    }
    ctx.restore();
  }

  private drawBlackDoom(enemy: Enemy) {
    const ctx = this.ctx;
    const hover = Math.sin(this.elapsed * 2.8) * 5;
    ctx.save(); ctx.translate(enemy.x, enemy.y + hover);
    ctx.fillStyle = '#00000070'; ctx.beginPath(); ctx.ellipse(0, 58 - hover, 72, 21, 0, 0, TAU); ctx.fill();
    const aura = ctx.createRadialGradient(0, 0, 25, 0, 0, 135);
    aura.addColorStop(0, '#e0476545'); aura.addColorStop(1, '#d2306700');
    ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(0, 0, 135, 0, TAU); ctx.fill();
    if (enemy.shield > 0) {
      ctx.strokeStyle = '#e7a2dc'; ctx.lineWidth = 3; ctx.setLineDash([9, 7]);
      ctx.beginPath(); ctx.arc(0, 0, 94, this.elapsed, this.elapsed + TAU); ctx.stroke(); ctx.setLineDash([]);
    }
    const cloak = ctx.createLinearGradient(-60, -40, 45, 90);
    cloak.addColorStop(0, '#342234'); cloak.addColorStop(.5, '#100b19'); cloak.addColorStop(1, '#4f1a30');
    ctx.fillStyle = cloak; ctx.strokeStyle = '#ad5a706e'; ctx.lineWidth = 2;
    polygon(ctx, [[-31, -43], [-70, -12], [-81, 65], [-54, 53], [-43, 86], [-12, 65], [3, 90], [27, 70], [51, 86], [60, 54], [85, 67], [71, -12], [31, -43]]); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = '#743548'; ctx.lineWidth = 4;
    [[-29, -18, -46, 64], [-10, -15, -7, 67], [17, -20, 24, 69], [33, -10, 49, 60]].forEach(([x, y, x2, y2]) => { ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 12, 31, x2, y2); ctx.stroke(); });
    for (const side of [-1, 1]) {
      ctx.save(); ctx.scale(side, 1);
      const horn = ctx.createLinearGradient(25, -24, 70, -91);
      horn.addColorStop(0, '#706879'); horn.addColorStop(.5, '#b1a1a5'); horn.addColorStop(1, '#e0c4ab');
      ctx.fillStyle = horn; ctx.strokeStyle = '#d8beba90'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(25, -35); ctx.bezierCurveTo(59, -40, 81, -60, 89, -95); ctx.bezierCurveTo(95, -55, 78, -19, 39, -13); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#151021'; ctx.lineWidth = 15; ctx.beginPath(); ctx.moveTo(44, -3); ctx.quadraticCurveTo(66, -20, 86, 3); ctx.stroke();
      ctx.fillStyle = '#716175'; ctx.beginPath(); ctx.ellipse(88, 4, 12, 9, .3, 0, TAU); ctx.fill();
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = '#c8a6a2'; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(85 + i * 5, 3); ctx.quadraticCurveTo(87 + i * 6, -10, 96 + i * 5, -11); ctx.stroke();
      }
      if (enemy.phase > 1) {
        ctx.shadowColor = '#ff6677'; ctx.shadowBlur = 20; ctx.fillStyle = '#ff7284';
        ctx.beginPath(); ctx.arc(88, -14, 7 + enemy.phase, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
      }
      ctx.restore();
    }
    ctx.fillStyle = '#15111e'; ctx.strokeStyle = '#ba9caf80'; ctx.lineWidth = 2;
    polygon(ctx, [[-30, -43], [-17, -69], [0, -82], [17, -69], [30, -43], [23, -10], [0, 0], [-23, -10]]); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#665167'; polygon(ctx, [[-23, -37], [-10, -55], [0, -49], [10, -55], [23, -37], [11, -18], [0, -14], [-11, -18]]); ctx.fill();
    for (const [x, y, r] of [[-14, -35, 8], [14, -35, 8], [0, -54, 6]]) {
      ctx.shadowColor = '#ff392f'; ctx.shadowBlur = 19; ctx.fillStyle = '#ff5641';
      ctx.beginPath(); ctx.ellipse(x, y, r, r * .72, 0, 0, TAU); ctx.fill();
      ctx.shadowBlur = 0; ctx.fillStyle = '#ffe19d'; ctx.beginPath(); ctx.ellipse(x, y, 2, r * .6, 0, 0, TAU); ctx.fill();
    }
    ctx.fillStyle = '#be9d73'; polygon(ctx, [[-9, 2], [0, -5], [9, 2], [0, 12]]); ctx.fill();
    ctx.restore();
  }

  private drawEnemy(enemy: Enemy) {
    const ctx = this.ctx;
    if (enemy.dead) return;
    if (enemy.kind === 'black-doom') { this.drawBlackDoom(enemy); return; }
    ctx.save(); ctx.translate(enemy.x, enemy.y);
    ctx.fillStyle = '#00000060'; ctx.beginPath(); ctx.ellipse(0, 9, enemy.radius + 5, enemy.radius * .65, 0, 0, TAU); ctx.fill();
    ctx.rotate(enemy.angle);
    if (enemy.kind === 'robot') {
      ctx.fillStyle = '#343d48'; ctx.fillRect(-11, -24, 17, 10); ctx.fillRect(-11, 14, 17, 10);
      ctx.fillStyle = '#66707d'; ctx.fillRect(-12, -22, 6, 6); ctx.fillRect(-12, 16, 6, 6);
      ctx.fillStyle = '#a2abb6'; polygon(ctx, [[-15, -13], [7, -16], [17, -7], [17, 7], [7, 16], [-15, 13]]); ctx.fill();
      ctx.fillStyle = '#59616d'; ctx.fillRect(-13, -9, 10, 18);
      ctx.fillStyle = '#161c24'; ctx.beginPath(); ctx.arc(7, 0, 8, 0, TAU); ctx.fill();
      ctx.shadowColor = '#ff3847'; ctx.shadowBlur = 10; ctx.fillStyle = '#ff3847'; ctx.beginPath(); ctx.arc(9, 0, 4, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
      ctx.fillStyle = '#252c37'; ctx.fillRect(9, 11, 22, 5);
    } else if (enemy.kind === 'alien') {
      ctx.fillStyle = '#18101f'; polygon(ctx, [[21, 0], [9, -14], [-2, -23], [-9, -13], [-25, -22], [-17, -4], [-27, 2], [-15, 12], [-21, 23], [-1, 17], [10, 12]]); ctx.fill();
      ctx.strokeStyle = '#764b6d'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#61334c'; polygon(ctx, [[-17, -5], [5, -11], [12, 0], [3, 12], [-15, 7]]); ctx.fill();
      ctx.fillStyle = '#fd5369'; ctx.shadowColor = '#f93758'; ctx.shadowBlur = 10; ctx.fillRect(9, -6, 6, 3); ctx.fillRect(9, 4, 6, 3); ctx.shadowBlur = 0;
      ctx.strokeStyle = '#b8a39f'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(5, -17); ctx.lineTo(20, -23); ctx.moveTo(4, 17); ctx.lineTo(20, 25); ctx.stroke();
    } else {
      ctx.shadowColor = '#f53559'; ctx.shadowBlur = 20;
      ctx.fillStyle = '#211320'; polygon(ctx, [[20, -26], [-22, -57], [-7, -25], [-42, -36], [-24, -8], [-51, 15], [-23, 18], [-10, 47], [4, 27], [24, 37], [35, 13], [46, 0], [31, -17]]); ctx.fill();
      ctx.strokeStyle = '#96344f'; ctx.lineWidth = 2; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.fillStyle = '#482039'; ctx.beginPath(); ctx.ellipse(3, 0, 29, 24, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#15101b'; ctx.beginPath(); ctx.ellipse(15, 0, 18, 15, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ff364b'; ctx.shadowColor = '#ff364b'; ctx.shadowBlur = 18; ctx.beginPath(); ctx.ellipse(20, 0, 10, 7, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ffe9a0'; ctx.beginPath(); ctx.arc(23, 0, 3, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
      ctx.strokeStyle = '#a8949a'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(9, -22); ctx.lineTo(29, -35); ctx.lineTo(32, -23); ctx.moveTo(9, 22); ctx.lineTo(29, 35); ctx.lineTo(32, 23); ctx.stroke();
    }
    ctx.restore();
    if (enemy.stun > 0) {
      ctx.strokeStyle = '#cfaae6'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.ellipse(enemy.x, enemy.y - enemy.radius - 5, 14, 5, 0, 0, TAU); ctx.stroke();
    }
    if (enemy.hp < enemy.maxHp && enemy.kind !== 'boss') {
      ctx.fillStyle = '#05060bcc'; ctx.fillRect(enemy.x - 19, enemy.y - enemy.radius - 12, 38, 4);
      ctx.fillStyle = '#e54958'; ctx.fillRect(enemy.x - 19, enemy.y - enemy.radius - 12, 38 * Math.max(0, enemy.hp / enemy.maxHp), 4);
    }
  }

  private drawPickup(pickup: Pickup) {
    const ctx = this.ctx;
    if (pickup.kind === 'emerald') {
      const emerald = allEmeralds[pickup.emeraldId ?? 0];
      ctx.save();
      ctx.translate(pickup.x, pickup.y + Math.sin(this.elapsed * 2.4 + pickup.x) * 5);
      const halo = ctx.createRadialGradient(0, 0, 4, 0, 0, 56);
      halo.addColorStop(0, `${emerald.color}55`); halo.addColorStop(1, `${emerald.color}00`);
      ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(0, 0, 56, 0, TAU); ctx.fill();
      ctx.rotate(Math.sin(this.elapsed * 1.6) * .35);
      ctx.shadowColor = emerald.color; ctx.shadowBlur = 24;
      ctx.fillStyle = `${emerald.color}3a`; ctx.strokeStyle = emerald.color; ctx.lineWidth = 2;
      polygon(ctx, [[-7, -14], [7, -14], [15, -3], [0, 17], [-15, -3]]); ctx.fill(); ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = `${emerald.color}cc`; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-15, -3); ctx.lineTo(15, -3); ctx.moveTo(-7, -14); ctx.lineTo(0, 17); ctx.lineTo(7, -14); ctx.stroke();
      ctx.fillStyle = '#ffffff70'; polygon(ctx, [[-7, -14], [-1, -14], [-5, -3], [-15, -3]]); ctx.fill();
      ctx.restore();
      return;
    }
    ctx.save(); ctx.translate(pickup.x, pickup.y + Math.sin(this.elapsed * 3 + pickup.x) * 3);
    ctx.shadowColor = pickup.kind === 'energy' ? '#a9ff79' : '#ff5a72'; ctx.shadowBlur = 14;
    ctx.strokeStyle = pickup.kind === 'energy' ? '#a9ff79' : '#ff5a72'; ctx.fillStyle = pickup.kind === 'energy' ? '#427e40' : '#9f3145'; ctx.lineWidth = 1.5;
    polygon(ctx, [[-6, -8], [6, -8], [10, -1], [0, 11], [-10, -1]]); ctx.fill(); ctx.stroke();
    ctx.shadowBlur = 0; ctx.strokeStyle = '#e2ffc2'; ctx.beginPath(); ctx.moveTo(-6, -1); ctx.lineTo(6, -1); ctx.moveTo(0, -7); ctx.lineTo(0, 6); ctx.stroke();
    ctx.restore();
  }

  destroy() {
    this.disposed = true;
    this.arenaImages.forEach(image => { image.onload = null; });
    cancelAnimationFrame(this.raf);
    this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.keyDown);
    window.removeEventListener('keyup', this.keyUp);
    window.removeEventListener('blur', this.blur);
    this.canvas.removeEventListener('pointerdown', this.pointerStart);
    this.canvas.removeEventListener('pointermove', this.pointerMove);
    this.canvas.removeEventListener('lostpointercapture', this.pointerEnd);
    this.canvas.removeEventListener('contextmenu', this.preventMenu);
    window.removeEventListener('pointerup', this.pointerEnd);
    window.removeEventListener('pointercancel', this.pointerEnd);
  }
}