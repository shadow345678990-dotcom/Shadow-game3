import { gameAssets } from '../assets';

export type SceneId = 'ark-lab' | 'ark-observatory' | 'ark-reactor' | 'ark-corridor' | 'ark-hangar' | 'city-street' | 'city-archive' | 'city-bridge' | 'city-occupied' | 'comet-surface' | 'comet-core' | 'doom-throne';

interface World {
  name: string;
  english: string;
  image: string;
  accent: string;
  family: 'lab' | 'hangar' | 'city' | 'comet';
}

export const worlds: Record<SceneId, World> = {
  'ark-lab': { name: 'آرک / آزمایشگاه پروژهٔ شدو', english: 'ARK // PROJECT SHADOW LAB', image: gameAssets.arkLab, accent: '#6ed9eb', family: 'lab' },
  'ark-observatory': { name: 'آرک / رصدخانهٔ زمین', english: 'ARK // EARTH OBSERVATORY', image: gameAssets.arkLab, accent: '#7dafff', family: 'lab' },
  'ark-reactor': { name: 'آرک / اتاق راکتور', english: 'ARK // CHAOS REACTOR', image: gameAssets.arkLab, accent: '#85eda2', family: 'lab' },
  'ark-corridor': { name: 'آرک / راهروی هشدار قرمز', english: 'ARK // EMERGENCY CORRIDOR', image: gameAssets.arkHangar, accent: '#ff625e', family: 'hangar' },
  'ark-hangar': { name: 'آرک / آشیانهٔ کپسول‌های فرار', english: 'ARK // ESCAPE POD HANGAR', image: gameAssets.arkHangar, accent: '#ffb96b', family: 'hangar' },
  'city-street': { name: 'سنترال سیتی / خیابان‌های ویران', english: 'CENTRAL CITY // RUINED STREETS', image: gameAssets.city, accent: '#8dabbc', family: 'city' },
  'city-archive': { name: 'سنترال سیتی / مرکز اسناد اگمن', english: 'CENTRAL CITY // EGGMAN ARCHIVE', image: gameAssets.city, accent: '#61cee3', family: 'city' },
  'city-bridge': { name: 'سنترال سیتی / پل تخلیه', english: 'CENTRAL CITY // EVACUATION BRIDGE', image: gameAssets.city, accent: '#85b8ea', family: 'city' },
  'city-occupied': { name: 'سنترال سیتی / منطقهٔ اشغال بلک آرمز', english: 'CENTRAL CITY // BLACK ARMS OCCUPATION', image: gameAssets.city, accent: '#e4719b', family: 'city' },
  'comet-surface': { name: 'دنباله‌دار سیاه / سطح خارجی', english: 'BLACK COMET // OUTER CRUST', image: gameAssets.comet, accent: '#ad8ae8', family: 'comet' },
  'comet-core': { name: 'دنباله‌دار سیاه / قلب بیومکانیکی', english: 'BLACK COMET // LIVING CORE', image: gameAssets.comet, accent: '#e84c76', family: 'comet' },
  'doom-throne': { name: 'دنباله‌دار سیاه / تالار بلک دووم', english: 'BLACK COMET // BLACK DOOM THRONE', image: gameAssets.comet, accent: '#ff5a56', family: 'comet' },
};

const TAU = Math.PI * 2;

export function buildArena(width: number, height: number, scene: SceneId, image?: HTMLImageElement) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  const world = worlds[scene];
  const { accent } = world;
  ctx.fillStyle = world.family === 'comet' ? '#211525' : '#1c2630';
  ctx.fillRect(0, 0, width, height);
  if (image?.complete && image.naturalWidth) {
    ctx.drawImage(image, 0, 0, width, height);
    ctx.fillStyle = '#06081135';
    ctx.fillRect(0, 0, width, height);
  } else {
    // The arena remains playable and location-specific while its artwork loads.
    ctx.strokeStyle = '#a3bdcc16';
    for (let x = 0; x < width; x += 80) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke(); }
    for (let y = 0; y < height; y += 80) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }
  }

  const glow = (x: number, y: number, radius: number, color = accent, opacity = '2c') => {
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, color + opacity);
    gradient.addColorStop(1, color + '00');
    ctx.fillStyle = gradient;
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  };
  const circle = (x: number, y: number, radius: number, color: string, line = 2) => {
    ctx.strokeStyle = color; ctx.lineWidth = line;
    ctx.beginPath(); ctx.arc(x, y, radius, 0, TAU); ctx.stroke();
  };
  const console = (x: number, y: number, rotation = 0) => {
    ctx.save(); ctx.translate(x, y); ctx.rotate(rotation);
    ctx.fillStyle = '#050b15cc'; ctx.fillRect(-48, -24, 96, 48);
    ctx.strokeStyle = '#8598ae50'; ctx.lineWidth = 2; ctx.strokeRect(-47, -23, 94, 46);
    ctx.fillStyle = accent + '45'; ctx.fillRect(-36, -15, 36, 22);
    ctx.fillStyle = accent + 'bd'; ctx.fillRect(-32, -11, 25, 2); ctx.fillRect(-32, -6, 17, 2);
    for (let i = 0; i < 4; i++) ctx.fillRect(12 + i * 6, -12, 3, 3);
    ctx.fillStyle = '#8392a733'; ctx.fillRect(-35, 13, 64, 3);
    ctx.restore(); glow(x, y, 100);
  };

  if (world.family === 'lab') {
    for (const x of [width * .13, width * .87]) {
      console(x, height * .19);
      console(x, height * .81, Math.PI);
    }
    if (scene === 'ark-observatory') {
      ctx.fillStyle = '#020611'; ctx.fillRect(0, 0, width, height * .2);
      let seed = 211;
      for (let i = 0; i < 130; i++) {
        seed = seed * 16807 % 2147483647;
        ctx.fillStyle = '#d9eaff' + (i % 3 ? '60' : 'aa');
        ctx.fillRect(seed % width, seed % Math.max(1, Math.floor(height * .2)), i % 4 ? 1 : 2, 1);
      }
      const earth = ctx.createRadialGradient(width * .65, -height * .04, 25, width * .65, -height * .04, width * .27);
      earth.addColorStop(0, '#366eaa'); earth.addColorStop(.7, '#143d68'); earth.addColorStop(1, '#8bcfe300');
      ctx.fillStyle = earth; ctx.fillRect(width * .36, 0, width * .57, height * .2);
      ctx.fillStyle = '#7697b322'; ctx.fillRect(0, height * .2, width, 9);
      for (let x = 0; x < width; x += width / 5) { ctx.fillStyle = '#0a1723'; ctx.fillRect(x, 0, 12, height * .2 + 9); }
      glow(width / 2, height * .32, 260, '#6ab6fa');
    } else if (scene === 'ark-reactor') {
      const r = Math.min(width, height) * .23;
      for (let i = 0; i < 4; i++) circle(width / 2, height / 2, r + i * 18, accent + (i ? '2a' : '90'), i ? 1 : 5);
      for (let i = 0; i < 12; i++) {
        const angle = i * TAU / 12;
        ctx.save(); ctx.translate(width / 2 + Math.cos(angle) * (r + 35), height / 2 + Math.sin(angle) * (r + 35)); ctx.rotate(angle);
        ctx.fillStyle = '#8eeaa551'; ctx.fillRect(-14, -5, 28, 10); ctx.restore();
      }
      glow(width / 2, height / 2, r + 60, accent, '36');
    } else {
      circle(width / 2, height / 2, Math.min(width, height) * .2, accent + '40', 3);
      for (let i = 0; i < 4; i++) {
        const x = width * (.2 + i * .2);
        ctx.fillStyle = '#081725b0'; ctx.fillRect(x - 22, height - 83, 44, 60);
        ctx.fillStyle = accent + '60'; ctx.fillRect(x - 13, height - 72, 26, 31);
      }
    }
  } else if (world.family === 'hangar') {
    const corridor = scene === 'ark-corridor';
    const railX = corridor ? .28 : .19;
    for (const x of [width * railX, width * (1 - railX)]) {
      ctx.strokeStyle = '#30222b'; ctx.lineWidth = 12;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
      ctx.strokeStyle = accent + '78'; ctx.lineWidth = 2; ctx.stroke();
      for (let y = 40; y < height; y += 120) glow(x, y, 68, accent);
    }
    for (let y = 75; y < height; y += 145) {
      ctx.fillStyle = '#f0c06530';
      for (let i = 0; i < 5; i++) ctx.fillRect(width * .46 + i * 13, y, 7, 18);
    }
    if (!corridor) for (const x of [width * .09, width * .91]) {
      for (const y of [height * .25, height * .65]) {
        ctx.fillStyle = '#102b39d9'; ctx.beginPath(); ctx.ellipse(x, y, 22, 48, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#9dc9d176'; ctx.lineWidth = 2; ctx.stroke();
        glow(x, y, 60, '#6ea4e2');
      }
    }
    console(width / 2, height * .1);
  } else if (world.family === 'city') {
    if (scene === 'city-archive') {
      ctx.fillStyle = '#122331bb'; ctx.fillRect(width * .08, height * .11, width * .84, height * .78);
      ctx.strokeStyle = '#7198b25a'; ctx.lineWidth = 3; ctx.strokeRect(width * .08, height * .11, width * .84, height * .78);
      for (let i = 0; i < 6; i++) {
        console(width * (.15 + i * .14), height * .14);
        console(width * (.15 + i * .14), height * .86, Math.PI);
      }
      ctx.fillStyle = '#8dc7df18'; ctx.fillRect(width * .45, height * .25, width * .1, height * .5);
    } else if (scene === 'city-bridge') {
      ctx.fillStyle = '#071a2be8'; ctx.fillRect(0, 0, width, height * .21); ctx.fillRect(0, height * .79, width, height * .21);
      for (let i = 0; i < 40; i++) {
        ctx.fillStyle = '#68a8da18'; ctx.fillRect((i * 117) % width, (i * 37) % (height * .2), 38, 2);
        ctx.fillRect((i * 167) % width, height * .81 + (i * 21) % (height * .17), 47, 2);
      }
      for (const y of [height * .22, height * .78]) {
        ctx.fillStyle = '#67778270'; ctx.fillRect(0, y, width, 10);
        for (let x = 40; x < width; x += 85) { ctx.fillStyle = '#d7e9f04a'; ctx.fillRect(x, y - 3, 9, 16); }
      }
      ctx.setLineDash([48, 42]); ctx.strokeStyle = '#e3d4a23c'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(0, height / 2); ctx.lineTo(width, height / 2); ctx.stroke(); ctx.setLineDash([]);
    } else if (scene === 'city-occupied') {
      for (let i = 0; i < 8; i++) {
        const x = (i % 2 ? .92 : .08) * width;
        const y = (.15 + Math.floor(i / 2) * .23) * height;
        ctx.fillStyle = '#26172bda'; ctx.strokeStyle = '#bc54775c'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(x - 22, y + 38); ctx.lineTo(x - 35, y); ctx.lineTo(x, y - 62); ctx.lineTo(x + 27, y + 11); ctx.closePath(); ctx.fill(); ctx.stroke();
        glow(x, y, 130, '#ee6c94');
      }
    } else {
      for (let i = 0; i < 24; i++) {
        const x = (i * 197 + 18) % width;
        const y = (i * 73 + 15) % height;
        ctx.strokeStyle = '#08091080'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 9, y + 11); ctx.lineTo(x - 4, y + 22); ctx.stroke();
      }
    }
  } else {
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) * .36;
    if (scene === 'comet-surface') {
      for (let i = 0; i < 7; i++) {
        const x = width * (.13 + (i % 3) * .36);
        const y = height * (.15 + Math.floor(i / 3) * .34);
        ctx.fillStyle = '#03030a50'; ctx.beginPath(); ctx.ellipse(x, y, 65, 38, .4, 0, TAU); ctx.fill();
        circle(x, y, 52, '#b89ae319', 2);
      }
    } else {
      for (let i = 0; i < 4; i++) circle(cx, cy, radius - i * 24, accent + (i % 2 ? '25' : '50'), i ? 1 : 4);
      for (let i = 0; i < 12; i++) {
        const angle = i * TAU / 12;
        const r = radius + 16;
        ctx.strokeStyle = accent + '45'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
        ctx.lineTo(cx + Math.cos(angle + .035) * (r + 28), cy + Math.sin(angle + .035) * (r + 28)); ctx.stroke();
      }
      glow(cx, cy, radius + 80, accent, scene === 'doom-throne' ? '28' : '20');
    }
    if (scene === 'doom-throne') {
      ctx.strokeStyle = '#ff544335'; ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i <= 6; i++) {
        const angle = i * TAU / 6 - Math.PI / 2;
        const x = cx + Math.cos(angle) * radius * .74;
        const y = cy + Math.sin(angle) * radius * .74;
        if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      for (const x of [width * .3, width * .7]) {
        ctx.fillStyle = '#241018ec';
        ctx.beginPath(); ctx.moveTo(x - 28, 75); ctx.lineTo(x - 46, 13); ctx.lineTo(x + 37, 50); ctx.lineTo(x + 24, 96); ctx.closePath(); ctx.fill();
        glow(x, 60, 100, '#ff6c41');
      }
    }
  }

  const vignette = ctx.createRadialGradient(width / 2, height / 2, Math.min(width, height) * .3, width / 2, height / 2, Math.max(width, height) * .72);
  vignette.addColorStop(0, '#05080a00'); vignette.addColorStop(1, '#020408ab');
  ctx.fillStyle = vignette; ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = accent + '24'; ctx.lineWidth = 1; ctx.strokeRect(14, 14, width - 28, height - 28);
  ctx.font = '11px monospace'; ctx.fillStyle = accent + '85'; ctx.fillText(world.english, 30, height - 27);
  return canvas;
}

export function drawAtmosphere(ctx: CanvasRenderingContext2D, width: number, height: number, scene: SceneId, time: number) {
  const world = worlds[scene];
  ctx.save();
  if (world.family === 'hangar') {
    ctx.globalAlpha = .08 + Math.max(0, Math.sin(time * 2)) * .12;
    ctx.fillStyle = world.accent;
    ctx.fillRect(0, 0, 8, height); ctx.fillRect(width - 8, 0, 8, height);
  }
  for (let i = 0; i < 15; i++) {
    const speed = world.family === 'comet' ? 15 : 6;
    const x = (i * 137.7 + Math.sin(time * .3 + i) * 12) % width;
    const y = (height + (i * 83.3 - time * speed) % height) % height;
    ctx.globalAlpha = .13 + Math.sin(time + i) * .09;
    ctx.fillStyle = world.accent; ctx.fillRect(x, y, world.family === 'comet' ? 2 : 1, 2);
  }
  ctx.restore();
}