import type { DoomForm } from '../data';

const TAU = Math.PI * 2;

function shape(ctx: CanvasRenderingContext2D, points: number[][]) {
  ctx.beginPath();
  points.forEach(([x, y], index) => index ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.closePath();
}

export function drawDoomForm(ctx: CanvasRenderingContext2D, form: DoomForm, angle: number, time: number, superForm: boolean, boosting: boolean, spin: number) {
  ctx.save(); ctx.rotate(angle);
  const red = superForm ? '#ffdc82' : '#f85682';
  if (form === 'wing') {
    // Exact authentic Sonic X Shadow Generations Doom Wings:
    // Massive black demonic fleshy wings with biological ribbing, sharp bat-like armatures,
    // glowing crimson veins branching through the webbing, pale bone claws at the main joints.
    for (const side of [-1, 1]) {
      ctx.save();
      ctx.scale(1, side);
      // Realistic wing flap oscillation based on movement/boost
      const flap = Math.sin(time * (boosting ? 11 : 6.5)) * (boosting ? .14 : .08);
      ctx.rotate(-.08 + flap);

      // Dark shadow projection underneath the wing
      ctx.fillStyle = '#00000055';
      ctx.beginPath();
      ctx.ellipse(-14, 68, 46, 20, .35, 0, TAU);
      ctx.fill();

      // Atmospheric alien Doom Aura emanating along the wing silhouette
      const wingAura = ctx.createRadialGradient(2, 54, 15, -4, 68, 115);
      wingAura.addColorStop(0, red + '45');
      wingAura.addColorStop(.5, red + '18');
      wingAura.addColorStop(1, red + '00');
      ctx.fillStyle = wingAura;
      ctx.beginPath();
      ctx.arc(-4, 68, 115, 0, TAU);
      ctx.fill();

      // Outer fleshy black-charcoal wing membrane with deep crimson gradient
      const skin = ctx.createLinearGradient(-35, 12, 48, 110);
      skin.addColorStop(0, '#2d1829');
      skin.addColorStop(.35, '#120b17');
      skin.addColorStop(.7, '#1b0d1a');
      skin.addColorStop(1, '#3b1424');

      ctx.fillStyle = skin;
      ctx.strokeStyle = red + 'd0';
      ctx.lineWidth = boosting ? 2.5 : 1.7;
      ctx.shadowColor = red;
      ctx.shadowBlur = boosting ? 24 : 10;

      // Authentic Doom Wing silhouette: extended scythe-like primary claw tip and 4 deep scalloped finger curves
      ctx.beginPath();
      ctx.moveTo(-6, 11);
      ctx.bezierCurveTo(15, 18, 38, 52, 54, 108); // Leading edge bone up to sharp main tip
      ctx.lineTo(26, 76);
      ctx.quadraticCurveTo(14, 98, -1, 105);      // First scallop trailing edge
      ctx.lineTo(-14, 73);
      ctx.quadraticCurveTo(-26, 92, -42, 91);     // Second scallop
      ctx.lineTo(-37, 54);
      ctx.quadraticCurveTo(-52, 68, -68, 63);     // Third inner scallop
      ctx.lineTo(-46, 31);
      ctx.bezierCurveTo(-58, 22, -45, 13, -6, 11); // Shoulder root
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Heavy articulated muscular/skeletal armatures running along leading edge
      const bone = ctx.createLinearGradient(-6, 11, 54, 108);
      bone.addColorStop(0, '#594452');
      bone.addColorStop(.5, '#2c1c28');
      bone.addColorStop(1, '#785b6b');
      ctx.strokeStyle = bone;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(-6, 11);
      ctx.bezierCurveTo(12, 22, 34, 55, 52, 105);
      ctx.stroke();

      // Branching internal ribs extending into each trailing claw finger
      ctx.strokeStyle = '#43293c';
      ctx.lineWidth = 2.5;
      for (const [midX, midY, endX, endY] of [
        [22, 54, -1, 105],
        [9, 44, -42, 91],
        [-12, 36, -68, 63]
      ]) {
        ctx.beginPath();
        ctx.moveTo(12, 28);
        ctx.quadraticCurveTo(midX, midY, endX, endY);
        ctx.stroke();
      }

      // Bioluminescent Doom Veins glowing hot red/amber through the skin
      ctx.strokeStyle = red;
      ctx.lineWidth = 1.3;
      ctx.shadowColor = red;
      ctx.shadowBlur = boosting ? 12 : 6;
      ctx.beginPath();
      ctx.moveTo(2, 24);
      ctx.quadraticCurveTo(18, 48, 48, 100);
      ctx.moveTo(18, 46);
      ctx.quadraticCurveTo(12, 70, 0, 98);
      ctx.moveTo(12, 40);
      ctx.quadraticCurveTo(-6, 62, -36, 85);
      ctx.moveTo(-2, 34);
      ctx.quadraticCurveTo(-24, 48, -58, 59);
      // Secondary capillary vein offshoots
      ctx.moveTo(30, 68); ctx.lineTo(38, 77);
      ctx.moveTo(8, 62);  ctx.lineTo(2, 72);
      ctx.moveTo(-12, 52); ctx.lineTo(-19, 61);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Ivory/pale-bone sharp claws at the joint elbow and primary tips (canonical detail)
      ctx.fillStyle = '#ead6c6';
      ctx.strokeStyle = '#614840';
      ctx.lineWidth = 1;
      shape(ctx, [[45, 93], [54, 108], [50, 90]]); // Primary scythe tip claw
      ctx.fill(); ctx.stroke();
      shape(ctx, [[-1, 10], [9, 14], [2, 19]]);    // Upper thumb/carpal claw spur
      ctx.fill(); ctx.stroke();

      ctx.restore();
    }
  } else if (form === 'surf') {
    ctx.fillStyle = '#00000042'; ctx.beginPath(); ctx.ellipse(-12, 21, 75, 33, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#80f1e899'; ctx.lineWidth = boosting ? 4 : 2;
    for (const side of [-1, 1]) {
      ctx.beginPath(); ctx.moveTo(-19, side * 48); ctx.quadraticCurveTo(-50, side * 39, -90, side * 32); ctx.stroke();
    }
    const ray = ctx.createLinearGradient(35, -35, -40, 40);
    ray.addColorStop(0, '#544454'); ray.addColorStop(.6, '#101b25'); ray.addColorStop(1, '#38263b');
    ctx.fillStyle = ray; ctx.strokeStyle = red + 'bb'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(39, 0); ctx.quadraticCurveTo(14, -28, -21, -64);
    ctx.quadraticCurveTo(-10, -26, -35, -17); ctx.quadraticCurveTo(-60, 0, -35, 17);
    ctx.quadraticCurveTo(-10, 26, -21, 64); ctx.quadraticCurveTo(14, 28, 39, 0); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = red + '80'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-35, 0); ctx.quadraticCurveTo(-69, 9, -100, -7); ctx.stroke();
    ctx.fillStyle = '#ec566d'; ctx.beginPath(); ctx.ellipse(24, -8, 5, 2, -.3, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(24, 8, 5, 2, .3, 0, TAU); ctx.fill();
    if (spin > 0) {
      ctx.rotate(time * 12); ctx.strokeStyle = '#97fff0'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, 0, 78, 0, Math.PI * 1.5); ctx.stroke();
    }
  } else {
    for (let i = 0; i < 7; i++) {
      const spread = (i - 3) * .4;
      const endX = -33 - Math.cos(spread) * 35;
      const endY = Math.sin(spread) * 49 + Math.sin(time * 5 + i) * 7;
      ctx.strokeStyle = '#452b65'; ctx.lineWidth = 9;
      ctx.beginPath(); ctx.moveTo(-7, (i - 3) * 4);
      ctx.bezierCurveTo(-28, endY * .4, -38, endY + 14, endX, endY); ctx.stroke();
      ctx.strokeStyle = red + 'aa'; ctx.lineWidth = 2; ctx.stroke();
    }
    const body = ctx.createRadialGradient(5, -8, 1, 0, 0, 34);
    body.addColorStop(0, superForm ? '#f3d68c' : '#8760ba'); body.addColorStop(.45, superForm ? '#8d6929' : '#3f275b'); body.addColorStop(1, '#130d25');
    ctx.fillStyle = body; ctx.strokeStyle = '#b39aca88'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(32, 0); ctx.quadraticCurveTo(4, -37, -21, -20); ctx.quadraticCurveTo(-36, 0, -21, 20); ctx.quadraticCurveTo(4, 37, 32, 0); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#f784b6'; ctx.shadowColor = '#ff5484'; ctx.shadowBlur = 13;
    ctx.beginPath(); ctx.ellipse(12, -8, 6, 3, -.25, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(12, 8, 6, 3, .25, 0, TAU); ctx.fill();
    ctx.shadowBlur = 0; ctx.fillStyle = '#ffecbf'; ctx.fillRect(13, -9, 2, 3); ctx.fillRect(13, 6, 2, 3);
  }
  ctx.restore();
}