let audio: AudioContext | null = null;

export function unlockAudio() {
  try {
    if (!audio) audio = new AudioContext();
    if (audio.state === 'suspended') void audio.resume().catch(() => {});
  } catch {
    // Audio is optional on browsers without Web Audio support.
  }
}

export function playSound(kind: 'shot' | 'hit' | 'power' | 'pickup' | 'wave' | 'teleport' | 'doom', enabled: boolean) {
  if (!enabled || !audio || audio.state !== 'running') return;
  const oscillator = audio.createOscillator();
  const gain = audio.createGain();
  const now = audio.currentTime;
  const config = {
    shot: [360, 65, .065, .028],
    hit: [125, 40, .12, .045],
    power: [110, 850, .38, .05],
    pickup: [700, 1250, .12, .035],
    wave: [220, 440, .35, .04],
    teleport: [1200, 140, .23, .045],
    doom: [95, 560, .21, .04],
  }[kind];
  oscillator.type = kind === 'shot' || kind === 'hit' ? 'sawtooth' : 'sine';
  oscillator.frequency.setValueAtTime(config[0], now);
  oscillator.frequency.exponentialRampToValueAtTime(config[1], now + config[2]);
  gain.gain.setValueAtTime(config[3], now);
  gain.gain.exponentialRampToValueAtTime(.001, now + config[2]);
  oscillator.connect(gain);
  gain.connect(audio.destination);
  oscillator.start(now);
  oscillator.stop(now + config[2]);
  oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
}