import { useEffect, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, Crosshair, Flame, Heart, HelpCircle, Home, MapPin, MessageSquare, Orbit, Pause, Play, RotateCcw, Shield, ShieldHalf, SkipForward, Sparkles, Target, Timer, Volume2, VolumeX, Zap } from 'lucide-react';
import { chaosTeleport, chapters, doomRules, emeralds, fa, powers, superShadow, type GameResult, type Session, type StoryCheckpoint } from '../data';
import { GameEngine, initialHUD } from '../game/engine';
import { ShadowMark } from './Visuals';
import { DoomPowerMenu } from './DoomPowers';
import DoomPowerIcon from './DoomPowerIcon';
import { GameActionButton, GameHoldButton } from './GameButtons';

function duration(seconds: number) {
  return `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`.replace(/\d/g, n => '۰۱۲۳۴۵۶۷۸۹'[Number(n)]);
}

export default function Game({ session, onExit, onRestart, onNext, onResult, onSoundChange, onCheckpoint }: {
  session: Session;
  onExit: () => void;
  onRestart: () => void;
  onNext: () => void;
  onResult: (result: GameResult) => void;
  onSoundChange: (enabled: boolean) => void;
  onCheckpoint: (checkpoint: StoryCheckpoint) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState(initialHUD);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<GameResult | null>(null);
  const [sound, setSound] = useState(session.settings.sound);
  const [stick, setStick] = useState({ x: 0, y: 0 });
  const [doomMenuOpen, setDoomMenuOpen] = useState(false);
  const inputBlocked = paused || !!result || !!hud.dialogue;
  const joystickRef = useRef<HTMLDivElement>(null);
  const joystickPointer = useRef<number | null>(null);
  const dialogueContinueRef = useRef<HTMLButtonElement>(null);
  const callbacks = useRef({ onResult, onExit, onSoundChange, onCheckpoint });
  callbacks.current = { onResult, onExit, onSoundChange, onCheckpoint };

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const engine = new GameEngine(canvasRef.current!, session, setHud, (finished) => {
      setResult(finished);
      setPaused(false);
      callbacks.current.onResult(finished);
    }, () => setPaused(value => !value), checkpoint => callbacks.current.onCheckpoint(checkpoint));
    engineRef.current = engine;
    return () => {
      engine.destroy();
      engineRef.current = null;
      document.body.style.overflow = previousOverflow;
    };
  }, [session]);

  useEffect(() => {
    engineRef.current?.setPaused(paused);
  }, [paused]);

  useEffect(() => {
    if (!inputBlocked) return;
    setStick({ x: 0, y: 0 });
    joystickPointer.current = null;
    engineRef.current?.setTouchMovement(0, 0);
    engineRef.current?.setTouchFire(false);
    setDoomMenuOpen(false);
  }, [inputBlocked]);

  useEffect(() => {
    if (hud.dialogue && !paused) dialogueContinueRef.current?.focus();
  }, [hud.dialogue?.title, hud.dialogue?.index, paused]);

  const exit = () => {
    if (!result) engineRef.current?.retire();
    callbacks.current.onExit();
  };

  const restart = () => {
    if (!result) engineRef.current?.retire();
    onRestart();
  };

  const toggleSound = () => {
    const enabled = !sound;
    setSound(enabled);
    engineRef.current?.setSound(enabled);
    callbacks.current.onSoundChange(enabled);
  };

  const moveStick = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (joystickPointer.current !== event.pointerId) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = joystickRef.current!.getBoundingClientRect();
    let x = (event.clientX - rect.left - rect.width / 2) / 38;
    let y = (event.clientY - rect.top - rect.height / 2) / 38;
    const length = Math.hypot(x, y);
    if (length > 1) { x /= length; y /= length; }
    setStick({ x, y });
    engineRef.current?.setTouchMovement(x, y);
  };

  const releaseStick = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (joystickPointer.current !== event.pointerId) return;
    event.stopPropagation();
    joystickPointer.current = null;
    setStick({ x: 0, y: 0 });
    engineRef.current?.setTouchMovement(0, 0);
  };

  const isStory = session.mode === 'story';
  const teleportStatus = hud.teleportCooldown > 0 ? `${hud.teleportCooldown.toLocaleString('fa-IR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ثانیه` : hud.superTime > 0 ? 'رایگان' : hud.energy < chaosTeleport.cost ? 'انرژی کم' : `${fa(chaosTeleport.cost)} انرژی`;

  return (
    <motion.div className={`game-screen ${hud.controlTime > 0 ? 'chaos-controlled' : ''}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <header className="game-topbar">
        <div className="game-identity"><ShadowMark className="game-mark" /><div><span className="game-brand">SHADOW</span><span dir="rtl">{isStory ? chapters[session.chapter].title : 'نبرد بی‌پایان'}</span></div></div>
        <div className="player-meters">
          <div className="meter-row"><Heart size={14} /><div className="meter-track health-track"><span style={{ width: `${hud.health / hud.maxHealth * 100}%` }} /></div><span>{fa(hud.health)} / {fa(hud.maxHealth)}</span></div>
          <div className="meter-row energy-meter"><Zap size={14} /><div className="meter-track"><span style={{ width: `${hud.energy}%` }} /></div><span>{fa(hud.energy)} / ۱۰۰</span></div>
        </div>
        <div className="game-score"><span>امتیاز</span><strong>{fa(hud.score)}</strong></div>
        <div className="game-top-actions">
          <GameActionButton className="icon-button" onPress={toggleSound} aria-label={sound ? 'قطع صدا' : 'فعال کردن صدا'}>{sound ? <Volume2 size={19} /> : <VolumeX size={19} />}</GameActionButton>
          <GameActionButton className="icon-button pause-button" onPress={() => { if (!result) setPaused(value => !value); }} aria-label="توقف بازی" disabled={!!result}><Pause size={19} /></GameActionButton>
        </div>
      </header>

      <div className="game-stage">
        <canvas ref={canvasRef} className="game-canvas" aria-label="میدان نبرد شدو؛ برای حرکت از WASD و برای تیراندازی از Space استفاده کن" />
        <div className="stage-info" dir="rtl">
          <span className="live-dot" />
          <span>{isStory ? `مرحله ${fa(hud.wave || 1)} از ${fa(hud.targetWaves || chapters[session.chapter].stages.length)}` : `موج ${fa(hud.wave || 1)}`}</span>
          <i /><span>{fa(hud.remaining)} دشمن</span>
        </div>
        <div className="stage-time"><Timer size={14} />{duration(hud.time)}</div>

        {isStory && hud.objective && <div className="objective-card" dir="rtl">
          <span className="objective-label"><Target size={13} />هدف فعلی</span>
          <strong>{hud.objective}</strong>
          <p className="objective-detail">{hud.objectiveDetail}</p>
          {hud.objectiveValue && <span className="objective-value">{hud.objectiveValue}</span>}
          <div className="objective-track"><span style={{ width: `${Math.min(100, Math.max(0, hud.objectiveProgress * 100))}%` }} /></div>
        </div>}

        {hud.podMax > 0 && <div className="pod-meter" dir="rtl"><ShieldHalf size={14} /><span>{hud.podLabel}</span><div><span style={{ width: `${Math.max(0, hud.podHealth / hud.podMax * 100)}%` }} /></div></div>}
        <div className="scene-location" dir="rtl"><MapPin size={12} />{hud.location}</div>

        <div className="emerald-hud" dir="rtl" title={`${hud.emeralds.length} از ۷ کیاس امرالد`}>
          {emeralds.map(emerald => <span key={emerald.id} className={hud.emeralds.includes(emerald.id) ? 'emerald-dot owned' : 'emerald-dot'} style={{ '--gem': emerald.color } as CSSProperties} aria-hidden="true" />)}
          <small>{fa(hud.emeralds.length)}/۷</small>
        </div>

        {hud.superTime > 0 && <div className="super-banner" dir="rtl"><Sparkles size={15} />سوپر شدو · {fa(Math.ceil(hud.superTime))} ثانیه</div>}

        {hud.bossMax > 0 && <div className={`boss-meter ${hud.bossPhase > 0 ? 'doom-boss-meter' : ''}`} dir="rtl"><span>{hud.bossName}{hud.bossPhase > 0 && <small>فاز {fa(hud.bossPhase)} از ۳</small>}</span><div><span style={{ width: `${Math.max(0, hud.bossHealth / hud.bossMax * 100)}%` }} />{hud.bossPhase > 0 && <><i style={{ right: '33.33%' }} /><i style={{ right: '66.66%' }} /></>}</div>{hud.bossAttack && <p>{hud.bossAttack}</p>}</div>}

        <AnimatePresence mode="wait">
          {hud.announcement && !inputBlocked && <motion.div key={hud.announcement} className="wave-announcement" dir="rtl" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}><span>CHAOS UNLEASHED</span><h2>{hud.announcement}</h2><p>{hud.announcementDetail}</p></motion.div>}
        </AnimatePresence>
        <AnimatePresence>
          {hud.toast && !inputBlocked && <motion.div className="game-toast" dir="rtl" key={hud.toast} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><Zap size={15} />{hud.toast}</motion.div>}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {hud.radio && !inputBlocked && <motion.div key={`${hud.radio.speaker}-${hud.radio.text}`} className="story-radio" dir="rtl" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><MessageSquare size={16} /><div><strong>{hud.radio.speaker}</strong><p>{hud.radio.text}</p></div></motion.div>}
        </AnimatePresence>

        {!inputBlocked && <div className="touch-controls">
          <div ref={joystickRef} className="joystick" aria-label="کنترل حرکت لمسی" onPointerDown={event => {
            if (event.button !== 0 || (joystickPointer.current !== null && joystickPointer.current !== event.pointerId)) return;
            event.preventDefault();
            event.stopPropagation();
            joystickPointer.current = event.pointerId;
            event.currentTarget.setPointerCapture(event.pointerId);
            moveStick(event);
          }} onPointerMove={moveStick} onPointerUp={releaseStick} onPointerCancel={releaseStick} onLostPointerCapture={releaseStick}><span style={{ transform: `translate(${stick.x * 30}px, ${stick.y * 30}px)` }} /></div>
          <GameActionButton className="touch-dash" aria-label="جهش سریع" disabled={!hud.dashReady} onPress={() => engineRef.current?.dash()}><Zap size={21} /></GameActionButton>
          <GameActionButton className={`touch-super ${hud.superReady ? 'super-ready' : ''}`} aria-label="تبدیل به سوپر شدو" disabled={!hud.superReady} onPress={() => engineRef.current?.goSuper()}><Sparkles size={19} /></GameActionButton>
          <GameActionButton className="touch-teleport" aria-label={`${chaosTeleport.name}؛ ${teleportStatus}`} disabled={!hud.teleportReady} onPress={() => engineRef.current?.teleport(true)} title={chaosTeleport.description}>{hud.teleportCooldown > 0 ? <span>{hud.teleportCooldown.toLocaleString('fa-IR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</span> : <Orbit size={21} />}</GameActionButton>
          <GameHoldButton className="touch-fire" aria-label="تیراندازی؛ نگه دار" onHoldingChange={held => engineRef.current?.setTouchFire(held)}><Crosshair size={30} /><span>شلیک</span></GameHoldButton>
        </div>}

        <AnimatePresence>
          {doomMenuOpen && !inputBlocked && <motion.div className="doom-menu-position" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: .18 }}>
            <DoomPowerMenu form={hud.doomForm} cooldowns={hud.doomCooldowns} blocked={inputBlocked} onActivate={power => engineRef.current?.castDoomPower(power)} onClose={() => setDoomMenuOpen(false)} />
          </motion.div>}
        </AnimatePresence>
      </div>

      <footer className="game-abilitybar">
        <div className="desktop-controls"><div><kbd>W A S D</kbd><span>حرکت</span></div><div><kbd>SPACE</kbd><span>شلیک (نگه دار)</span></div><div><kbd>SHIFT</kbd><span>جهش</span><span className={`dash-dot ${hud.dashReady ? 'ready' : ''}`} /></div></div>
        <GameActionButton className="ability-button teleport-button" style={{ '--power-color': chaosTeleport.color } as CSSProperties} onPress={() => engineRef.current?.teleport()} disabled={inputBlocked || !hud.teleportReady} aria-label={`${chaosTeleport.name}؛ ${teleportStatus}`} title={chaosTeleport.description}><Orbit size={21} /><div><strong>تله‌پورت</strong><span>{teleportStatus}</span></div><kbd>{chaosTeleport.key}</kbd></GameActionButton>
        <div className="game-powers">
          <GameActionButton className={`ability-button super-button ${hud.superTime > 0 ? 'super-on' : ''}`} style={{ '--power-color': '#f3c552' } as CSSProperties} onPress={() => engineRef.current?.goSuper()} disabled={!hud.superReady || inputBlocked} title={superShadow.description}>
            <Sparkles size={21} />
            <div><strong>{superShadow.name}</strong><span>{hud.superTime > 0 ? `${fa(Math.ceil(hud.superTime))} ثانیه` : hud.emeralds.length < 7 ? `${fa(hud.emeralds.length)} از ۷ امرالد` : hud.superCooldown > 0 ? `بازیابی: ${fa(Math.ceil(hud.superCooldown))} ثانیه` : 'انرژی کامل لازم است'}</span></div>
            <kbd>F</kbd>
          </GameActionButton>
          {powers.map((power, index) => {
            const Icon = [Zap, Timer, Flame][index];
            return <GameActionButton key={power.id} className={`ability-button ${power.id === 'control' && hud.controlTime > 0 ? 'ability-active' : ''}`} style={{ '--power-color': power.color } as CSSProperties} onPress={() => engineRef.current?.castPower(power.id)} disabled={(hud.superTime <= 0 && hud.energy < power.cost) || inputBlocked || (power.id === 'control' && hud.controlTime > 0)} title={power.description}><Icon size={21} /><div><strong>{power.name}</strong><span>{power.id === 'control' && hud.controlTime > 0 ? `${fa(Math.ceil(hud.controlTime))} ثانیه` : hud.superTime > 0 ? 'رایگان' : `${fa(power.cost)} انرژی`}</span></div><kbd>{power.key}</kbd></GameActionButton>;
          })}
        </div>
        <GameActionButton className={`doom-menu-trigger ${doomMenuOpen ? 'doom-menu-trigger-open' : ''}`} onPress={() => setDoomMenuOpen(open => !open)} disabled={inputBlocked} aria-label="باز و بسته کردن منوی دووم پاورها" aria-expanded={doomMenuOpen && !inputBlocked} aria-controls="doom-power-menu"><DoomPowerIcon power={hud.doomForm ?? 'wing'} size={20} /><span>دووم</span></GameActionButton>
        <GameActionButton className="icon-button game-help" onPress={() => { if (!result) setPaused(true); }} aria-label="راهنمای بازی"><HelpCircle size={20} /></GameActionButton>
      </footer>

      <AnimatePresence>
        {hud.dialogue && !paused && !result && <motion.div className="game-story-overlay" role="dialog" aria-modal="true" aria-labelledby="story-dialogue-title" dir="rtl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onKeyDown={event => {
          if (event.key !== 'Tab') return;
          const buttons = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
          if (event.shiftKey && document.activeElement === buttons[0]) { event.preventDefault(); buttons[buttons.length - 1]?.focus(); }
          else if (!event.shiftKey && document.activeElement === buttons[buttons.length - 1]) { event.preventDefault(); buttons[0]?.focus(); }
        }}>
          <img className="story-scene-image" src={hud.dialogue.image} alt={hud.dialogue.location} />
          <div className="story-scene-shade" />
          <div className="story-scene-header"><span className="overline">CHAPTER 0{session.chapter + 1} / SCENE {String(hud.wave).padStart(2, '0')}</span><button className="text-button" onClick={exit}><Home size={15} />بازگشت به پایگاه</button></div>
          <motion.div className="story-dialogue-content" key={`${hud.dialogue.title}-${hud.dialogue.index}`} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .35 }}>
            <span className="story-scene-location"><MapPin size={14} />{hud.dialogue.location}</span>
            <h2 id="story-dialogue-title">{hud.dialogue.title}</h2>
            <div className="dialogue-line"><span>{hud.dialogue.speaker}</span><p>{hud.dialogue.text}</p></div>
            {hud.dialogue.kind === 'briefing' && <div className="story-mission-preview"><Target size={18} /><p>{hud.objectiveDetail}</p></div>}
            <div className="dialogue-actions"><button ref={dialogueContinueRef} className="button button-primary" onClick={() => engineRef.current?.advanceDialogue()}>{hud.dialogue.index === hud.dialogue.total - 1 ? (hud.dialogue.kind === 'finale' ? <><Sparkles size={16} />پایان داستان</> : <><Play size={16} fill="currentColor" />ورود به نبرد</>) : <>ادامهٔ روایت<ArrowLeft size={16} /></>}<kbd>ENTER</kbd></button><button className="text-button" onClick={() => engineRef.current?.advanceDialogue(true)}>{hud.dialogue.kind === 'finale' ? 'رد کردن پایان‌بندی' : 'رد کردن روایت'}<SkipForward size={15} /></button></div>
            <div className="dialogue-pagination">{Array.from({ length: hud.dialogue.total }, (_, index) => <span key={index} className={index === hud.dialogue!.index ? 'dialogue-current' : ''} />)}<small>{hud.dialogue.kind === 'finale' ? `روایت پایانی · ${fa(hud.dialogue.index + 1)} از ${fa(hud.dialogue.total)}` : `مرحله ${fa(hud.wave)} از ${fa(hud.targetWaves)} · نقطهٔ ذخیرهٔ خودکار`}</small></div>
          </motion.div>
        </motion.div>}
      </AnimatePresence>

      <AnimatePresence>
        {paused && !result && <motion.div className="game-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="pause-content" dir="rtl" initial={{ y: 20 }} animate={{ y: 0 }}><span className="overline">TAKE A BREATH</span><h2>آشوب منتظر می‌ماند.</h2><p>بازی متوقف شده است. آماده‌ای برگردی؟</p><button className="button button-primary" onClick={() => setPaused(false)}><Play size={18} fill="currentColor" />ادامهٔ نبرد<kbd>ESC</kbd></button>
            <div className="pause-controls"><div><kbd>WASD / ↑↓←→</kbd><span>حرکت</span></div><div><kbd>SPACE / CLICK</kbd><span>شلیک / شاخک مورف</span></div><div><kbd>Q / E / R</kbd><span>قدرت‌های کیاس</span></div><div><kbd>SHIFT</kbd><span>جهش / چرخش سورف</span></div><div><kbd>F</kbd><span>سوپر شدو (۷ امرالد)</span></div><div><kbd>T</kbd><span>تله‌پورت کیاس</span></div><div><kbd>1 / 2 / 3 / 4 / 5</kbd><span>دووم پاورها</span></div><div><kbd>ESC</kbd><span>توقف بازی</span></div></div>
            <div className="pause-emeralds" aria-label={`${hud.emeralds.length} از ۷ کیاس امرالد`}>{emeralds.map(emerald => <span key={emerald.id} className={hud.emeralds.includes(emerald.id) ? 'emerald-dot owned' : 'emerald-dot'} style={{ '--gem': emerald.color } as CSSProperties} />)}<small>{fa(hud.emeralds.length)} از ۷ امرالد</small></div>
            <p className="pause-teleport-tip">{chaosTeleport.description}</p>
            <p className="pause-doom-tip">{doomRules}</p>
            <p className="pause-tip"><Shield size={16} />امرالدهای سبز انرژی و نشان‌های قرمز سلامتی را بازیابی می‌کنند.</p>
            <p className="pause-tip">{isStory ? 'پیشرفت مراحل ذخیره می‌شود؛ تلاش دوباره از ابتدای همین مرحله است.' : `سوپر شدو ${fa(superShadow.duration)} ثانیه فعال می‌ماند.`}</p>
            <div className="pause-actions"><button className="text-button" onClick={restart}><RotateCcw size={16} />{isStory ? 'از نقطهٔ ذخیره' : 'شروع دوباره'}</button><button className="text-button" onClick={exit}><Home size={16} />بازگشت به پایگاه</button></div>
          </motion.div>
        </motion.div>}

        {result && <motion.div className="game-overlay result-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><motion.div className="result-content" dir="rtl" initial={{ y: 24, scale: .97 }} animate={{ y: 0, scale: 1 }}>
          <ShadowMark className="result-mark" /><span className="overline">{result.victory ? 'MISSION COMPLETE' : 'NEVER SURRENDER'}</span>
          <h2>{result.victory ? (session.chapter === 4 ? 'بلک دووم شکست خورد.' : 'ماموریت انجام شد.') : 'هنوز پایان راه نیست.'}</h2>
          <p className={result.victory ? 'chapter-epilogue' : ''}>{result.victory ? chapters[session.chapter].epilogue : isStory ? 'ماموریت هنوز تمام نشده؛ از نقطهٔ ذخیرهٔ همین مرحله دوباره بجنگ.' : 'هر شکست، یک قدم به شناخت قدرت واقعی تو نزدیک‌تر است.'}</p>
          <div className="result-stats"><div><span>امتیاز نهایی</span><strong>{fa(result.score)}</strong></div><div><span>دشمنان شکست‌خورده</span><strong>{fa(result.kills)}</strong></div><div><span>کیاس امرالد</span><strong>{fa(result.emeralds.length)} <small>/ ۷</small></strong></div><div><span>زمان نبرد</span><strong>{duration(result.duration)}</strong></div></div>
          {result.emeralds.length >= 7 && <p className="result-super"><Sparkles size={15} />فرم سوپر شدو با کلید F، برای {fa(superShadow.duration)} ثانیه در اختیار توست.</p>}
          <div className="result-buttons">{result.victory && session.chapter < chapters.length - 1 ? <button className="button button-primary" onClick={onNext}><SkipForward size={18} />فصل بعدی</button> : <button className="button button-primary" onClick={restart}><RotateCcw size={18} />{isStory && !result.victory ? 'تلاش از همین مرحله' : 'دوباره بجنگ'}</button>}<button className="button button-secondary" onClick={exit}><ArrowLeft size={17} />بازگشت به پایگاه</button></div>
          <span className="saved-note">پیشرفت و رکوردت در این مرورگر ذخیره شد.</span>
        </motion.div></motion.div>}
      </AnimatePresence>
    </motion.div>
  );
}