import type { CSSProperties } from 'react';
import { doomPowers, doomRules, fa, type DoomForm, type DoomPower } from '../data';
import DoomPowerIcon from './DoomPowerIcon';
import { GameActionButton } from './GameButtons';
import { X } from 'lucide-react';

export function DoomPowerMenu({ form, cooldowns, blocked, onActivate, onClose }: {
  form: DoomForm | null;
  cooldowns: Record<DoomPower, number>;
  blocked: boolean;
  onActivate: (power: DoomPower) => void;
  onClose: () => void;
}) {
  return <section className="doom-power-menu" id="doom-power-menu" role="region" aria-label="منوی دووم پاورها" dir="rtl">
    <div className="doom-controls">
      {doomPowers.map(power => {
        const active = form === power.id;
        const cooldown = cooldowns[power.id];
        const status = active ? 'فعال؛ خاموش کن' : cooldown > 0 ? `${Math.max(.1, cooldown).toLocaleString('fa-IR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ثانیه` : power.form ? 'روشن / خاموش' : 'آماده';
        return <GameActionButton key={power.id} className={`doom-ability ${active ? 'doom-ability-active' : ''}`} style={{ '--doom-color': power.color } as CSSProperties} onPress={() => onActivate(power.id)} disabled={blocked || cooldown > 0} aria-pressed={power.form ? active : undefined} aria-label={`${power.name}؛ ${status}؛ کلید ${power.key}`} title={`${power.name} — ${power.description}`}>
          {cooldown > 0 ? <span className="doom-cooldown-number">{fa(Math.ceil(cooldown))}</span> : <DoomPowerIcon power={power.id} size={20} />}
          <strong>{power.shortName}</strong>
          <kbd>{power.key}</kbd>
          {cooldown > 0 && power.cooldown > 0 && <span className="doom-cooldown-line" style={{ width: `${Math.min(100, cooldown / power.cooldown * 100)}%` }} />}
        </GameActionButton>;
      })}
      <GameActionButton className="doom-menu-close" onPress={onClose} aria-label="بستن منوی دووم پاورها" title="بستن منو"><X size={17} /></GameActionButton>
    </div>
  </section>;
}

export function DoomPowerGuide() {
  return <div className="doom-guide" dir="rtl">
    <p className="doom-guide-intro">قدرت‌های شدو جنریشنز، بازآفرینی‌شده برای میدان شوتر دوبعدی.</p>
    <p className="doom-guide-rules">{doomRules}</p>
    <div className="doom-guide-list">{doomPowers.map(power => <div className="doom-guide-row" key={power.id} style={{ '--doom-color': power.color } as CSSProperties}>
      <DoomPowerIcon power={power.id} size={32} />
      <div><span>{power.english}</span><h3>{power.name}</h3><p>{power.description}</p></div>
      <kbd>{power.key}</kbd>
    </div>)}</div>
    <p className="doom-guide-tip">در میدان، دکمهٔ بال‌های «دووم» منوی جداگانهٔ قدرت‌ها را در بالای صفحه باز می‌کند، بدون توقف بازی و بدون کوچک شدن میدان. با یک انگشت جوی‌استیک را نگه دار و با انگشت‌های دیگر قدرت و شلیک را بزن. در مورف دکمهٔ شلیک، شاخک‌ها را فعال می‌کند؛ در سورف دکمهٔ جهش، حملهٔ چرخشی می‌زند.</p>
  </div>;
}