import type { DoomPower } from '../data';

const shapes: Record<DoomPower, string[]> = {
  spear: ['M12 3v15', 'm8 7 4-4 4 4', 'M5 9v11m-3-8 3-3 3 3', 'M19 9v11m-3-8 3-3 3 3'],
  morph: ['M6 11a6 6 0 1 1 12 0v2H6z', 'M6 13c-4 0-4 8-1 8 2 0 2-4 4-4', 'M18 13c4 0 4 8 1 8-2 0-2-4-4-4', 'M9 13v6m6-6v6', 'M9 9h.01M15 9h.01'],
  surf: ['M12 4c-3 5-7 6-10 8l5 1 1 4 4-3 4 3 1-4 5-1c-3-2-7-3-10-8Z', 'm12 14-2 8', 'M2 20c2-2 3 2 5 0m10 0c2-2 3 2 5 0'],
  blast: ['m13 2-3 7H3l5 5-3 7 8-3 6 4-1-8 5-5-8 1-2-8Z', 'm10 12 3 3 3-4'],
  wing: ['M12 19V9', 'M12 12C9 5 6 3 2 2l2 9 4-1 1 5 3 4', 'M12 12c3-7 6-9 10-10l-2 9-4-1-1 5-3 4', 'm10 6 2 3 2-3'],
};

export default function DoomPowerIcon({ power, size = 22, className = '' }: { power: DoomPower; size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>{shapes[power].map((d, index) => <path d={d} key={index} />)}</svg>;
}