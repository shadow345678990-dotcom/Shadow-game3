import { useEffect, useRef, useState, type ButtonHTMLAttributes, type PointerEvent } from 'react';

type ButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick' | 'onPointerDown' | 'onPointerUp' | 'onPointerCancel' | 'onLostPointerCapture' | 'onKeyDown' | 'onKeyUp' | 'onBlur'>;

export function GameActionButton({ onPress, children, className = '', disabled, ...props }: ButtonProps & { onPress: () => void }) {
  return <button {...props} type="button" disabled={disabled} className={`game-action-button ${className}`} onPointerDown={event => {
    if (disabled || event.button !== 0) return;
    // Act on every contact, including the second or third finger, without waiting for a synthetic click.
    event.preventDefault();
    event.stopPropagation();
    onPress();
  }} onClick={event => {
    event.stopPropagation();
    const source = event.nativeEvent as MouseEvent & { pointerType?: string };
    if (!disabled && event.detail === 0 && !source.pointerType) onPress();
  }} onContextMenu={event => event.preventDefault()}>{children}</button>;
}

export function GameHoldButton({ onHoldingChange, children, className = '', disabled, ...props }: ButtonProps & { onHoldingChange: (held: boolean) => void }) {
  const pointers = useRef(new Set<number>());
  const keyboardHeld = useRef(false);
  const callback = useRef(onHoldingChange);
  const lastHeld = useRef(false);
  const [held, setHeld] = useState(false);
  callback.current = onHoldingChange;

  const sync = () => {
    const next = pointers.current.size > 0 || keyboardHeld.current;
    if (next === lastHeld.current) return;
    lastHeld.current = next;
    setHeld(next);
    callback.current(next);
  };

  const release = (event: PointerEvent<HTMLButtonElement>) => {
    if (!pointers.current.delete(event.pointerId)) return;
    event.stopPropagation();
    sync();
  };

  useEffect(() => () => {
    if (lastHeld.current) callback.current(false);
  }, []);

  useEffect(() => {
    if (!disabled) return;
    pointers.current.clear();
    keyboardHeld.current = false;
    if (lastHeld.current) {
      lastHeld.current = false;
      setHeld(false);
      callback.current(false);
    }
  }, [disabled]);

  return <button {...props} type="button" disabled={disabled} className={`game-action-button ${className}`} data-held={held ? 'true' : undefined} aria-pressed={held} onPointerDown={event => {
    if (disabled || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    pointers.current.add(event.pointerId);
    sync();
  }} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release} onKeyDown={event => {
    if (disabled || ![' ', 'Enter'].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    keyboardHeld.current = true;
    sync();
  }} onKeyUp={event => {
    if (![' ', 'Enter'].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    keyboardHeld.current = false;
    sync();
  }} onBlur={() => {
    keyboardHeld.current = false;
    sync();
  }} onClick={event => {
    event.stopPropagation();
    const source = event.nativeEvent as MouseEvent & { pointerType?: string };
    if (!disabled && event.detail === 0 && !source.pointerType) {
      keyboardHeld.current = !keyboardHeld.current;
      sync();
    }
  }} onContextMenu={event => event.preventDefault()}>{children}</button>;
}