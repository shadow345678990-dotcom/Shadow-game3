export function ShadowMark({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" fill="none" aria-hidden="true" className={className}>
      <path d="M8 35 1 28l12 1L4 17l15 5L15 7l12 10 7-14 2 18 10-3-5 12 5 5-17 9-12-4z" fill="currentColor" />
      <path d="m5 19 17 8-5-17 9 17 9-18-4 22-13 5z" fill="#101114" />
      <path d="m24 30 11-3-4 8-10 1z" fill="#f1f0ed" />
      <path d="m30 30 3-1-2 5-3 1z" fill="#f43f48" />
      <path d="m33 37 8-5-1 7-8 3-9-4z" fill="#101114" />
    </svg>
  );
}

export function Emerald({ color = '#9deb72', className = '' }: { color?: string; className?: string }) {
  return (
    <svg viewBox="0 0 80 80" fill="none" className={className} aria-hidden="true" style={{ color }}>
      <path d="m21 15 38 0 14 22-33 35L7 37z" fill="currentColor" fillOpacity=".12" stroke="currentColor" strokeWidth="1.4" />
      <path d="M7 37h66M21 15l8 22 11 35 11-35 8-22M29 37l11-22 11 22" stroke="currentColor" strokeWidth="1.1" strokeOpacity=".65" />
      <path d="m40 15 11 22-11 35-11-35z" fill="currentColor" fillOpacity=".17" />
      <path d="m21 15 8 22H7z" fill="white" fillOpacity=".12" />
    </svg>
  );
}